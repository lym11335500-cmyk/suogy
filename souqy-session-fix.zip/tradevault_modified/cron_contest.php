<?php
/**
 * =====================================================
 * cron_contest.php — مهمة مجدولة للمسابقات
 * =====================================================
 * نفّذ هذا الملف يومياً (أو كل ساعة) عبر Cron Job:
 *
 *   # كل يوم الساعة 00:05
 *   5 0 * * * php /path/to/your/site/cron_contest.php
 *
 * أو عبر URL (مع حماية بمفتاح سري في site_settings):
 *   https://yoursite.com/cron_contest.php?key=YOUR_SECRET
 * =====================================================
 */

define('RUNNING_CRON', true);
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/referral_helpers.php';

// حماية بسيطة: تشغيل فقط من CLI أو بمفتاح سري
$cronKey = getSetting($pdo, 'cron_secret_key', '');
$isCli   = (PHP_SAPI === 'cli');
$keyOk   = $cronKey && isset($_GET['key']) && hash_equals($cronKey, $_GET['key']);

if (!$isCli && !$keyOk) {
    http_response_code(403);
    exit('Access denied');
}

$now = date('Y-m-d');
echo "[".date('Y-m-d H:i:s')."] بدء تشغيل مهمة المسابقات\n";

// 1. انتهت تواريخ المسابقات النشطة؟ → احسب الفائزين وأنشئ مسابقة جديدة
$expired = $pdo->prepare("SELECT * FROM contests WHERE status='active' AND end_date < ?");
$expired->execute([$now]);
$expired = $expired->fetchAll();

foreach ($expired as $c) {
    echo "[INFO] إنهاء مسابقة #{$c['id']}: {$c['title']}\n";
    calcContestWinners($pdo, $c['id']);
    echo "[OK] تم حساب الفائزين للمسابقة #{$c['id']}\n";

    // إنشاء مسابقة الشهر القادم تلقائياً
    if (getSetting($pdo, 'contest_auto_cycle', '1') === '1') {
        $nextStart = date('Y-m-01', strtotime('first day of next month'));
        $nextEnd   = date('Y-m-t', strtotime('last day of next month'));
        $nextTitle = 'مسابقة إحالة — ' . date('m/Y', strtotime($nextStart));

        $exists = $pdo->prepare("SELECT COUNT(*) FROM contests WHERE start_date=? AND status='active'");
        $exists->execute([$nextStart]);
        if (!$exists->fetchColumn()) {
            $pdo->prepare("INSERT INTO contests (title,start_date,end_date,status) VALUES (?,?,?,'active')")
                ->execute([$nextTitle, $nextStart, $nextEnd]);
            echo "[OK] تم إنشاء مسابقة الشهر القادم: $nextTitle ($nextStart → $nextEnd)\n";
        }
    }
}

// 2. تأكد من وجود مسابقة نشطة للشهر الحالي
$active = getActiveContest($pdo);
if (!$active) {
    $start = date('Y-m-01');
    $end   = date('Y-m-t');
    $title = 'مسابقة إحالة — ' . date('m/Y');
    $pdo->prepare("INSERT INTO contests (title,start_date,end_date,status) VALUES (?,?,?,'active')")
        ->execute([$title, $start, $end]);
    echo "[OK] لم تكن هناك مسابقة نشطة، تم إنشاء مسابقة للشهر الحالي: $title\n";
}

// 3. تحديث رموز الإحالة للمستخدمين الذين لا يملكون رمزاً
$noCode = $pdo->query("SELECT id FROM users WHERE referral_code IS NULL OR referral_code=''")->fetchAll(PDO::FETCH_COLUMN);
foreach ($noCode as $uid) {
    ensureReferralCode($pdo, $uid);
}
if ($noCode) echo "[OK] تم توليد رموز إحالة لـ ".count($noCode)." مستخدم\n";

echo "[".date('Y-m-d H:i:s')."] انتهت مهمة المسابقات بنجاح\n";
