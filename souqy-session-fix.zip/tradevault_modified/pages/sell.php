<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid  = uid();
$user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

// KYC guard
if($user['kyc_status']!=='approved'){
    pageHead('نشر إعلان');
    pageTopbar($pdo,'index.php','نشر إعلان');
    echo '<div class="page" style="padding:20px 16px 90px">';
    echo flash('warn','يجب التحقق من هويتك قبل نشر إعلانات');
    echo '<a href="kyc.php" class="btn btn-gold btn-block" style="margin-top:12px"><i class="fas fa-id-card"></i> التحقق من الهوية</a>';
    echo '</div>';
    pageFoot();
    exit;
}

// Daily limit
$rate  = (int)getSetting($pdo,'max_listings_per_day','2');
$today = $pdo->prepare("SELECT COUNT(*) FROM listings WHERE user_id=? AND DATE(created_at)=CURDATE()");
$today->execute([$uid]);
$todayCount = (int)$today->fetchColumn();

$cats   = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order,name")->fetchAll();
$msg    = ''; $msgType='ok';
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit   = null;
if($editId){
    $es = $pdo->prepare("SELECT * FROM listings WHERE id=? AND user_id=?");
    $es->execute([$editId,$uid]);
    $edit = $es->fetch();
}

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $title   = trim($_POST['title']??'');
    $desc    = trim($_POST['description']??'');
    $price   = (float)($_POST['price']??0);
    $catId   = (int)($_POST['category_id']??0);
    $errors  = [];

    if(!$title||mb_strlen($title)<5)     $errors[]='العنوان قصير جداً (5 أحرف على الأقل)';
    if(mb_strlen($title)>255)            $errors[]='العنوان طويل جداً';
    if(!$desc||mb_strlen($desc)<20)      $errors[]='الوصف قصير جداً (20 حرفاً على الأقل)';
    if(mb_strlen($desc)>2000)            $errors[]='الوصف لا يتجاوز 2000 حرف';
    if($price<=0)                        $errors[]='السعر يجب أن يكون أكبر من صفر';
    if(!$catId)                          $errors[]='اختر فئة المنتج';
    if(!$editId && $todayCount>=$rate)   $errors[]="الحد اليومي للنشر هو $rate إعلانات";

    if(empty($errors)){
        if($editId && $edit){
            $pdo->prepare("UPDATE listings SET title=?,description=?,price=?,category_id=? WHERE id=? AND user_id=?")
                ->execute([$title,$desc,$price,$catId,$editId,$uid]);
            $lid = $editId;
            $msg = 'تم تحديث الإعلان بنجاح ✅';
        } else {
            $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
            $pdo->prepare("INSERT INTO listings(user_id,category_id,title,description,price,expires_at)VALUES(?,?,?,?,?,?)")
                ->execute([$uid,$catId,$title,$desc,$price,$expires]);
            $lid = (int)$pdo->lastInsertId();
            $msg = 'تم نشر إعلانك بنجاح ✅';
        }

        // Upload images
        $uploaded = 0;
        if(!empty($_FILES['images']['name'][0])){
            foreach($_FILES['images']['name'] as $i=>$name){
                if($uploaded>=10) break;
                $file = [
                    'name'=>$name,'type'=>$_FILES['images']['type'][$i],
                    'tmp_name'=>$_FILES['images']['tmp_name'][$i],
                    'error'=>$_FILES['images']['error'][$i],
                    'size'=>$_FILES['images']['size'][$i]
                ];
                $path = uploadFile($file,'listings');
                if($path){
                    $pdo->prepare("INSERT INTO listing_images(listing_id,image_path,sort_order)VALUES(?,?,?)")
                        ->execute([$lid,$path,$uploaded]);
                    $uploaded++;
                }
            }
        }

        header("Location:listing.php?id=$lid"); exit;
    } else {
        $msg = implode('<br>',$errors);
        $msgType = 'err';
    }
}

pageHead($editId?'تعديل الإعلان':'نشر إعلان جديد');
pageTopbar($pdo,'index.php',$editId?'تعديل الإعلان':'نشر إعلان جديد');
?>
<div class="page" style="padding:16px 16px 90px">

<?php if($msg): echo '<div class="alert alert-'.$msgType.'"><i class="fas fa-'.($msgType==='ok'?'check-circle':'times-circle').'"></i><span>'.$msg.'</span></div>'; endif; ?>

<?php if(!$editId): ?>
<div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;font-size:.78rem">
  <span style="color:var(--txt2)">نشرت اليوم</span>
  <span class="mono gold"><?=$todayCount?>/<?=$rate?></span>
</div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_csrf" value="<?=csrf()?>">

  <div class="card" style="margin-bottom:14px">
    <div class="card-hd"><i class="fas fa-layer-group"></i> تفاصيل الإعلان</div>

    <div class="fg">
      <label>الفئة <span style="color:var(--red)">*</span></label>
      <select name="category_id" class="fsel" required>
        <option value="">اختر فئة المنتج</option>
        <?php foreach($cats as $c): ?>
        <option value="<?=$c['id']?>" <?=($edit&&$edit['category_id']==$c['id'])||($_POST['category_id']??'')==$c['id']?'selected':''?>>
          <?=e($c['name'])?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="fg">
      <label>عنوان الإعلان <span style="color:var(--red)">*</span></label>
      <input type="text" name="title" class="fi" required maxlength="255" placeholder="مثال: حساب PUBG مستوى 80 — 5000 UC — رانك Conqueror"
        value="<?=e($edit['title']??$_POST['title']??'')?>" id="titleIn" oninput="cc(this,'tc',255)">
      <div class="char-count"><span id="tc">0</span>/255</div>
    </div>

    <div class="fg">
      <label>وصف تفصيلي <span style="color:var(--red)">*</span></label>
      <textarea name="description" class="fta" required rows="6" maxlength="2000" placeholder="اكتب وصفاً مفصلاً: المستوى، الإنجازات، المحتوى، أي معلومات مفيدة للمشتري..." id="descIn" oninput="cc(this,'dc',2000)"><?=e($edit['description']??$_POST['description']??'')?></textarea>
      <div class="char-count"><span id="dc">0</span>/2000</div>
    </div>

    <div class="fg">
      <label>السعر (دولار $) <span style="color:var(--red)">*</span></label>
      <div style="position:relative">
        <input type="number" name="price" class="fi" required min="0.01" step="0.01" placeholder="0.00"
          value="<?=e($edit['price']??$_POST['price']??'')?>" style="padding-right:44px">
        <span style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--gold);font-weight:900;font-family:'JetBrains Mono',monospace">$</span>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="card-hd"><i class="fas fa-images"></i> صور المنتج (حتى 10)</div>

    <div id="dropZone" onclick="document.getElementById('imgFiles').click()"
      style="border:2px dashed var(--border2);border-radius:var(--r2);padding:28px 20px;text-align:center;cursor:pointer;transition:all .2s;background:var(--bg2)">
      <i class="fas fa-cloud-upload-alt" style="font-size:2rem;color:var(--txt3);margin-bottom:10px;display:block"></i>
      <div style="font-size:.85rem;color:var(--txt2);margin-bottom:4px">اضغط لرفع الصور</div>
      <div style="font-size:.72rem;color:var(--txt3)">JPG, PNG, WEBP — حتى 10MB لكل صورة</div>
    </div>
    <input type="file" name="images[]" id="imgFiles" accept="image/*" multiple style="display:none" onchange="previewImgs(this)">
    <div id="imgPreviews" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px"></div>

    <?php
    if($editId){
        $imgs = $pdo->prepare("SELECT * FROM listing_images WHERE listing_id=? ORDER BY sort_order");
        $imgs->execute([$editId]);
        $imgs = $imgs->fetchAll();
        if($imgs):
    ?>
    <div style="margin-top:10px">
      <div style="font-size:.75rem;color:var(--txt2);margin-bottom:8px">الصور الحالية:</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
        <?php foreach($imgs as $img): ?>
        <div style="position:relative">
          <img src="<?=e($img['image_path'])?>" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--r3);border:1px solid var(--border)">
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; } ?>

    <div class="form-hint" style="margin-top:10px">
      <i class="fas fa-lightbulb" style="color:var(--gold)"></i>
      نصيحة: أضف صوراً واضحة وعالية الجودة — تزيد فرص البيع 3 أضعاف
    </div>
  </div>

  <div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;margin-bottom:16px;font-size:.75rem;color:var(--txt2);line-height:1.7">
    <i class="fas fa-exclamation-circle" style="color:var(--gold)"></i>
    <strong style="color:var(--txt)"> تنبيه:</strong> لا تضع كلمات مرور الحساب في الوصف — يتم تبادل البيانات السرية فقط داخل المحادثة الآمنة بعد الشراء.
  </div>

  <button type="submit" class="btn btn-gold btn-block">
    <i class="fas fa-<?=$editId?'save':'paper-plane'?>"></i>
    <?=$editId?'حفظ التغييرات':'نشر الإعلان'?>
  </button>
</form>

</div>

<script>
function cc(el,spanId,max){
  document.getElementById(spanId).textContent=el.value.length;
}
document.addEventListener('DOMContentLoaded',()=>{
  const t=document.getElementById('titleIn');const d=document.getElementById('descIn');
  if(t)document.getElementById('tc').textContent=t.value.length;
  if(d)document.getElementById('dc').textContent=d.value.length;
});

function previewImgs(input){
  const prev = document.getElementById('imgPreviews');
  prev.innerHTML='';
  const dz = document.getElementById('dropZone');
  dz.style.borderColor='var(--gold)';
  Array.from(input.files).slice(0,10).forEach(f=>{
    const r=new FileReader();
    r.onload=e=>{
      const div=document.createElement('div');
      div.style.cssText='position:relative;aspect-ratio:1;border-radius:8px;overflow:hidden;border:1px solid var(--border)';
      div.innerHTML='<img src="'+e.target.result+'" style="width:100%;height:100%;object-fit:cover">';
      prev.appendChild(div);
    };
    r.readAsDataURL(f);
  });
}
</script>
<?php pageFoot(); ?>
