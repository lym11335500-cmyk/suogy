<?php
// NOTIFICATIONS
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$uid=uid();
// Mark all read
$pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$uid]);
$notifs=$pdo->prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50");
$notifs->execute([$uid]);
$notifs=$notifs->fetchAll();

$typeIcon=[
    'new_purchase'=>['fa-shopping-cart','var(--gold)'],
    'chat_message'=>['fa-comment','var(--blue)'],
    'sale_complete'=>['fa-check-double','var(--green)'],
    'purchase_complete'=>['fa-box-check','var(--green)'],
    'kyc_approved'=>['fa-shield-check','var(--green)'],
    'kyc_rejected'=>['fa-times-circle','var(--red)'],
    'refund'=>['fa-undo','var(--blue)'],
    'kyc_request'=>['fa-user-shield','var(--gold)'],
];

pageHead('الإشعارات');
pageTopbar($pdo,'index.php','الإشعارات');
?>
<div class="page" style="padding:16px 16px 90px">
<?php if(empty($notifs)): ?>
<div class="empty fade-up"><i class="fas fa-bell-slash"></i><p>لا توجد إشعارات</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($notifs as $n):
  [$ic,$col]=$typeIcon[$n['type']]??['fa-info-circle','var(--txt2)'];
?>
<a href="<?=e($n['link']?:'#')?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:13px 14px;display:flex;gap:12px;align-items:flex-start;text-decoration:none;color:var(--txt)">
  <div style="width:36px;height:36px;border-radius:var(--r3);background:<?=$col?>18;border:1px solid <?=$col?>33;display:flex;align-items:center;justify-content:center;color:<?=$col?>;flex-shrink:0">
    <i class="fas <?=$ic?>"></i>
  </div>
  <div style="flex:1">
    <div style="font-size:.83rem;line-height:1.5"><?=e($n['message'])?></div>
    <div style="font-size:.65rem;color:var(--txt3);margin-top:4px"><?=timeAgo($n['created_at'])?></div>
  </div>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<?php pageBottomNav(); pageFoot(); ?>
