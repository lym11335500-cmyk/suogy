<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
// 🔒 حماية — يجب تسجيل الدخول
requireLogin();

$viewId = isset($_GET['id']) ? (int)$_GET['id'] : (isLoggedIn() ? uid() : 0);
if(!$viewId){ header('Location:index.php'); exit; }
$isOwn  = isLoggedIn() && uid()===$viewId;

$user = $pdo->query("SELECT * FROM users WHERE id=$viewId")->fetch();
if(!$user){ header('Location:index.php'); exit; }

// تأكد من وجود معرف فريد
if($isOwn) ensureUniqueId($pdo, $viewId);
$user = $pdo->query("SELECT * FROM users WHERE id=$viewId")->fetch();

$siteName = getSiteName($pdo);
$siteUrl  = getSetting($pdo,'site_url',getSiteUrl());

$msg=''; $msgType='ok';
if($isOwn && $_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act = $_POST['act']??'';

    if($act==='update_profile'){
        $phone   = trim($_POST['phone']??'');
        $picPath = $user['profile_pic'];
        if(!empty($_FILES['profile_pic']['name']) && $_FILES['profile_pic']['error']===UPLOAD_ERR_OK){
            $up = uploadFile($_FILES['profile_pic'],'profiles');
            if($up) $picPath=$up; else { $msg='صورة غير صالحة'; $msgType='err'; }
        }
        if(!$msg){
            $pdo->prepare("UPDATE users SET phone=?,profile_pic=? WHERE id=?")->execute([$phone,$picPath,$viewId]);
            $user = $pdo->query("SELECT * FROM users WHERE id=$viewId")->fetch();
            $msg='✅ تم تحديث الملف الشخصي';
        }
    }

    if($act==='change_password'){
        $oldPw = $_POST['old_password']??'';
        $newPw = $_POST['new_password']??'';
        if(!verifyPassword($oldPw,$user['password'])){ $msg='كلمة المرور الحالية خاطئة'; $msgType='err'; }
        elseif(strlen($newPw)<6){ $msg='كلمة المرور الجديدة 6 أحرف على الأقل'; $msgType='err'; }
        else {
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$newPw,$viewId]);
            $msg='✅ تم تغيير كلمة المرور بنجاح';
        }
    }
}

$listings = $pdo->prepare("SELECT l.*,c.name_ar cat_name,c.name cat_name_en,c.icon cat_icon,u.username seller_name,u.profile_pic,u.seller_rating FROM listings l JOIN categories c ON l.category_id=c.id JOIN users u ON l.user_id=u.id WHERE l.user_id=? AND l.status='active' ORDER BY l.created_at DESC LIMIT 12");
$listings->execute([$viewId]);
$listings = $listings->fetchAll();

pageHead(e($user['username']));
pageTopbar($pdo,'index.php', e($user['username']));
?>
<div class="page" style="padding:16px 16px 90px">

<?php if($msg): echo flash($msgType==='ok'?'ok':$msgType,$msg); endif; ?>

<!-- PROFILE HEADER -->
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:20px;margin-bottom:14px;text-align:center;position:relative">
  <?php if($isOwn): ?>
  <label for="picUp" style="position:absolute;top:12px;right:12px;cursor:pointer">
    <div class="icon-btn" style="width:32px;height:32px" title="تغيير الصورة"><i class="fas fa-camera" style="font-size:.8rem"></i></div>
  </label>
  <?php endif; ?>

  <div style="width:80px;height:80px;border-radius:var(--r);margin:0 auto 12px;border:3px solid var(--gold3);overflow:hidden;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:900;color:var(--gold)">
    <?php if($user['profile_pic']): ?><img src="<?=e(assetUrl($user['profile_pic']))?>" style="width:100%;height:100%;object-fit:cover" alt="">
    <?php else: ?><?=strtoupper(mb_substr($user['username'],0,1,'UTF-8'))?><?php endif; ?>
  </div>

  <div style="font-size:1.15rem;font-weight:900;margin-bottom:4px"><?=e($user['username'])?></div>
  <div style="margin-bottom:10px"><?=kycBadge($user['kyc_status'])?></div>

  <div class="grid-3">
    <div class="stat-box" style="padding:10px"><div class="stat-val" style="font-size:1rem"><?=$user['total_sales']?></div><div class="stat-lbl">مبيعات</div></div>
    <div class="stat-box" style="padding:10px"><div class="stat-val" style="font-size:1rem"><?=$user['seller_rating']?></div><div class="stat-lbl">نجوم بائع</div></div>
    <div class="stat-box" style="padding:10px"><div class="stat-val" style="font-size:1rem"><?=$user['buyer_rating']?></div><div class="stat-lbl">نجوم مشترٍ</div></div>
  </div>
  <?php if($user['seller_rating']>0): ?>
  <div style="margin-top:10px;color:var(--gold)"><?=str_repeat('★',min((int)$user['seller_rating'],10))?></div>
  <?php endif; ?>
  <div style="font-size:.7rem;color:var(--txt3);margin-top:6px">عضو منذ <?=date('M Y',strtotime($user['created_at']))?></div>
  <?php if($user['unique_id']): ?>
  <div style="margin-top:8px;display:flex;align-items:center;justify-content:center;gap:6px;font-size:.75rem;color:var(--txt2)">
    <i class="fas fa-fingerprint" style="color:var(--gold)"></i>
    <span class="mono" style="color:var(--gold)"><?=e($user['unique_id'])?></span>
  </div>
  <?php endif; ?>
</div>

<?php if($isOwn): ?>

<!-- ══ SETTINGS CARD (merged) ══ -->
<div class="card" style="margin-bottom:14px">

  <!-- Settings Tab Switcher -->
  <div style="display:flex;background:var(--bg2);border-radius:var(--r3);padding:3px;gap:3px;margin-bottom:16px">
    <button type="button" id="tabBtnInfo" onclick="switchSettingsTab('info')"
      style="flex:1;padding:9px 6px;border-radius:var(--r4);font-size:.78rem;font-weight:700;border:none;cursor:pointer;
             background:var(--card);color:var(--gold);border:1px solid var(--border2);transition:all .2s;font-family:inherit"
      class="settings-tab-btn active">
      <i class="fas fa-user-edit" style="display:block;margin-bottom:3px"></i>معلوماتي
    </button>
    <button type="button" id="tabBtnPw" onclick="switchSettingsTab('pw')"
      style="flex:1;padding:9px 6px;border-radius:var(--r4);font-size:.78rem;font-weight:700;border:none;cursor:pointer;
             background:transparent;color:var(--txt3);border:1px solid transparent;transition:all .2s;font-family:inherit"
      class="settings-tab-btn">
      <i class="fas fa-lock" style="display:block;margin-bottom:3px"></i>كلمة المرور
    </button>
  </div>

  <!-- Tab: Profile Info -->
  <div id="tabInfo">
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="update_profile">
      <input type="file" name="profile_pic" id="picUp" accept="image/*" style="display:none" onchange="this.form.submit()">
      <div class="fg">
        <label>رقم الهاتف</label>
        <input type="tel" name="phone" class="fi" value="<?=e($user['phone']??'')?>" placeholder="رقم الهاتف">
      </div>
      <div class="fg">
        <label>البريد الإلكتروني</label>
        <input type="email" class="fi" value="<?=e($user['email'])?>" disabled style="opacity:.5;cursor:not-allowed">
        <div class="form-hint">لا يمكن تغيير البريد الإلكتروني</div>
      </div>
      <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-save"></i> حفظ التعديلات</button>
    </form>
  </div>

  <!-- Tab: Change Password -->
  <div id="tabPw" style="display:none">
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="change_password">
      <div class="fg">
        <label>كلمة المرور الحالية</label>
        <input type="password" name="old_password" class="fi" placeholder="كلمة مرورك الحالية" required>
      </div>
      <div class="fg">
        <label>كلمة المرور الجديدة</label>
        <input type="password" name="new_password" class="fi" placeholder="6 أحرف على الأقل" minlength="6" required>
      </div>
      <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-key"></i> تغيير كلمة المرور</button>
    </form>
  </div>

</div>

<!-- QUICK LINKS -->
<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px">
  <a href="kyc.php" style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--txt)">
    <i class="fas fa-id-card" style="color:var(--gold);width:20px;text-align:center"></i>
    <span style="flex:1;font-size:.88rem">التحقق من الهوية (KYC)</span>
    <?=kycBadge($user['kyc_status'])?>
  </a>
  <a href="contests.php" style="background:linear-gradient(135deg,rgba(232,164,0,.08),rgba(232,164,0,.03));border:1px solid rgba(232,164,0,.25);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--txt)">
    <i class="fas fa-trophy" style="color:var(--gold);width:20px;text-align:center"></i>
    <span style="flex:1;font-size:.88rem;font-weight:700;color:var(--gold)">المسابقات والإحالة</span>
    <i class="fas fa-chevron-left" style="font-size:.65rem;color:var(--gold)"></i>
  </a>
  <a href="wallet.php" style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--txt)">
    <i class="fas fa-wallet" style="color:var(--gold);width:20px;text-align:center"></i>
    <span style="flex:1;font-size:.88rem">المحفظة والمعاملات</span>
    <span class="mono gold" style="font-size:.85rem"><?=money((float)$user['balance'])?></span>
  </a>
  <a href="logout.php" style="background:var(--bg3);border:1px solid #ef444422;border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--red)">
    <i class="fas fa-sign-out-alt" style="width:20px;text-align:center"></i>
    <span style="font-size:.88rem;font-weight:700">تسجيل الخروج</span>
  </a>
</div>

<script>
function switchSettingsTab(tab) {
  var isInfo = tab === 'info';
  document.getElementById('tabInfo').style.display = isInfo ? 'block' : 'none';
  document.getElementById('tabPw').style.display   = isInfo ? 'none'  : 'block';
  var btnInfo = document.getElementById('tabBtnInfo');
  var btnPw   = document.getElementById('tabBtnPw');
  // Active styles
  btnInfo.style.background   = isInfo ? 'var(--card)'        : 'transparent';
  btnInfo.style.color        = isInfo ? 'var(--gold)'        : 'var(--txt3)';
  btnInfo.style.borderColor  = isInfo ? 'var(--border2)'     : 'transparent';
  btnPw.style.background     = !isInfo ? 'var(--card)'       : 'transparent';
  btnPw.style.color          = !isInfo ? 'var(--gold)'       : 'var(--txt3)';
  btnPw.style.borderColor    = !isInfo ? 'var(--border2)'    : 'transparent';
}
// Auto-switch to password tab if there's an error from that form
<?php if(isset($msg) && $msg && strpos($msg,'كلمة المرور')!==false): ?>
switchSettingsTab('pw');
<?php endif; ?>
</script>

<?php endif; ?>

<!-- USER LISTINGS -->
<?php if(!empty($listings)): ?>
<div class="sec-hd" style="padding:0;margin-bottom:10px">
  <div class="sec-title">إعلانات <?=e($user['username'])?></div>
  <span style="font-size:.75rem;color:var(--txt3)"><?=count($listings)?></span>
</div>
<div class="grid-2">
  <?php foreach($listings as $l): echo listingCard($pdo,$l); endforeach; ?>
</div>
<?php endif; ?>

</div>
<?php pageBottomNav(); pageFoot(); ?>
