<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$siteName = getSetting(\$pdo,'site_name','سوقي');
$howItWorks = getSetting($pdo,'how_it_works','');
$terms = getSetting($pdo,'terms_content','');
$depositMethods = $pdo->query("SELECT * FROM payment_methods WHERE type='deposit' AND is_active=1 ORDER BY sort_order LIMIT 10")->fetchAll();
$withdrawMethods = $pdo->query("SELECT * FROM payment_methods WHERE type='withdraw' AND is_active=1 ORDER BY sort_order LIMIT 10")->fetchAll();

pageHead('معلومات عن الموقع');
?>
<div class="page pb-safe" style="padding-bottom:90px">
  <?php pageTopbar($pdo,'js:back','معلومات'); ?>

  <!-- HERO -->
  <div style="background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(232,164,0,0.15) 0%,transparent 70%);padding:36px 20px 28px;text-align:center">
    <div style="width:64px;height:64px;background:linear-gradient(135deg,var(--gold),var(--gold3));border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#060810;margin:0 auto 16px;box-shadow:0 8px 32px rgba(232,164,0,.35)">⚡</div>
    <h1 style="font-size:1.7rem;font-weight:900;color:var(--t1);margin-bottom:6px"><?=e($siteName)?></h1>
    <p style="color:var(--t2);font-size:.88rem;max-width:320px;margin:0 auto;line-height:1.7">مجتمع رقمي موثوق لبيع وشراء الحسابات والمنتجات الرقمية بأمان وضمان كامل</p>
  </div>

  <!-- HOW IT WORKS -->
  <div style="padding:0 16px 16px">
    <div class="sec-card anim-in" style="--d:0s">
      <div class="sec-card-title"><i class="fas fa-route" style="color:var(--gold)"></i> كيف يعمل الموقع؟</div>
      <div style="display:flex;flex-direction:column;gap:14px">
        <?php
        $steps=[
          ['1','fa-user-plus','سجّل حسابك','أنشئ حساباً مجانياً خلال ثوانٍ فقط'],
          ['2','fa-wallet','أضف رصيداً','أودع عبر أي طريقة دفع متاحة'],
          ['3','fa-search','تصفّح المنتجات','اختر الحساب الرقمي المناسب لك'],
          ['4','fa-handshake','أتمّ الصفقة','اشترِ بأمان وستظهر بيانات الحساب فوراً'],
          ['5','fa-star','قيّم التجربة','شارك رأيك لمساعدة المجتمع'],
        ];
        foreach($steps as [$n,$ic,$title,$desc]): ?>
        <div style="display:flex;gap:14px;align-items:flex-start">
          <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold3));display:flex;align-items:center;justify-content:center;color:#060810;font-weight:900;font-size:.85rem;flex-shrink:0"><?=$n?></div>
          <div>
            <div style="font-weight:700;font-size:.88rem;color:var(--t1);margin-bottom:2px"><?=e($title)?></div>
            <div style="font-size:.78rem;color:var(--t2)"><?=e($desc)?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- DEPOSIT METHODS -->
    <?php if($depositMethods): ?>
    <div class="sec-card anim-in" style="--d:.06s">
      <div class="sec-card-title"><i class="fas fa-arrow-circle-down" style="color:var(--green)"></i> طرق الإيداع المتاحة</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <?php foreach($depositMethods as $m): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px;background:var(--bg2);border-radius:var(--r3);border:1px solid var(--b1)">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(232,164,0,.1);display:flex;align-items:center;justify-content:center;color:var(--gold);flex-shrink:0"><i class="fas <?=e($m['icon'])?>"></i></div>
          <div style="flex:1">
            <div style="font-weight:700;font-size:.84rem"><?=e($m['name_ar']??$m['name'])?></div>
            <div style="font-size:.7rem;color:var(--t3)">حد أدنى: $<?=$m['min_amount']?> · رسوم: <?=$m['fee_percent']?>%</div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- WITHDRAW METHODS -->
    <?php if($withdrawMethods): ?>
    <div class="sec-card anim-in" style="--d:.1s">
      <div class="sec-card-title"><i class="fas fa-money-bill-wave" style="color:var(--cyan)"></i> طرق السحب المتاحة</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <?php foreach($withdrawMethods as $m): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px;background:var(--bg2);border-radius:var(--r3);border:1px solid var(--b1)">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(34,211,238,.08);display:flex;align-items:center;justify-content:center;color:var(--cyan);flex-shrink:0"><i class="fas <?=e($m['icon'])?>"></i></div>
          <div style="flex:1">
            <div style="font-weight:700;font-size:.84rem"><?=e($m['name_ar']??$m['name'])?></div>
            <div style="font-size:.7rem;color:var(--t3)">حد أدنى: $<?=$m['min_amount']?> · رسوم: <?=$m['fee_percent']?>%</div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- SECURITY -->
    <div class="sec-card anim-in" style="--d:.14s">
      <div class="sec-card-title"><i class="fas fa-shield-alt" style="color:var(--blue)"></i> الأمان والضمان</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <?php foreach([
          ['fa-lock','نظام Escrow للحماية','أموالك محجوزة بأمان حتى تأكيد استلام المنتج'],
          ['fa-id-card','توثيق KYC إلزامي','نتحقق من هوية البائعين لضمان الموثوقية والأمان'],
          ['fa-headset','دعم النزاعات الفوري','فريقنا يتدخل فوراً عند أي خلاف بين البائع والمشتري'],
          ['fa-clock','ضمان 48 ساعة للمشتري','لديك 48 ساعة بعد الصفقة لتقديم بلاغ في حال أي مشكلة'],
        ] as [$ic,$t,$d]): ?>
        <div style="display:flex;align-items:flex-start;gap:12px;padding:10px;background:var(--bg2);border-radius:var(--r3);border:1px solid var(--b1)">
          <div style="width:32px;height:32px;border-radius:8px;background:rgba(74,143,245,.1);display:flex;align-items:center;justify-content:center;color:var(--blue);flex-shrink:0;margin-top:2px"><i class="fas <?=$ic?>"></i></div>
          <div><div style="font-weight:700;font-size:.84rem;margin-bottom:2px"><?=$t?></div><div style="font-size:.75rem;color:var(--t2)"><?=$d?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- FAQ -->
    <div class="sec-card anim-in" style="--d:.18s">
      <div class="sec-card-title"><i class="fas fa-question-circle" style="color:var(--purple)"></i> الأسئلة الشائعة</div>
      <div id="faqList">
        <?php foreach([
          ['كيف أودع رصيداً؟','انتقل إلى صفحة المحفظة، اختر طريقة الإيداع، أرسل المبلغ وأرفق صورة التأكيد.'],
          ['كم تستغرق معالجة الإيداع؟','عادةً خلال ساعة إلى 24 ساعة حسب طريقة الدفع.'],
          ['هل يمكنني إلغاء طلب السحب؟','يمكنك ذلك طالما الطلب في حالة "معلق" من صفحة المحفظة.'],
          ['ماذا يحدث إذا لم يستجب البائع؟','سيتم استرجاع أموالك تلقائياً بعد انتهاء مهلة الصفقة.'],
          ['كيف أصبح بائعاً موثقاً؟','أكمل توثيق KYC من ملفك الشخصي لرفع مصداقيتك.'],
        ] as $i=>[$q,$a]): ?>
        <div class="faq-item" onclick="toggleFaq(<?=$i?>)" style="border-bottom:1px solid var(--b1);cursor:pointer">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0">
            <span style="font-size:.84rem;font-weight:700;color:var(--t1)"><?=e($q)?></span>
            <i id="faq_ic_<?=$i?>" class="fas fa-chevron-down" style="color:var(--t3);font-size:.75rem;transition:transform .25s"></i>
          </div>
          <div id="faq_<?=$i?>" style="display:none;padding-bottom:12px;font-size:.8rem;color:var(--t2);line-height:1.7"><?=e($a)?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- TERMS -->
    <?php if($terms): ?>
    <div class="sec-card anim-in" style="--d:.22s">
      <div class="sec-card-title"><i class="fas fa-file-contract" style="color:var(--gold)"></i> الشروط والأحكام</div>
      <div style="font-size:.8rem;color:var(--t2);line-height:1.8;white-space:pre-wrap"><?=e($terms)?></div>
    </div>
    <?php endif; ?>

    <!-- CONTACT CTA -->
    <div style="text-align:center;padding:20px 0 10px">
      <div style="font-size:.8rem;color:var(--t3)">هل لديك استفسار؟ تواصل معنا عبر لوحة النزاعات</div>
    </div>
  </div>
</div>

<?php pageBottomNav('about'); ?>

<script>
function toggleFaq(i){
  var el=document.getElementById('faq_'+i), ic=document.getElementById('faq_ic_'+i);
  var open=el.style.display!=='none';
  el.style.display=open?'none':'block';
  ic.style.transform=open?'rotate(0)':'rotate(180deg)';
}
</script>

<?php pageFoot(); ?>
