<?php
// ══════════════════════════════════════════════════════
//  auction_deal.php — غرفة تسليم المزاد
//  الأطراف: الفائز + البائع + الأدمن
// ══════════════════════════════════════════════════════
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid = uid();
$rid = isset($_GET['rid']) ? (int)$_GET['rid'] : 0;
if (!$rid) { header('Location: auctions.php'); exit; }

// ─── تحميل بيانات الغرفة ──────────────────────────────
$stmt = $pdo->prepare("
    SELECT ch.*,
           a.title  auction_title, a.id auction_id, a.current_price win_amount,
           a.seller_id a_seller_id,
           w.id     winner_uid,  w.username winner_name,  w.profile_pic winner_pic,
           s.id     seller_uid,  s.username seller_name,  s.profile_pic seller_pic
    FROM chats ch
    JOIN auctions a  ON a.id  = ch.auction_id
    JOIN users   w  ON w.id  = ch.winner_id
    JOIN users   s  ON s.id  = ch.seller_id2
    WHERE ch.id=? AND ch.auction_id IS NOT NULL
");
$stmt->execute([$rid]);
$room = $stmt->fetch();
if (!$room) { header('Location: auctions.php'); exit; }

$isWinner = ($uid === (int)$room['winner_uid']);
$isSeller = ($uid === (int)$room['seller_uid']);
$isAdm    = isAdmin();
if (!$isWinner && !$isSeller && !$isAdm) { header('Location: index.php'); exit; }

$myLabel = $isWinner ? 'فائز' : ($isSeller ? 'بائع' : 'إدارة');

// ─── تسجيل الدخول للغرفة ──────────────────────────────
if (!$room['winner_joined']  && $isWinner)  { $pdo->prepare("UPDATE chats SET winner_joined=1  WHERE id=?")->execute([$rid]); }
if (!$room['seller_joined']  && $isSeller)  { $pdo->prepare("UPDATE chats SET seller_joined=1  WHERE id=?")->execute([$rid]); }
if (!$room['admin_joined']   && $isAdm)     { $pdo->prepare("UPDATE chats SET admin_joined=1   WHERE id=?")->execute([$rid]); }
$stmt->execute([$rid]); $room = $stmt->fetch();

// ─── AJAX POLL ────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax']==='poll') {
    header('Content-Type: application/json; charset=utf-8');
    $lastId = (int)($_GET['last']??0);
    try {
        $pdo->prepare("UPDATE messages SET is_read=1 WHERE chat_id=? AND sender_id!=?")->execute([$rid,$uid]);
        $q = $pdo->prepare("
            SELECT m.id, m.content, m.message_type, m.image_path, m.created_at, m.sender_id,
                   u.username sender_name, u.profile_pic sender_pic, u.is_admin
            FROM messages m JOIN users u ON m.sender_id=u.id
            WHERE m.chat_id=? AND m.id>?
            ORDER BY m.id ASC LIMIT 50
        ");
        $q->execute([$rid,$lastId]);
        $r2 = $pdo->query("SELECT status,expires_at,winner_joined,seller_joined,admin_joined FROM chats WHERE id=$rid")->fetch();
        $tl = null;
        if ($r2['expires_at']) {
            $sec = max(0, strtotime($r2['expires_at'])-time());
            $tl = sprintf('%02d:%02d:%02d',floor($sec/3600),floor($sec%3600/60),$sec%60);
        }
        echo json_encode(['ok'=>true,'messages'=>$q->fetchAll(),'status'=>$r2['status'],'time_left'=>$tl,'joined'=>[(int)$r2['winner_joined'],(int)$r2['seller_joined'],(int)$r2['admin_joined']]]);
    } catch(Exception $e){ echo json_encode(['ok'=>false]); }
    exit;
}

// ─── POST ACTIONS ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()) {
    $act = $_POST['act']??'';

    // إرسال رسالة
    if ($act==='send' && in_array($room['status'],['active','extended'])) {
        $content = trim($_POST['content']??'');
        $type    = 'text';
        $imgPath = null;
        if (!empty($_FILES['media']['name']) && $_FILES['media']['error']===UPLOAD_ERR_OK) {
            $up = uploadFileMedia($_FILES['media'],'deals');
            if ($up) { $imgPath=$up['path']; $type=$up['type']; if(!$content) $content=$imgPath; }
        }
        if ($type==='text' && $content && preg_match('/https?:\/\//i',$content)) $type='link';
        if ($content || $imgPath) {
            try {
                $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content,image_path)VALUES(?,?,?,?,?)")
                    ->execute([$rid,$uid,$type,$content,$imgPath]);
                // إشعار باقي الأطراف
                $notifyIds = [(int)$room['winner_uid'],(int)$room['seller_uid']];
                foreach ($pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll() as $ad) $notifyIds[]=(int)$ad['id'];
                foreach (array_unique($notifyIds) as $nid)
                    if ($nid!==$uid)
                        addNotif($pdo,$nid,'deal_message','💬 رسالة في غرفة المزاد: '.mb_substr($room['auction_title'],0,25,'UTF-8'),'auction_deal.php?rid='.$rid);
            } catch(Exception $e){}
        }
        header("Location:auction_deal.php?rid=$rid"); exit;
    }

    // أدمن: إغلاق الغرفة (تم التسليم)
    if ($act==='admin_close' && $isAdm) {
        try {
            $pdo->prepare("UPDATE chats SET status='completed' WHERE id=?")->execute([$rid]);
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
                ->execute([$rid,"✅ أغلقت الإدارة غرفة التسليم — تم إتمام الصفقة بنجاح!\nشكراً لاستخدامكم سوقي 🎉"]);
            addNotif($pdo,(int)$room['winner_uid'],'auction','✅ تم تأكيد استلام المزاد من قِبل الإدارة','');
            addNotif($pdo,(int)$room['seller_uid'],'auction','✅ تم تأكيد تسليم المزاد من قِبل الإدارة','');
        } catch(Exception $e){}
        header("Location:auction_deal.php?rid=$rid"); exit;
    }

    // أدمن: تمديد الوقت
    if ($act==='admin_extend' && $isAdm) {
        try {
            $newExp = date('Y-m-d H:i:s', strtotime($room['expires_at']??'now')+7200);
            $pdo->prepare("UPDATE chats SET expires_at=?,status='extended' WHERE id=?")->execute([$newExp,$rid]);
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
                ->execute([$rid,'⏱ تم تمديد وقت غرفة التسليم بساعتين إضافيتين من قِبل الإدارة.']);
        } catch(Exception $e){}
        header("Location:auction_deal.php?rid=$rid"); exit;
    }
}

// ─── تحميل الرسائل ─────────────────────────────────────
$allMsgs = [];
try {
    $q = $pdo->prepare("SELECT m.id,m.content,m.message_type,m.image_path,m.created_at,m.sender_id,u.username sender_name,u.profile_pic sender_pic,u.is_admin FROM messages m JOIN users u ON m.sender_id=u.id WHERE m.chat_id=? ORDER BY m.id ASC");
    $q->execute([$rid]);
    $allMsgs = $q->fetchAll();
    $pdo->prepare("UPDATE messages SET is_read=1 WHERE chat_id=? AND sender_id!=?")->execute([$rid,$uid]);
} catch(Exception $e){}

$lastId   = !empty($allMsgs) ? (int)end($allMsgs)['id'] : 0;
$isActive = in_array($room['status'],['active','extended']);
$isDone   = in_array($room['status'],['completed','expired','cancelled']);
$joinCount= (int)$room['winner_joined']+(int)$room['seller_joined']+(int)$room['admin_joined'];
$timeLeft = '';
if ($room['expires_at']) {
    $sec = max(0, strtotime($room['expires_at'])-time());
    $timeLeft = sprintf('%02d:%02d:%02d',floor($sec/3600),floor($sec%3600/60),$sec%60);
}

pageHead(e($room['auction_title']));
pageTopbar($pdo,'js:back','غرفة تسليم المزاد');
?>
<style>
.room-hd{padding:12px 14px;background:var(--bg2);border-bottom:1px solid var(--b1)}
.timer{font-family:'JetBrains Mono',monospace;font-size:.82rem;color:var(--gold);font-weight:700;background:var(--bg3);padding:4px 10px;border-radius:20px;border:1px solid rgba(232,164,0,.2)}
.party-dot{display:inline-flex;align-items:center;gap:4px;font-size:.63rem;font-weight:700;padding:3px 8px;border-radius:20px}
.party-dot.on{background:rgba(16,217,122,.1);color:var(--green);border:1px solid rgba(34,197,94,.15)}
.party-dot.off{background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(239,68,68,.15)}
.msgs{flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:10px;min-height:0}
.mw{display:flex;gap:8px;max-width:90%}
.mw.me{flex-direction:row-reverse;align-self:flex-end}
.mw.them{align-self:flex-start}
.mw.sys{align-self:center;max-width:100%}
.av{width:30px;height:30px;border-radius:8px;background:var(--card2);border:1px solid var(--b2);overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:900;color:var(--gold);flex-shrink:0}
.av img{width:100%;height:100%;object-fit:cover}
.bub{padding:9px 12px;border-radius:14px;font-size:.84rem;line-height:1.55;max-width:100%;word-break:break-word}
.mw.me   .bub{background:linear-gradient(135deg,var(--gold),var(--gold3));color:#06040a;border-bottom-right-radius:4px}
.mw.them .bub{background:var(--card2);border:1px solid var(--b2);color:var(--t1);border-bottom-left-radius:4px}
.mw.adm  .bub{background:linear-gradient(135deg,rgba(59,130,246,.1),rgba(139,92,246,.1));border:1px solid rgba(59,130,246,.2);color:var(--t1);border-bottom-left-radius:4px}
.mt{font-size:.57rem;color:var(--t3);margin-top:3px}
.sn{font-size:.6rem;font-weight:700;color:var(--t3);margin-bottom:2px}
.adm-tag{display:inline-block;background:rgba(59,130,246,.15);color:var(--blue);font-size:.53rem;font-weight:900;padding:1px 5px;border-radius:4px;margin-left:4px}
.sysbub{background:var(--bg3);border:1px solid var(--b1);border-radius:10px;padding:9px 14px;font-size:.77rem;color:var(--t2);text-align:center;line-height:1.7;white-space:pre-wrap;width:100%}
.msg-img{max-width:220px;border-radius:10px;cursor:pointer;display:block}
.msg-link{color:var(--blue);text-decoration:underline;word-break:break-all}
.ibar{padding:10px 12px;background:var(--bg2);border-top:1px solid var(--b1);flex-shrink:0}
.irow{display:flex;align-items:flex-end;gap:8px}
.txta{flex:1;background:var(--bg3);border:1.5px solid var(--b2);border-radius:20px;padding:10px 14px;color:var(--t1);font-family:'Cairo',sans-serif;font-size:.88rem;outline:none;resize:none;max-height:100px;line-height:1.4;min-height:42px}
.txta:focus{border-color:var(--gold)}
.sbtn{width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold3));border:none;color:#06040a;display:flex;align-items:center;justify-content:center;font-size:.95rem;cursor:pointer;flex-shrink:0}
.ibtn{width:36px;height:36px;border-radius:50%;background:var(--bg3);border:1px solid var(--b2);color:var(--t2);display:flex;align-items:center;justify-content:center;cursor:pointer}
.ibtn:hover{border-color:var(--gold);color:var(--gold)}
.adm-panel{background:linear-gradient(135deg,rgba(59,130,246,.05),rgba(139,92,246,.05));border:1px solid rgba(59,130,246,.2);border-radius:var(--r2);padding:12px;margin:8px 12px;flex-shrink:0}
.prev-bar{display:none;align-items:center;gap:8px;padding:6px 12px;font-size:.75rem;color:var(--t2);border-top:1px solid var(--b1)}
.prev-bar img{height:40px;border-radius:6px;object-fit:cover}
</style>

<div style="display:flex;flex-direction:column;height:calc(100vh - 56px);overflow:hidden">

<!-- HEADER -->
<div class="room-hd">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
    <div style="flex:1;min-width:0">
      <div style="font-weight:800;font-size:.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        🏆 <?=e($room['auction_title'])?>
      </div>
      <div style="font-size:.67rem;color:var(--t2);margin-top:1px">
        <span style="color:var(--gold);font-weight:700;font-family:'JetBrains Mono',monospace"><?=money((float)$room['win_amount'])?></span>
        · أنت: <span style="color:var(--gold);font-weight:700"><?=$myLabel?></span>
      </div>
    </div>
    <?php if($timeLeft && $isActive): ?>
    <div class="timer" id="tdisplay">⏱ <?=$timeLeft?></div>
    <?php endif; ?>
  </div>

  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:5px">
    <div style="display:flex;gap:5px">
      <div class="party-dot <?=$room['winner_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> فائز</div>
      <div class="party-dot <?=$room['seller_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> بائع</div>
      <div class="party-dot <?=$room['admin_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> إدارة</div>
    </div>
    <?php
    $stBadge = ['active'=>'badge-ok','extended'=>'badge-ok','completed'=>'badge-ok','expired'=>'badge-err','cancelled'=>'badge-err'];
    $stLabel = ['active'=>'● نشطة','extended'=>'● ممتدة','completed'=>'✅ مكتملة','expired'=>'⏰ منتهية','cancelled'=>'❌ ملغاة'];
    ?>
    <span class="badge <?=$stBadge[$room['status']]??'badge-gray'?>" style="font-size:.6rem"><?=$stLabel[$room['status']]??$room['status']?></span>
  </div>
</div>

<!-- ADMIN PANEL -->
<?php if($isAdm && $isActive): ?>
<div class="adm-panel">
  <div style="font-size:.72rem;font-weight:800;color:var(--blue);margin-bottom:8px"><i class="fas fa-shield-alt"></i> لوحة الإدارة</div>
  <div style="display:flex;gap:7px;flex-wrap:wrap">
    <form method="POST" style="display:inline">
      <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="admin_close">
      <button class="btn btn-green btn-xs" onclick="return confirm('تأكيد إغلاق الغرفة وإتمام التسليم؟')">
        <i class="fas fa-check-double"></i> إتمام التسليم
      </button>
    </form>
    <form method="POST" style="display:inline">
      <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="admin_extend">
      <button class="btn btn-ghost btn-xs"><i class="fas fa-clock"></i> تمديد +2 ساعة</button>
    </form>
    <a href="auction.php?id=<?=$room['auction_id']?>" class="btn btn-ghost btn-xs" target="_blank">
      <i class="fas fa-gavel"></i> عرض المزاد
    </a>
  </div>
</div>
<?php endif; ?>

<?php if($isDone): ?>
<div style="padding:10px 14px;background:rgba(16,217,122,.06);border-bottom:1px solid rgba(16,217,122,.15);font-size:.75rem;color:var(--green);text-align:center;flex-shrink:0">
  <i class="fas fa-check-circle"></i>
  <?=$room['status']==='completed'?'✅ تم إتمام الصفقة بنجاح':'الغرفة مغلقة'?>
</div>
<?php endif; ?>

<!-- MESSAGES -->
<div class="msgs" id="msgs">
<?php foreach($allMsgs as $m):
  $isMe  = (int)$m['sender_id'] === $uid;
  $isSys = $m['message_type'] === 'system';
  $isAdmMsg = (bool)$m['is_admin'];
  $av    = strtoupper(mb_substr($m['sender_name'],0,1,'UTF-8'));
?>
<div class="mw <?=$isSys?'sys':($isMe?'me':($isAdmMsg?'adm':'them'))?>">
  <?php if(!$isSys && !$isMe): ?>
  <div class="av">
    <?php if($m['sender_pic']): ?><img src="<?=e(assetUrl($m['sender_pic']))?>" alt=""><?php else: ?><?=$av?><?php endif; ?>
  </div>
  <?php endif; ?>
  <div>
    <?php if(!$isMe && !$isSys): ?>
    <div class="sn"><?=e($m['sender_name'])?><?=$isAdmMsg?'<span class="adm-tag">إدارة</span>':''?></div>
    <?php endif; ?>
    <?php if($isSys): ?>
    <div class="sysbub"><?=e($m['content'])?></div>
    <?php elseif($m['message_type']==='image'): ?>
    <div class="bub" style="padding:4px"><img src="<?=e(assetUrl($m['image_path']))?>" class="msg-img" onclick="window.open(this.src)"></div>
    <?php elseif($m['message_type']==='link'): ?>
    <div class="bub"><a href="<?=e($m['content'])?>" class="msg-link" target="_blank"><?=e($m['content'])?></a></div>
    <?php else: ?>
    <div class="bub"><?=nl2br(e($m['content']))?></div>
    <?php endif; ?>
    <?php if(!$isSys): ?><div class="mt"><?=timeAgo($m['created_at'])?></div><?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
<?php if(empty($allMsgs)): ?>
<div style="text-align:center;margin:auto;color:var(--t3);font-size:.8rem">
  <i class="fas fa-comments" style="font-size:2rem;opacity:.1;display:block;margin-bottom:8px"></i>
  لا توجد رسائل بعد
</div>
<?php endif; ?>
</div>

<!-- INPUT BAR -->
<?php if($isActive): ?>
<div class="prev-bar" id="prevBar">
  <span id="prevName" style="flex:1"></span>
  <button onclick="clearPreview()" style="background:none;border:none;color:var(--t2);cursor:pointer"><i class="fas fa-times"></i></button>
</div>
<form class="ibar" method="POST" enctype="multipart/form-data" id="chatForm">
  <input type="hidden" name="_csrf" value="<?=csrf()?>">
  <input type="hidden" name="act" value="send">
  <input type="file" name="media" id="mediaInp" accept="image/*,video/*" style="display:none" onchange="previewMedia(this)">
  <div class="irow">
    <button type="button" class="ibtn" onclick="document.getElementById('mediaInp').click()">
      <i class="fas fa-paperclip"></i>
    </button>
    <textarea class="txta" name="content" id="msgTxta" placeholder="اكتب رسالة..." rows="1"
              onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();document.getElementById('chatForm').submit()}"
              oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"></textarea>
    <button type="submit" class="sbtn"><i class="fas fa-paper-plane"></i></button>
  </div>
</form>
<?php else: ?>
<div style="padding:14px;text-align:center;font-size:.78rem;color:var(--t2);background:var(--bg2);border-top:1px solid var(--b1)">
  <i class="fas fa-lock" style="color:var(--t3)"></i>
  <?=$isDone?'الغرفة مغلقة':'الغرفة غير نشطة'?>
</div>
<?php endif; ?>

</div><!-- end flex wrapper -->

<script>
var LAST_ID = <?=$lastId?>;
var ROOM_ID = <?=$rid?>;

// scroll to bottom
function scrollDown(){ var m=document.getElementById('msgs'); if(m) m.scrollTop=m.scrollHeight; }
scrollDown();

// render new messages
function renderMsg(m){
  var uid = <?=$uid?>;
  var isSys = m.message_type==='system';
  var isMe  = parseInt(m.sender_id)===uid;
  var isAdmMsg = parseInt(m.is_admin)===1;
  var cls   = isSys?'sys':(isMe?'me':(isAdmMsg?'adm':'them'));
  var av    = m.sender_name?m.sender_name[0].toUpperCase():'?';
  var avHtml= m.sender_pic?'<img src="'+m.sender_pic+'" style="width:100%;height:100%;object-fit:cover">':av;
  var bubStyle= isMe?'background:linear-gradient(135deg,var(--gold),var(--gold3));color:#06040a;border-bottom-right-radius:4px'
               :isAdmMsg?'background:linear-gradient(135deg,rgba(59,130,246,.1),rgba(139,92,246,.1));border:1px solid rgba(59,130,246,.2);color:var(--t1);border-bottom-left-radius:4px'
               :'background:var(--card2);border:1px solid var(--b2);color:var(--t1);border-bottom-left-radius:4px';
  var body='';
  if(isSys) body='<div class="sysbub">'+m.content.replace(/\n/g,'<br>')+'</div>';
  else if(m.message_type==='image') body='<div class="bub" style="padding:4px"><img src="'+m.image_path+'" class="msg-img" onclick="window.open(this.src)"></div>';
  else if(m.message_type==='link') body='<div class="bub" style="'+bubStyle+'"><a href="'+m.content+'" class="msg-link" target="_blank">'+m.content+'</a></div>';
  else body='<div class="bub" style="'+bubStyle+'">'+m.content.replace(/\n/g,'<br>')+'</div>';
  var nameTag = (!isMe&&!isSys)?('<div class="sn">'+m.sender_name+(isAdmMsg?'<span class="adm-tag">إدارة</span>':'')+'</div>'):'';
  var avTag   = (!isSys&&!isMe)?('<div class="av">'+avHtml+'</div>'):'';
  var html = '<div class="mw '+cls+'">'+(cls!=='sys'&&!isMe?avTag:'')+'<div>'+nameTag+body+'<div class="mt">الآن</div></div></div>';
  var c=document.getElementById('msgs');
  c.insertAdjacentHTML('beforeend',html);
}

// poll every 7s
function poll(){
  fetch('auction_deal.php?rid='+ROOM_ID+'&ajax=poll&last='+LAST_ID)
    .then(function(r){return r.json();}).then(function(d){
      if(!d.ok) return;
      d.messages.forEach(function(m){ renderMsg(m); LAST_ID=m.id; });
      if(d.messages.length) scrollDown();
      if(d.time_left){var t=document.getElementById('tdisplay');if(t)t.textContent='⏱ '+d.time_left;}
      if(d.status==='completed'&&!window._done){window._done=true;setTimeout(function(){location.reload();},2000);}
    }).catch(function(){});
}
setInterval(poll, 7000);

// media preview
function previewMedia(inp){
  var f=inp.files[0]; if(!f)return;
  var pb=document.getElementById('prevBar');
  pb.style.display='flex';
  document.getElementById('prevName').textContent='📎 '+f.name;
}
function clearPreview(){
  document.getElementById('mediaInp').value='';
  document.getElementById('prevBar').style.display='none';
}
</script>

<?php pageFoot(); ?>
