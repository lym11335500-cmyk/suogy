<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid   = uid();
$user  = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();
$kyc   = $pdo->prepare("SELECT * FROM kyc_documents WHERE user_id=? ORDER BY submitted_at DESC LIMIT 1");
$kyc->execute([$uid]);
$kyc = $kyc->fetch();

$msg = '';
$msgType = 'ok';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    if($user['kyc_status']==='approved'){
        $msg='هويتك موثقة مسبقاً';$msgType='info';
    } else {
        $fullName  = trim($_POST['full_name']??'');
        $idNum     = trim($_POST['id_number']??'');
        $dob       = $_POST['date_of_birth']??'';
        $address   = trim($_POST['address']??'');

        $errors=[];
        if(!$fullName) $errors[]='الاسم الكامل مطلوب';
        if(!$idNum)    $errors[]='رقم الهوية مطلوب';
        if(!$dob)      $errors[]='تاريخ الميلاد مطلوب';

        $idCardPath = null;
        $selfiePath = null;

        if(!empty($_FILES['id_card']['name'])){
            $idCardPath = uploadFile($_FILES['id_card'],'kyc');
            if(!$idCardPath) $errors[]='صورة الجواز غير صالحة (JPG/PNG/WEBP حتى 10MB)';
        } else {
            $errors[]='صورة الجواز أو بطاقة الهوية مطلوبة';
        }
        if(!empty($_FILES['selfie']['name'])){
            $selfiePath = uploadFile($_FILES['selfie'],'kyc');
            if(!$selfiePath) $errors[]='الصورة الشخصية غير صالحة';
        } else {
            $errors[]='الصورة الشخصية (selfie) مطلوبة';
        }

        if(empty($errors)){
            // Delete old KYC if rejected
            if($kyc) $pdo->prepare("DELETE FROM kyc_documents WHERE user_id=?")->execute([$uid]);

            addActivityLog($pdo,'kyc','طلب توثيق KYC جديد من المستخدم ID: '.$uid,$uid,'user');
            $pdo->prepare("INSERT INTO kyc_documents(user_id,id_card_image,selfie_image,full_name,id_number,date_of_birth,address)VALUES(?,?,?,?,?,?,?)")
                ->execute([$uid,$idCardPath,$selfiePath,$fullName,$idNum,$dob,$address]);

            $pdo->prepare("UPDATE users SET kyc_status='pending' WHERE id=?")->execute([$uid]);
            $user['kyc_status']='pending';

            // Notify admins
            $admins = $pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll();
            foreach($admins as $adm){
                addNotif($pdo,$adm['id'],'kyc_request','طلب تحقق جديد من '.e($user['username']),'../admin/kyc.php');
            }

            $msg='✅ تم رفع مستنداتك بنجاح — جاري المراجعة خلال 24 ساعة';
            $kyc = $pdo->prepare("SELECT * FROM kyc_documents WHERE user_id=? ORDER BY submitted_at DESC LIMIT 1");
            $kyc->execute([$uid]);
            $kyc = $kyc->fetch();
        } else {
            $msgType='err';
            $msg=implode('<br>',$errors);
        }
    }
}

pageHead('التحقق من الهوية KYC');
pageTopbar($pdo,'index.php','التحقق KYC');
?>
<div class="page" style="padding:16px 16px 90px">

<!-- STATUS BANNER -->
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:16px;margin-bottom:16px;display:flex;align-items:center;gap:14px">
  <div style="font-size:2rem">
    <?php
    $km=['approved'=>'✅','pending'=>'⏳','rejected'=>'❌'];
    echo isset($km[$user['kyc_status']])?$km[$user['kyc_status']]:'🪪';
    ?>
  </div>
  <div>
    <div style="font-weight:900;font-size:.95rem;margin-bottom:3px">حالة التحقق</div>
    <div><?=kycBadge($user['kyc_status'])?></div>
    <?php if($user['kyc_status']==='approved'): ?>
    <div style="font-size:.75rem;color:var(--txt2);margin-top:4px">يمكنك البيع والشراء بحرية 🎉</div>
    <?php elseif($user['kyc_status']==='pending'): ?>
    <div style="font-size:.75rem;color:var(--txt2);margin-top:4px">تتم مراجعة مستنداتك — خلال 24 ساعة</div>
    <?php elseif($user['kyc_status']==='rejected'): ?>
    <div style="font-size:.75rem;color:var(--red);margin-top:4px">
      <?=e($kyc['admin_notes']??'يُرجى إعادة رفع المستندات بصورة واضحة')?>
    </div>
    <?php else: ?>
    <div style="font-size:.75rem;color:var(--txt2);margin-top:4px">الرجاء إكمال التحقق للبيع والشراء</div>
    <?php endif; ?>
  </div>
</div>

<?php if($msg): echo '<div class="alert alert-'.$msgType.'"><i class="fas fa-'.($msgType==='ok'?'check-circle':'times-circle').'"></i><span>'.$msg.'</span></div>'; endif; ?>

<?php if(in_array($user['kyc_status'],['not_submitted','rejected'])): ?>

<!-- WHY KYC -->
<div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;margin-bottom:16px;font-size:.78rem;color:var(--txt2);line-height:1.7">
  <strong style="color:var(--gold);display:block;margin-bottom:4px"><i class="fas fa-info-circle"></i> لماذا نطلب التحقق؟</strong>
  نضمن أمان جميع المعاملات ونحمي البائعين والمشترين من الاحتيال. معلوماتك محفوظة بأمان ولا تُشارك مع أي طرف ثالث.
</div>

<form method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_csrf" value="<?=csrf()?>">

  <div class="card" style="margin-bottom:14px">
    <div class="card-hd"><i class="fas fa-id-card"></i> بيانات الهوية</div>

    <div class="fg">
      <label>الاسم الكامل (كما في الجواز)</label>
      <input type="text" name="full_name" class="fi" required placeholder="أحمد محمد علي" value="<?=e($kyc['full_name']??'')?>">
    </div>
    <div class="fg">
      <label>رقم الجواز / بطاقة الهوية</label>
      <input type="text" name="id_number" class="fi" required placeholder="A12345678" value="<?=e($kyc['id_number']??'')?>">
    </div>
    <div class="fg">
      <label>تاريخ الميلاد</label>
      <input type="date" name="date_of_birth" class="fi" required value="<?=e($kyc['date_of_birth']??'')?>">
    </div>
    <div class="fg">
      <label>العنوان</label>
      <textarea name="address" class="fta" rows="2" placeholder="المدينة، الدولة"><?=e($kyc['address']??'')?></textarea>
    </div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="card-hd"><i class="fas fa-camera"></i> الصور المطلوبة</div>

    <div class="fg">
      <label>صورة الجواز / بطاقة الهوية <span style="color:var(--red)">*</span></label>
      <div id="idDrop" onclick="document.getElementById('idFile').click()" style="border:2px dashed var(--border2);border-radius:var(--r2);padding:24px;text-align:center;cursor:pointer;transition:border .2s;background:var(--bg2)">
        <i class="fas fa-id-card" style="font-size:1.8rem;color:var(--txt3);margin-bottom:8px;display:block"></i>
        <div style="font-size:.8rem;color:var(--txt2)">اضغط لاختيار الصورة</div>
        <div id="idPreview" style="margin-top:10px"></div>
      </div>
      <input type="file" name="id_card" id="idFile" accept="image/*" required style="display:none" onchange="preview(this,'idPreview','idDrop')">
    </div>

    <div class="fg">
      <label>صورة شخصية (Selfie) مع إمساك الهوية <span style="color:var(--red)">*</span></label>
      <div id="selfDrop" onclick="document.getElementById('selfFile').click()" style="border:2px dashed var(--border2);border-radius:var(--r2);padding:24px;text-align:center;cursor:pointer;transition:border .2s;background:var(--bg2)">
        <i class="fas fa-user-circle" style="font-size:1.8rem;color:var(--txt3);margin-bottom:8px;display:block"></i>
        <div style="font-size:.8rem;color:var(--txt2)">صورة selfie واضحة مع وثيقة الهوية</div>
        <div id="selfPreview" style="margin-top:10px"></div>
      </div>
      <input type="file" name="selfie" id="selfFile" accept="image/*" required style="display:none" onchange="preview(this,'selfPreview','selfDrop')">
    </div>
  </div>

  <button type="submit" class="btn btn-gold btn-block">
    <i class="fas fa-paper-plane"></i> إرسال للمراجعة
  </button>
</form>

<?php elseif($user['kyc_status']==='pending' && $kyc): ?>
<div class="card">
  <div class="card-hd"><i class="fas fa-clock"></i> بياناتك المُرسلة</div>
  <div style="display:flex;flex-direction:column;gap:10px;font-size:.83rem">
    <div style="display:flex;justify-content:space-between"><span class="txt2">الاسم الكامل</span><span><?=e($kyc['full_name'])?></span></div>
    <div style="display:flex;justify-content:space-between"><span class="txt2">رقم الهوية</span><span class="mono"><?=e($kyc['id_number'])?></span></div>
    <div style="display:flex;justify-content:space-between"><span class="txt2">تاريخ الميلاد</span><span><?=e($kyc['date_of_birth'])?></span></div>
    <div style="display:flex;justify-content:space-between"><span class="txt2">أُرسل في</span><span><?=timeAgo($kyc['submitted_at'])?></span></div>
  </div>
  <?php if($kyc['id_card_image']): ?>
  <div class="divider"></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    <div><div style="font-size:.7rem;color:var(--txt2);margin-bottom:6px">صورة الهوية</div><img src="<?=e($kyc['id_card_image'])?>" style="width:100%;border-radius:var(--r3);border:1px solid var(--border)" alt=""></div>
    <div><div style="font-size:.7rem;color:var(--txt2);margin-bottom:6px">صورة Selfie</div><img src="<?=e($kyc['selfie_image']??'')?>" style="width:100%;border-radius:var(--r3);border:1px solid var(--border)" alt=""></div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if(isAdmin()): ?>
<a href="../admin/index.php" class="btn btn-gold btn-block" style="margin-top:16px">
  <i class="fas fa-cog"></i> الذهاب للوحة الأدمن
</a>
<?php else: ?>
<a href="index.php" class="btn btn-outline btn-block" style="margin-top:16px">
  <i class="fas fa-home"></i> العودة للصفحة الرئيسية
</a>
<?php endif; ?>

</div>

<script>
function preview(input, previewId, dropId){
  if(!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById(previewId).innerHTML = '<img src="'+e.target.result+'" style="max-height:120px;border-radius:8px;border:1px solid var(--border)">';
    document.getElementById(dropId).style.borderColor = 'var(--gold)';
  };
  reader.readAsDataURL(input.files[0]);
}
</script>
<?php pageFoot(); ?>
