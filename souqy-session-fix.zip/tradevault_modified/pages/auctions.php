<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
require_once '../includes/auction_helpers.php';

requireLogin(); // 🔒 حماية — يجب تسجيل الدخول أولاً

try { settleExpiredAuctions($pdo); } catch(Exception $e){}

$uid    = uid();
$sort   = $_GET['sort'] ?? 'newest';
$myOnly = isset($_GET['my']) && $uid;

$orderMap = [
    'newest'  => 'a.created_at DESC',
    'ending'  => 'a.end_date ASC',
    'highest' => 'a.current_price DESC',
    'lowest'  => 'a.current_price ASC',
    'popular' => 'a.views DESC',
];
$orderBy = $orderMap[$sort] ?? 'a.created_at DESC';

$auctions = [];
try {
    $where  = "a.status='active'";
    $params = [];
    if ($myOnly && $uid) { $where .= " AND a.seller_id=?"; $params[] = $uid; }
    $st = $pdo->prepare("
        SELECT a.*, u.username seller_name,
            (SELECT COUNT(*) FROM bids b WHERE b.auction_id=a.id) AS bid_count
        FROM auctions a
        JOIN users u ON u.id=a.seller_id
        WHERE $where
        ORDER BY $orderBy
        LIMIT 40
    ");
    $st->execute($params);
    $auctions = $st->fetchAll();
} catch(Exception $e){ $auctions = []; }

pageHead('المزادات', '<style>
.sort-bar{display:flex;gap:6px;overflow-x:auto;padding:0 0 4px;scrollbar-width:none;margin-bottom:14px}
.sort-bar::-webkit-scrollbar{display:none}
.sort-chip{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;border-radius:20px;font-size:.72rem;font-weight:700;white-space:nowrap;border:1px solid var(--b2);background:var(--card);color:var(--t2);cursor:pointer;text-decoration:none;transition:.18s}
.sort-chip.active{background:var(--goldf);border-color:var(--gold);color:var(--gold)}
.ac{background:var(--card);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:0;display:flex;flex-direction:column;transition:.18s;text-decoration:none;color:var(--t1)}
.ac:hover{border-color:var(--b3);transform:translateY(-1px);box-shadow:0 8px 24px rgba(0,0,0,.3)}
.ac-img{width:100%;height:150px;object-fit:cover;background:var(--bg3);display:flex;align-items:center;justify-content:center;color:var(--t3);font-size:2rem}
.ac-img img{width:100%;height:150px;object-fit:cover;display:block}
.ac-body{padding:10px 12px;flex:1;display:flex;flex-direction:column;gap:4px}
.ac-title{font-weight:800;font-size:.82rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ac-price{font-size:1.1rem;font-weight:900;color:var(--gold);font-family:"JetBrains Mono",monospace}
.ac-meta{display:flex;justify-content:space-between;align-items:center;margin-top:2px}
.ac-timer{font-size:.65rem;font-weight:700;display:flex;align-items:center;gap:3px}
.ac-bids{font-size:.62rem;color:var(--t2)}
.empty-box{text-align:center;padding:60px 20px;color:var(--t2)}
.empty-box i{font-size:3rem;opacity:.12;display:block;margin-bottom:12px}
</style>');
pageTopbar($pdo, '', 'المزادات');
?>
<div class="page" style="padding:14px 14px 90px">

<div class="sort-bar">
<?php
$sorts = [['newest','🆕 الأحدث'],['ending','⏳ ينتهي قريباً'],['highest','🔥 الأعلى'],['lowest','💰 الأقل'],['popular','👁 الأكثر']];
if($uid) $sorts[] = ['my','👤 مزاداتي'];
foreach($sorts as [$k,$l]):
    $active = ($myOnly && $k==='my') || (!$myOnly && $sort===$k);
    $href   = $k==='my' ? '?my=1' : '?sort='.$k;
?>
  <a href="<?=$href?>" class="sort-chip <?=$active?'active':''?>"><?=$l?></a>
<?php endforeach; ?>
</div>

<?php if(empty($auctions)): ?>
<div class="empty-box">
  <i class="fas fa-gavel"></i>
  لا توجد مزادات نشطة الآن
  <?php if($uid): ?>
  <br><br><a href="create_auction.php" class="btn btn-gold" style="display:inline-flex">
    <i class="fas fa-plus"></i> أنشئ أول مزاد
  </a>
  <?php endif; ?>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
<?php foreach($auctions as $a):
  $endTs  = strtotime($a['end_date']) * 1000;
  $urgent = (strtotime($a['end_date']) - time()) < 86400;
?>
<a href="auction.php?id=<?=$a['id']?>" class="ac">
  <div class="ac-img">
    <?php if($a['image_path']): ?>
      <img src="<?=e(assetUrl($a['image_path']))?>" alt="" loading="lazy">
    <?php else: ?>
      <i class="fas fa-gavel"></i>
    <?php endif; ?>
  </div>
  <div class="ac-body">
    <div class="ac-title"><?=e($a['title'])?></div>
    <div class="ac-price"><?=money((float)$a['current_price'])?></div>
    <div class="ac-meta">
      <div class="ac-timer" style="color:<?=$urgent?'var(--red)':'var(--t2)'?>">
        <i class="fas fa-clock" style="font-size:.55rem"></i>
        <span class="acd" data-end="<?=$endTs?>"><?=auctionTimeLeft($a['end_date'])?></span>
      </div>
      <div class="ac-bids"><?=$a['bid_count']?> مزايدة</div>
    </div>
  </div>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if($uid): ?>
<a href="create_auction.php" style="position:fixed;bottom:72px;left:16px;z-index:200;width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold3));display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(232,164,0,.4);text-decoration:none">
  <i class="fas fa-plus" style="color:#000;font-size:1.1rem"></i>
</a>
<?php endif; ?>
</div>

<script>
(function(){
  function fmt(ms){
    var s=Math.max(0,Math.floor(ms/1000));
    var d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60),sc=s%60;
    if(d>0)return d+'ي '+h+'س'; if(h>0)return h+'س '+m+'د'; if(m>0)return m+'د '+sc+'ث'; return sc+'ث';
  }
  function tick(){
    document.querySelectorAll('.acd').forEach(function(el){
      var e=parseInt(el.dataset.end),diff=e-Date.now();
      el.textContent=fmt(diff);
      el.closest('.ac-timer').style.color=diff<86400000?'var(--red)':'var(--t2)';
    });
  }
  tick(); setInterval(tick,7000);
})();
</script>
<?php pageBottomNav('auctions'); pageFoot(); ?>
