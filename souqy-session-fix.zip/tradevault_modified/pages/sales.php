<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$uid=uid();

$sales=$pdo->prepare("
    SELECT p.*,l.title listing_title,l.id listing_id,
           b.username buyer_name,b.profile_pic buyer_pic,
           c.status chat_status,c.expires_at
    FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id
    JOIN chats c ON c.purchase_id=p.id
    WHERE p.seller_id=?
    ORDER BY p.created_at DESC
");
$sales->execute([$uid]);
$sales=$sales->fetchAll();

pageHead('مبيعاتي');
pageTopbar($pdo,'index.php','مبيعاتي');
?>
<div class="page" style="padding:16px 16px 90px">

<?php if(empty($sales)): ?>
<div class="empty fade-up">
  <i class="fas fa-store"></i>
  <p>لم تبيع شيئاً بعد<br><a href="sell.php" class="gold" style="text-decoration:none">انشر إعلانك الأول →</a></p>
</div>
<?php else: ?>

<div style="font-size:.78rem;color:var(--txt2);margin-bottom:12px"><?=count($sales)?> عملية بيع</div>

<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach($sales as $s):
  $timeLeft=max(0,strtotime($s['expires_at'])-time());
  $expired=$timeLeft<=0 && $s['chat_status']==='active';
  $nc=['completed'=>'var(--green)','refunded'=>'var(--blue)','disputed'=>'var(--red)'];
  $netColor=isset($nc[$s['status']])?$nc[$s['status']]:'var(--txt2)';
?>
<a href="deal.php?pid=<?=$s['id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:14px;display:flex;gap:12px;align-items:flex-start;text-decoration:none;color:var(--txt);transition:all .2s;<?=$s['status']==='held'?'border-color:var(--gold3)':''?>">
  <div style="width:44px;height:44px;border-radius:var(--r2);background:var(--bg3);display:flex;align-items:center;justify-content:center;color:var(--txt3);flex-shrink:0;border:1px solid var(--border2)">
    <?php if($s['buyer_pic']): ?><img src="<?=e(assetUrl($s['buyer_pic']))?>" style="width:100%;height:100%;object-fit:cover;border-radius:var(--r2)" alt="">
    <?php else: ?><i class="fas fa-user"></i><?php endif; ?>
  </div>
  <div style="flex:1;min-width:0">
    <div style="font-weight:700;font-size:.88rem;margin-bottom:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($s['listing_title'])?></div>
    <div style="font-size:.72rem;color:var(--txt2);margin-bottom:6px">اشترى من: <?=e($s['buyer_name'])?></div>
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <div>
        <span class="mono" style="font-size:.9rem;font-weight:700;color:<?=$netColor?>"><?=money((float)$s['seller_net'])?></span>
        <span style="font-size:.65rem;color:var(--txt3);margin-right:4px">(بعد العمولة)</span>
      </div>
      <span class="tag tag-<?=$s['status']?>"><?=statusLabel($s['status'])?></span>
      <?php if($expired): ?><span class="badge badge-err" style="font-size:.6rem">انتهت المهلة</span><?php endif; ?>
    </div>
    <?php if($s['status']==='held'): ?>
    <div style="margin-top:6px;font-size:.7rem;color:var(--txt2)">
      السعر: <?=money((float)$s['amount'])?> · عمولة: <?=money((float)$s['commission'])?>
    </div>
    <?php if(!$expired): ?>
    <div style="font-size:.7rem;color:var(--gold);margin-top:3px"><i class="fas fa-clock"></i> متبقي: <?=floor($timeLeft/3600)?>س <?=floor(($timeLeft%3600)/60)?>د</div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if($s['status']==='completed'): ?>
    <div style="margin-top:6px;font-size:.7rem;color:var(--green)"><i class="fas fa-check-double"></i> اكتملت <?=timeAgo($s['completed_at']??$s['created_at'])?></div>
    <?php endif; ?>
  </div>
  <i class="fas fa-chevron-left" style="color:var(--txt3);flex-shrink:0;margin-top:4px"></i>
</a>
<?php endforeach; ?>
</div>

<!-- SUMMARY -->
<?php
$completedSales=array_filter($sales,function($s){return $s['status']==='completed';});
$totalNet=array_sum(array_column(iterator_to_array((function() use($sales){ foreach($sales as $s) if($s['status']==='completed') yield $s; })()),'seller_net'));
$totalNet2=0;foreach($sales as $s){if($s['status']==='completed') $totalNet2+=$s['seller_net'];}
?>
<div style="margin-top:16px;background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:14px">
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center">
    <div><div class="stat-val" style="font-size:1rem"><?=count($sales)?></div><div class="stat-lbl">إجمالي</div></div>
    <div><div class="stat-val" style="font-size:1rem;color:var(--green)"><?=count($completedSales)?></div><div class="stat-lbl">مكتملة</div></div>
    <div><div class="stat-val" style="font-size:1rem;color:var(--green)"><?=money($totalNet2)?></div><div class="stat-lbl">أرباح صافية</div></div>
  </div>
</div>

<?php endif; ?>
</div>
<?php pageBottomNav('dashboard.php'); pageFoot(); ?>
