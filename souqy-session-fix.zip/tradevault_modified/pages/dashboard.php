<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$uid  = uid();
$user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

// Delete listing action
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act = $_POST['act']??'';
    if($act==='delete_listing'){
        $lid=(int)($_POST['lid']??0);
        $pdo->prepare("DELETE FROM listings WHERE id=? AND user_id=? AND status='active'")->execute([$lid,$uid]);
        header('Location:dashboard.php'); exit;
    }
}

// My listings
$myListings = $pdo->prepare("SELECT l.*,c.name cat_name,c.icon cat_icon FROM listings l JOIN categories c ON l.category_id=c.id WHERE l.user_id=? ORDER BY l.created_at DESC LIMIT 20");
$myListings->execute([$uid]);
$myListings = $myListings->fetchAll();

// My purchases
$myPurchases = $pdo->prepare("SELECT p.*,l.title listing_title,s.username seller_name FROM purchases p JOIN listings l ON p.listing_id=l.id JOIN users s ON p.seller_id=s.id WHERE p.buyer_id=? ORDER BY p.created_at DESC LIMIT 10");
$myPurchases->execute([$uid]);
$myPurchases = $myPurchases->fetchAll();

// My sales
$mySales = $pdo->prepare("SELECT p.*,l.title listing_title,b.username buyer_name FROM purchases p JOIN listings l ON p.listing_id=l.id JOIN users b ON p.buyer_id=b.id WHERE p.seller_id=? ORDER BY p.created_at DESC LIMIT 10");
$mySales->execute([$uid]);
$mySales = $mySales->fetchAll();

$tab = $_GET['tab']??'listings';

pageHead('لوحة التحكم');
pageTopbar($pdo,'index.php','لوحتي');
?>
<div class="page" style="padding:16px 16px 90px">

<!-- USER HERO -->
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:16px;margin-bottom:16px;display:flex;gap:14px;align-items:center">
  <div class="user-chip-av" style="width:56px;height:56px;border-radius:var(--r2);font-size:1.3rem;border:2px solid var(--gold3);flex-shrink:0">
    <?php if($user['profile_pic']): ?><img src="<?=e(assetUrl($user['profile_pic']))?>" alt="">
    <?php else: ?><?=strtoupper(mb_substr($user['username'],0,1,'UTF-8'))?><?php endif; ?>
  </div>
  <div style="flex:1;min-width:0">
    <div style="font-weight:900;font-size:1rem;margin-bottom:3px"><?=e($user['username'])?></div>
    <div style="margin-bottom:6px"><?=kycBadge($user['kyc_status'])?></div>
    <div style="font-size:.72rem;color:var(--txt2);display:flex;gap:12px">
      <span><span class="gold">★</span> <?=$user['seller_rating']?> بائع</span>
      <span><span class="gold">◆</span> <?=$user['buyer_rating']?> مشترٍ</span>
      <span><?=$user['total_sales']?> بيع · <?=$user['total_purchases']?> شراء</span>
    </div>
  </div>
  <a href="profile.php" class="icon-btn"><i class="fas fa-edit"></i></a>
</div>

<!-- BALANCE STRIP -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
  <div class="stat-box">
    <div class="stat-val"><?=money((float)$user['balance'])?></div>
    <div class="stat-lbl">الرصيد</div>
  </div>
  <div class="stat-box">
    <div class="stat-val" style="color:var(--txt2)"><?=money((float)$user['held_balance'])?></div>
    <div class="stat-lbl">محجوز</div>
  </div>
  <a href="wallet.php" class="stat-box" style="text-decoration:none;border-color:var(--gold3)">
    <div class="stat-val" style="font-size:.9rem"><i class="fas fa-wallet"></i></div>
    <div class="stat-lbl" style="color:var(--gold)">المحفظة</div>
  </a>
</div>

<!-- KYC ALERT -->
<?php if($user['kyc_status']!=='approved'): ?>
<a href="kyc.php" style="background:var(--bg3);border:1px solid var(--gold3);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:10px;text-decoration:none;margin-bottom:14px">
  <i class="fas fa-id-card" style="color:var(--gold);font-size:1.2rem"></i>
  <div style="flex:1">
    <div style="font-weight:700;font-size:.85rem;color:var(--gold)">أكمل التحقق من هويتك</div>
    <div style="font-size:.72rem;color:var(--txt2)">مطلوب للبيع والشراء</div>
  </div>
  <i class="fas fa-chevron-left" style="color:var(--txt3)"></i>
</a>
<?php endif; ?>

<!-- TABS -->
<div style="display:flex;background:var(--bg2);border-radius:var(--r2);padding:4px;gap:4px;margin-bottom:14px">
  <?php foreach(['listings'=>['fa-list','إعلاناتي'],'purchases'=>['fa-shopping-cart','مشترياتي'],'sales'=>['fa-store','مبيعاتي']] as $t=>[$ic,$lbl]): ?>
  <a href="?tab=<?=$t?>" style="flex:1;text-align:center;padding:9px 6px;border-radius:var(--r3);font-size:.78rem;font-weight:700;text-decoration:none;background:<?=$tab===$t?'var(--card)':'transparent'?>;color:<?=$tab===$t?'var(--gold)':'var(--txt3)'>; border:<?=$tab===$t?'1px solid var(--border2)':'1px solid transparent'?>;transition:all .2s">
    <i class="fas <?=$ic?>" style="display:block;margin-bottom:3px"></i><?=$lbl?>
  </a>
  <?php endforeach; ?>
</div>

<!-- TAB CONTENT -->
<?php if($tab==='listings'): ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
  <div style="font-size:.78rem;color:var(--txt2)"><?=count($myListings)?> إعلان</div>
  <a href="sell.php" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إعلان جديد</a>
</div>
<?php if(empty($myListings)): ?>
<div class="empty"><i class="fas fa-box-open"></i><p>لا توجد إعلانات — انشر أول إعلان!</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($myListings as $l): ?>
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;gap:10px;align-items:center">
  <?php $thumb=getListingThumb($pdo,(int)$l['id']); ?>
  <div style="width:48px;height:48px;border-radius:var(--r3);overflow:hidden;flex-shrink:0;background:var(--bg3)">
    <?php if($thumb): ?><img src="<?=e($thumb)?>" style="width:100%;height:100%;object-fit:cover" alt="">
    <?php else: ?><div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--txt3)"><i class="fas fa-image"></i></div><?php endif; ?>
  </div>
  <div style="flex:1;min-width:0">
    <div style="font-size:.85rem;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($l['title'])?></div>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:2px"><?=money((float)$l['price'])?> · <span class="tag tag-<?=$l['status']?>"><?=statusLabel($l['status'])?></span></div>
    <div style="font-size:.65rem;color:var(--txt3);margin-top:3px"><?=$l['views']?> مشاهدة · <?=timeAgo($l['created_at'])?></div>
  </div>
  <div style="display:flex;gap:6px;flex-shrink:0">
    <a href="sell.php?edit=<?=$l['id']?>" class="icon-btn btn-sm" style="width:32px;height:32px;border-radius:var(--r3)"><i class="fas fa-edit"></i></a>
    <?php if($l['status']==='active'): ?>
    <form method="POST" onsubmit="return confirm('حذف الإعلان؟')">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="delete_listing">
      <input type="hidden" name="lid" value="<?=$l['id']?>">
      <button type="submit" class="icon-btn" style="width:32px;height:32px;border-radius:var(--r3);color:var(--red);border-color:#ef444422"><i class="fas fa-trash"></i></button>
    </form>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php elseif($tab==='purchases'): ?>
<?php if(empty($myPurchases)): ?>
<div class="empty"><i class="fas fa-shopping-cart"></i><p>لم تشترِ شيئاً بعد</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($myPurchases as $p): ?>
<a href="deal.php?pid=<?=$p['id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;justify-content:space-between;align-items:center;text-decoration:none;color:var(--txt)">
  <div>
    <div style="font-size:.85rem;font-weight:700;margin-bottom:3px"><?=e(mb_substr($p['listing_title'],0,35,'UTF-8'))?></div>
    <div style="font-size:.7rem;color:var(--txt2)">من <?=e($p['seller_name'])?> · <?=timeAgo($p['created_at'])?></div>
  </div>
  <div style="text-align:center">
    <div class="mono gold"><?=money((float)$p['amount'])?></div>
    <span class="tag tag-<?=$p['status']?>"><?=statusLabel($p['status'])?></span>
  </div>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php elseif($tab==='sales'): ?>
<?php if(empty($mySales)): ?>
<div class="empty"><i class="fas fa-store"></i><p>لم تبيع شيئاً بعد<br>انشر إعلانك الأول!</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($mySales as $p): ?>
<a href="deal.php?pid=<?=$p['id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;justify-content:space-between;align-items:center;text-decoration:none;color:var(--txt)">
  <div>
    <div style="font-size:.85rem;font-weight:700;margin-bottom:3px"><?=e(mb_substr($p['listing_title'],0,35,'UTF-8'))?></div>
    <div style="font-size:.7rem;color:var(--txt2)">لـ <?=e($p['buyer_name'])?> · <?=timeAgo($p['created_at'])?></div>
  </div>
  <div style="text-align:center">
    <div class="mono green"><?=money((float)$p['seller_net'])?></div>
    <span class="tag tag-<?=$p['status']?>"><?=statusLabel($p['status'])?></span>
  </div>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php endif; ?>

</div>
<?php pageBottomNav('dashboard.php'); pageFoot(); ?>
