<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
require_once '../includes/auction_helpers.php';
requireLogin();

$uid  = uid();
$user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

$msg=''; $msgType='ok';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $title      = trim($_POST['title']??'');
    $desc       = trim($_POST['description']??'');
    $startPrice = (float)str_replace(',','',$_POST['start_price']??0);

    $errors = [];
    if(mb_strlen($title)<3)   $errors[]='العنوان قصير جداً (3 أحرف على الأقل)';
    if($startPrice<=0)        $errors[]='سعر البداية يجب أن يكون أكبر من صفر';

    $imgPath = null;
    if(!empty($_FILES['image']['name']) && $_FILES['image']['error']===UPLOAD_ERR_OK){
        $up = uploadFile($_FILES['image'],'listings');
        if($up) $imgPath=$up; else $errors[]='صورة غير صالحة';
    }

    if(empty($errors)){
        try {
            $startDate = date('Y-m-d H:i:s');
            $endDate   = date('Y-m-d H:i:s', strtotime('+7 days'));
            $minInc    = (float)getSetting($pdo,'auction_min_increment','1');
            $pdo->prepare("INSERT INTO auctions (seller_id,title,description,image_path,start_price,current_price,min_increment,start_date,end_date,status)
                VALUES (?,?,?,?,?,?,?,?,?,'active')")
                ->execute([$uid,$title,$desc,$imgPath,$startPrice,$startPrice,$minInc,$startDate,$endDate]);
            $newId = (int)$pdo->lastInsertId();
            addActivityLog($pdo,'auction','إنشاء مزاد: '.$title,$uid,'user');
            header('Location:auction.php?id='.$newId.'&created=1'); exit;
        } catch(Exception $e){
            $msg = 'حدث خطأ أثناء الحفظ — تأكد من تشغيل auction_migration.sql أولاً'; $msgType='err';
        }
    } else {
        $msg = implode(' · ', $errors); $msgType='err';
    }
}

pageHead('إنشاء مزاد');
pageTopbar($pdo,'auctions.php','إنشاء مزاد جديد');
?>
<div class="page" style="padding:14px 14px 90px">
<?php if($msg) echo flash($msgType,$msg); ?>

<form method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_csrf" value="<?=csrf()?>">

  <!-- Image upload -->
  <label for="imgUp" style="display:block;cursor:pointer">
    <div id="imgPreview" style="width:100%;height:180px;background:var(--card);border:2px dashed var(--b2);border-radius:var(--r2);display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--t2);margin-bottom:14px;transition:.18s;overflow:hidden">
      <i class="fas fa-image" style="font-size:2rem;margin-bottom:8px;opacity:.3"></i>
      <span style="font-size:.78rem">اضغط لإضافة صورة (اختياري)</span>
    </div>
  </label>
  <input type="file" name="image" id="imgUp" accept="image/*" style="display:none" onchange="previewImg(this)">

  <div class="fg">
    <label>عنوان المزاد *</label>
    <input type="text" name="title" class="fi" placeholder="مثال: آيفون 15 برو ماكس مستعمل" maxlength="200" required>
  </div>

  <div class="fg">
    <label>الوصف</label>
    <textarea name="description" class="fi" rows="4" placeholder="اكتب تفاصيل المنتج، حالته، المواصفات..." style="resize:none;min-height:100px"></textarea>
  </div>

  <div class="fg">
    <label>سعر البداية (USDT) *</label>
    <input type="number" name="start_price" class="fi" placeholder="0.00" min="0.01" step="0.01" required style="direction:ltr;text-align:center;font-family:'JetBrains Mono',monospace;font-weight:700;font-size:1.1rem">
  </div>

  <div style="background:rgba(232,164,0,.06);border:1px solid rgba(232,164,0,.18);border-radius:var(--r3);padding:12px;margin-bottom:14px;font-size:.72rem;color:var(--t2)">
    <i class="fas fa-info-circle" style="color:var(--gold)"></i>
    مدة المزاد <strong style="color:var(--t1)">7 أيام ثابتة</strong> من تاريخ النشر ·
    عمولة الموقع <strong style="color:var(--gold)"><?=getSetting($pdo,'auction_commission_rate','5')?>%</strong> من سعر البيع النهائي
  </div>

  <button type="submit" class="btn btn-gold btn-block">
    <i class="fas fa-gavel"></i> نشر المزاد الآن
  </button>
</form>

</div>

<script>
function previewImg(input){
  var file=input.files[0];
  if(!file)return;
  var r=new FileReader();
  r.onload=function(e){
    var p=document.getElementById('imgPreview');
    p.innerHTML='<img src="'+e.target.result+'" style="width:100%;height:180px;object-fit:cover">';
  };
  r.readAsDataURL(file);
}
</script>

<?php pageBottomNav(); pageFoot(); ?>
