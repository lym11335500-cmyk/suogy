<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
require_once '../includes/referral_helpers.php';
if(isLoggedIn()){ header('Location:dashboard.php'); exit; }

// ── حفظ كود الإحالة في الجلسة (لأن متصفحات واتساب/تيليغرام قد تفقد GET params)
$refCode = trim($_GET['ref'] ?? $_POST['ref_code'] ?? $_SESSION['pending_ref'] ?? '');
if (!empty($_GET['ref'])) {
    $_SESSION['pending_ref'] = $_GET['ref']; // حفظ احتياطي في الجلسة
}

$arabicCountries = [
    ['+20','🇪🇬','مصر'],['+966','🇸🇦','السعودية'],['+971','🇦🇪','الإمارات'],
    ['+962','🇯🇴','الأردن'],['+961','🇱🇧','لبنان'],['+963','🇸🇾','سوريا'],
    ['+964','🇮🇶','العراق'],['+212','🇲🇦','المغرب'],['+216','🇹🇳','تونس'],
    ['+213','🇩🇿','الجزائر'],['+218','🇱🇾','ليبيا'],['+249','🇸🇩','السودان'],
    ['+967','🇾🇲','اليمن'],['+968','🇴🇲','عُمان'],['+965','🇰🇼','الكويت'],
    ['+974','🇶🇦','قطر'],['+973','🇧🇭','البحرين'],['+970','🇵🇸','فلسطين'],
    ['+252','🇸🇴','الصومال'],['+222','🇲🇷','موريتانيا'],['+253','🇩🇯','جيبوتي'],
    ['+269','🇰🇲','جزر القمر'],
];
$allowedCodes = array_column($arabicCountries,0);

$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $un=trim($_POST['username']??'');
    $em=trim($_POST['email']??'');
    $pw=$_POST['password']??'';
    $phone=trim($_POST['phone']??'');
    $code=trim($_POST['country_code']??'+20');
    $flag=trim($_POST['country_flag']??'🇪🇬');
    $refCode=trim($_POST['ref_code']??$refCode);
    if(mb_strlen($un)<3||mb_strlen($un)>50) $errors[]='اسم المستخدم بين 3 و50 حرفاً';
    if(!filter_var($em,FILTER_VALIDATE_EMAIL)) $errors[]='بريد إلكتروني غير صحيح';
    if(strlen($pw)<6) $errors[]='كلمة المرور 6 أحرف على الأقل';
    if(!$phone) $errors[]='رقم الهاتف مطلوب';
    if(!preg_match('/^[a-zA-Z0-9_]+$/u',$un)) $errors[]='اسم المستخدم: أحرف إنجليزية وأرقام وشرطة سفلية فقط';
    if(!in_array($code,$allowedCodes)) $errors[]='يُرجى اختيار رقم هاتف عربي فقط';
    if(empty($errors)){
        $chk=$pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $chk->execute([$un,$em]);
        if($chk->fetch()) $errors[]='اسم المستخدم أو البريد مستخدم مسبقاً';
        else {
            $uniqueId = generateUniqueId($pdo);
            $pdo->prepare("INSERT INTO users(unique_id,username,email,password,phone,phone_country_code,phone_country_flag)VALUES(?,?,?,?,?,?,?)")
                ->execute([$uniqueId,$un,$em,hashPassword($pw),$phone,$code,$flag]);
            $newId=(int)$pdo->lastInsertId();
            // معالجة الإحالة إذا كان هناك كود
            if($refCode) registerReferral($pdo, $newId, $refCode);
            unset($_SESSION['pending_ref']);
            session_regenerate_id(false);
            $_SESSION['uid']       = $newId;
            $_SESSION['username']  = $un;
            $_SESSION['is_admin']  = 0;
            $_SESSION['_db_check'] = time();
            session_write_close();
            addActivityLog($pdo,'user','تسجيل مستخدم جديد: '.$un,$newId,'user');
            header('Location: index.php', true, 302); exit;
        }
    }
}
$siteName = getSiteName($pdo);
$errorsJson = json_encode(array_values($errors));
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#060810">
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link rel="shortcut icon" href="../assets/img/favicon.svg">
<title>إنشاء حساب — <?=e($siteName)?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{min-height:100vh;background:#060810;color:#f0f3ff;font-family:'Tajawal',sans-serif;direction:rtl;overflow-x:hidden}
body{display:flex;align-items:stretch;justify-content:center;position:relative}

.noise{position:fixed;inset:0;z-index:0;opacity:.025;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");background-size:200px;pointer-events:none}

.glow-orb{position:fixed;border-radius:50%;filter:blur(80px);pointer-events:none;z-index:0}
.orb1{width:500px;height:500px;background:radial-gradient(circle,rgba(232,164,0,0.08),transparent 70%);top:-150px;right:-100px;animation:orbFloat 12s ease-in-out infinite}
.orb2{width:400px;height:400px;background:radial-gradient(circle,rgba(74,143,245,0.05),transparent 70%);bottom:-100px;left:-80px;animation:orbFloat 15s ease-in-out infinite reverse}
.orb3{width:300px;height:300px;background:radial-gradient(circle,rgba(168,85,247,0.04),transparent 70%);top:50%;left:50%;transform:translate(-50%,-50%);animation:orbFloat 10s ease-in-out infinite 3s}
@keyframes orbFloat{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-30px)}}

.grid-bg{position:fixed;inset:0;z-index:0;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:60px 60px;mask-image:radial-gradient(ellipse 80% 80% at 50% 50%,black,transparent)}

.wrap{position:relative;z-index:1;width:100%;max-width:450px;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px 18px 48px}

.logo-row{display:flex;align-items:center;gap:10px;margin-bottom:28px;animation:fadeSlideDown .6s cubic-bezier(.22,1,.36,1) both}
.logo-gem{width:42px;height:42px;border-radius:13px;background:linear-gradient(135deg,#e8a400,#b87d00);display:flex;align-items:center;justify-content:center;font-size:1.15rem;box-shadow:0 4px 20px rgba(232,164,0,.4),inset 0 1px 0 rgba(255,255,255,.2)}
.logo-name{font-size:1.25rem;font-weight:900;letter-spacing:-.4px}
.logo-name em{color:#e8a400;font-style:normal}

.card{width:100%;background:linear-gradient(155deg,rgba(255,255,255,.05) 0%,rgba(255,255,255,.02) 100%);border:1px solid rgba(255,255,255,.08);border-top:1px solid rgba(255,255,255,.12);border-radius:22px;padding:26px 22px;backdrop-filter:blur(24px);box-shadow:0 30px 70px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.06);animation:fadeSlideUp .65s cubic-bezier(.22,1,.36,1) .12s both}

@keyframes fadeSlideDown{from{opacity:0;transform:translateY(-18px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeSlideUp{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}

.head{text-align:center;margin-bottom:22px}
.head-icon{width:56px;height:56px;border-radius:17px;margin:0 auto 12px;background:linear-gradient(135deg,rgba(232,164,0,.18),rgba(232,164,0,.04));border:1px solid rgba(232,164,0,.22);display:flex;align-items:center;justify-content:center;font-size:1.5rem;animation:iconPulse 3s ease-in-out infinite}
@keyframes iconPulse{0%,100%{box-shadow:0 0 0 0 rgba(232,164,0,.2)}60%{box-shadow:0 0 0 10px rgba(232,164,0,0)}}
.head h1{font-size:1.22rem;font-weight:900;margin-bottom:5px}
.head p{font-size:.78rem;color:#8b95b5;line-height:1.55}

.feats{display:flex;justify-content:center;gap:18px;margin-bottom:18px;flex-wrap:wrap}
.feat{display:flex;align-items:center;gap:5px;font-size:.69rem;color:#3d4868}
.feat i{color:#10d97a;font-size:.62rem}

.errs{background:rgba(255,71,87,.08);border:1px solid rgba(255,71,87,.18);border-radius:12px;padding:12px 14px;margin-bottom:16px}
.errs-title{display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:800;color:#ff8591;margin-bottom:7px}
.errs ul{margin-right:12px}
.errs li{font-size:.78rem;color:#ff8591;margin-bottom:3px;list-style:disc}

.fg{margin-bottom:14px}
.fg label{display:flex;align-items:center;gap:7px;font-size:.76rem;font-weight:700;color:#8b95b5;margin-bottom:6px;letter-spacing:.2px}
.fg label i{font-size:.66rem;color:#e8a400;opacity:.85}
.fi{width:100%;padding:12px 14px;background:rgba(255,255,255,.035);border:1.5px solid rgba(255,255,255,.07);border-radius:11px;color:#f0f3ff;font-size:.88rem;font-family:'Tajawal',sans-serif;transition:all .2s ease;outline:none;-webkit-appearance:none}
.fi::placeholder{color:#3d4868}
.fi:focus{border-color:#e8a400;background:rgba(232,164,0,.035);box-shadow:0 0 0 3px rgba(232,164,0,.09)}
.fi.err{border-color:#ff4757;background:rgba(255,71,87,.04)}
.fi.ok{border-color:#10d97a}
.hint{font-size:.68rem;color:#3d4868;margin-top:4px}

.phone-row{display:flex;gap:8px}
.fsel{padding:12px 10px;background:rgba(255,255,255,.035);border:1.5px solid rgba(255,255,255,.07);border-radius:11px;color:#f0f3ff;font-size:.8rem;font-family:'Tajawal',sans-serif;outline:none;cursor:pointer;transition:all .2s;-webkit-appearance:none;max-width:120px}
.fsel:focus{border-color:#e8a400}

.pw-wrap{position:relative}
.pw-wrap .fi{padding-left:44px}
.pw-eye{position:absolute;left:13px;top:50%;transform:translateY(-50%);background:none;border:none;color:#3d4868;cursor:pointer;font-size:.88rem;transition:color .2s;padding:4px}
.pw-eye:hover{color:#8b95b5}

.strength{margin-top:7px;display:none}
.strength-track{height:3px;background:rgba(255,255,255,.07);border-radius:2px;overflow:hidden}
.strength-bar{height:100%;width:0%;border-radius:2px;transition:width .4s ease,background .3s ease}
.strength-lbl{font-size:.67rem;margin-top:4px;transition:color .3s}

.btn-submit{width:100%;padding:14px;border-radius:13px;border:none;background:linear-gradient(135deg,#e8a400,#b87d00);color:#000;font-size:.93rem;font-weight:900;font-family:'Tajawal',sans-serif;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .25s ease;margin-top:6px;box-shadow:0 6px 22px rgba(232,164,0,.28);letter-spacing:.2px;position:relative;overflow:hidden}
.btn-submit::before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.12),transparent);transform:translateX(-100%);transition:transform .5s ease}
.btn-submit:hover::before{transform:translateX(100%)}
.btn-submit:hover{transform:translateY(-2px);box-shadow:0 10px 30px rgba(232,164,0,.42)}
.btn-submit:active{transform:translateY(0)}
.btn-submit.loading{opacity:.75;pointer-events:none}
.spin{width:17px;height:17px;border:2.5px solid rgba(0,0,0,.18);border-top-color:#000;border-radius:50%;animation:spin .6s linear infinite;display:none}
@keyframes spin{to{transform:rotate(360deg)}}

.div-or{display:flex;align-items:center;gap:10px;margin:18px 0 14px}
.div-or::before,.div-or::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.06)}
.div-or span{font-size:.7rem;color:#3d4868}

.foot-link{text-align:center;font-size:.83rem;color:#8b95b5}
.foot-link a{color:#e8a400;font-weight:800;text-decoration:none;transition:color .2s}
.foot-link a:hover{color:#f5c842}

.sec-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(16,217,122,.05);border:1px solid rgba(16,217,122,.1);border-radius:8px;padding:5px 10px;font-size:.67rem;color:#10d97a;margin-top:13px}
</style>
</head>
<body>
<div class="noise"></div>
<div class="glow-orb orb1"></div>
<div class="glow-orb orb2"></div>
<div class="glow-orb orb3"></div>
<div class="grid-bg"></div>

<div class="wrap">
  <div class="logo-row">
    <div class="logo-gem">💎</div>
    <div class="logo-name">Trade<em>Vault</em></div>
  </div>

  <div class="card">
    <div class="head">
      <div class="head-icon">🚀</div>
      <h1>إنشاء حساب جديد</h1>
      <p>انضم إلى <?=e($siteName)?> وبع واشترِ بأمان تام</p>
    </div>

    <div class="feats">
      <div class="feat"><i class="fas fa-shield-alt"></i> شراء آمن موثوق</div>
      <div class="feat"><i class="fas fa-bolt"></i> تفعيل فوري</div>
      <div class="feat"><i class="fas fa-star"></i> موثوق 100%</div>
    </div>

    <?php if($errors): ?>
    <div class="errs">
      <div class="errs-title"><i class="fas fa-exclamation-circle"></i> يرجى تصحيح الأخطاء التالية:</div>
      <ul><?php foreach($errors as $e): ?><li><?=htmlspecialchars($e,ENT_QUOTES)?></li><?php endforeach; ?></ul>
    </div>
    <?php endif; ?>

    <form method="POST" id="regForm" novalidate>
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="ref_code" value="<?=htmlspecialchars($refCode,ENT_QUOTES,'UTF-8')?>">

      <div class="fg">
        <label><i class="fas fa-at"></i> اسم المستخدم</label>
        <input type="text" name="username" id="unIn" class="fi" placeholder="ahmed_99"
               required minlength="3" maxlength="50" value="<?=e($_POST['username']??'')?>"
               autocomplete="username" autocapitalize="none">
        <div class="hint">أحرف إنجليزية، أرقام، وشرطة سفلية فقط</div>
      </div>

      <div class="fg">
        <label><i class="fas fa-envelope"></i> البريد الإلكتروني</label>
        <input type="email" name="email" class="fi" placeholder="example@mail.com"
               required value="<?=e($_POST['email']??'')?>" autocomplete="email" inputmode="email">
      </div>

      <div class="fg">
        <label><i class="fas fa-phone"></i> رقم الهاتف <span style="font-weight:400;font-size:.67rem;color:#3d4868">(الدول العربية فقط)</span></label>
        <div class="phone-row">
          <select name="country_code" class="fsel" id="codeSelect">
            <?php foreach($arabicCountries as [$code,$flag,$name]): ?>
            <option value="<?=e($code)?>" data-flag="<?=e($flag)?>" <?=$code==='+20'?'selected':''?>><?=e($flag)?> <?=e($code)?></option>
            <?php endforeach; ?>
          </select>
          <input type="hidden" name="country_flag" id="flagInput" value="🇪🇬">
          <input type="tel" name="phone" class="fi" placeholder="0501234567"
                 required value="<?=e($_POST['phone']??'')?>" inputmode="tel">
        </div>
      </div>

      <div class="fg">
        <label><i class="fas fa-lock"></i> كلمة المرور</label>
        <div class="pw-wrap">
          <input type="password" name="password" class="fi" id="pwIn"
                 placeholder="6 أحرف على الأقل" required minlength="6"
                 autocomplete="new-password" oninput="chkStrength(this.value)">
          <button type="button" class="pw-eye" onclick="togglePw()"><i class="fas fa-eye" id="eyeIco"></i></button>
        </div>
        <div class="strength" id="strengthWrap">
          <div class="strength-track"><div class="strength-bar" id="sBar"></div></div>
          <div class="strength-lbl" id="sLbl"></div>
        </div>
      </div>

      <button type="submit" class="btn-submit" id="subBtn">
        <span id="btnTxt"><i class="fas fa-user-plus"></i> إنشاء الحساب مجاناً</span>
        <div class="spin" id="btnSpin"></div>
      </button>
    </form>

    <div style="text-align:center">
      <div class="sec-badge"><i class="fas fa-lock"></i> بياناتك محمية ومشفّرة بالكامل</div>
    </div>

    <div class="div-or"><span>أو</span></div>
    <div class="foot-link">لديك حساب؟ <a href="login.php">تسجيل الدخول</a></div>
  </div>
</div>

<script>
document.getElementById('codeSelect').addEventListener('change',function(){
  document.getElementById('flagInput').value=this.options[this.selectedIndex].dataset.flag||'🌍';
});
function togglePw(){
  const i=document.getElementById('pwIn'),ic=document.getElementById('eyeIco');
  i.type=i.type==='password'?'text':'password';
  ic.className=i.type==='password'?'fas fa-eye':'fas fa-eye-slash';
}
function chkStrength(v){
  const w=document.getElementById('strengthWrap'),b=document.getElementById('sBar'),l=document.getElementById('sLbl');
  if(!v){w.style.display='none';return;}
  w.style.display='block';
  let s=0;
  if(v.length>=6)s++;if(v.length>=10)s++;
  if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;
  const lvl=[{p:'12%',c:'#ff4757',t:'ضعيفة جداً'},{p:'30%',c:'#ff6b35',t:'ضعيفة'},{p:'55%',c:'#ffa502',t:'متوسطة'},{p:'80%',c:'#2ed573',t:'قوية'},{p:'100%',c:'#10d97a',t:'ممتازة 💪'}][Math.min(s,4)];
  b.style.width=lvl.p;b.style.background=lvl.c;l.textContent='قوة كلمة المرور: '+lvl.t;l.style.color=lvl.c;
}
document.getElementById('unIn').addEventListener('input',function(){
  const v=/^[a-zA-Z0-9_]*$/.test(this.value)&&this.value.length>=3;
  this.className='fi '+(this.value.length>0?(v?'ok':'err'):'');
});
document.getElementById('regForm').addEventListener('submit',function(){
  const b=document.getElementById('subBtn');
  b.classList.add('loading');
  document.getElementById('btnTxt').style.display='none';
  document.getElementById('btnSpin').style.display='block';
});
</script>
</body>
</html>
