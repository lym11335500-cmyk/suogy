<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
// حماية الصفحة — يجب تسجيل الدخول
requireLogin();

$lid  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT l.*,c.name cat_name,c.icon cat_icon,u.username seller_name,u.profile_pic,u.seller_rating,u.total_sales,u.kyc_status seller_kyc FROM listings l JOIN categories c ON l.category_id=c.id JOIN users u ON l.user_id=u.id WHERE l.id=?");
$stmt->execute([$lid]);
$listing = $stmt->fetch();
if(!$listing){ header('Location:index.php'); exit; }

// Increment views
$pdo->prepare("UPDATE listings SET views=views+1 WHERE id=?")->execute([$lid]);

// Images
$imgs = $pdo->prepare("SELECT * FROM listing_images WHERE listing_id=? ORDER BY sort_order");
$imgs->execute([$lid]);
$imgs = $imgs->fetchAll();

$msg=''; $msgType='ok';

// BUY ACTION
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    requireLogin();
    $uid   = uid();
    $buyer = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

    if($uid===$listing['user_id']){ $msg='لا يمكنك شراء إعلانك الخاص'; $msgType='err'; }
    elseif($buyer['kyc_status']!=='approved'){ $msg='يجب التحقق من هويتك أولاً'; $msgType='err'; header('Location:kyc.php'); exit; }
    elseif($listing['status']!=='active'){ $msg='هذا الإعلان غير متاح للشراء'; $msgType='err'; }
    elseif($buyer['balance']<$listing['price']){ $msg='رصيدك غير كافٍ — '.money($buyer['balance']).' متاح، يحتاج '.money($listing['price']); $msgType='err'; }
    else {
        $pdo->beginTransaction();
        try {
            $amount     = (float)$listing['price'];
            $rate       = (float)getSetting($pdo,'commission_rate','5');
            $commission = round($amount*$rate/100,2);
            $sellerNet  = round($amount-$commission,2);
            $warrantyEnd = date('Y-m-d H:i:s',strtotime('+48 hours'));

            // Deduct from buyer balance → held
            $buyerBefore = $buyer['balance'];
            $pdo->prepare("UPDATE users SET balance=balance-?,held_balance=held_balance+? WHERE id=?")->execute([$amount,$amount,$uid]);
            addTx($pdo,$uid,'hold',$amount,$buyerBefore,$buyerBefore-$amount,$lid,'حجز مبلغ شراء');

            // Create purchase
            $pdo->prepare("INSERT INTO purchases(listing_id,buyer_id,seller_id,amount,commission,seller_net,warranty_end)VALUES(?,?,?,?,?,?,?)")
                ->execute([$lid,$uid,$listing['user_id'],$amount,$commission,$sellerNet,$warrantyEnd]);
            $purchaseId = (int)$pdo->lastInsertId();

            // Create chat (status=pending until all 3 parties join)
            $pdo->prepare("INSERT INTO chats(purchase_id,status)VALUES(?,'pending')")->execute([$purchaseId]);
            $chatId = (int)$pdo->lastInsertId();

            // System message in chat
            $sysmsg = "🛒 صفقة جديدة!\nالمبلغ: ".money($amount)." — العمولة: ".money($commission)." — صافي البائع: ".money($sellerNet)."\n⏳ انتظار انضمام جميع الأطراف (مشتري + بائع + إدارة) لبدء الغرفة.";
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,?,?,?)")->execute([$chatId,1,'system',$sysmsg]);

            // Update listing status
            $pdo->prepare("UPDATE listings SET status='pending_sale' WHERE id=?")->execute([$lid]);

            // Notifications
            addNotif($pdo,$listing['user_id'],'new_purchase','🛒 طلب شراء جديد لإعلانك: '.e($listing['title']),'deal.php?pid='.$purchaseId);
            $admins = $pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll();
            foreach($admins as $adm) addNotif($pdo,$adm['id'],'new_purchase','🛒 صفقة جديدة — '.money($amount),'deal.php?pid='.$purchaseId);

            $pdo->commit();
            header("Location:deal.php?pid=$purchaseId"); exit;
        } catch(Exception $e){
            $pdo->rollBack();
            $msg='حدث خطأ — يُرجى المحاولة مرة أخرى: '.$e->getMessage();
            $msgType='err';
        }
    }
}

pageHead(e($listing['title']));
pageTopbar($pdo,'index.php','تفاصيل الإعلان');
?>
<div class="page">

<!-- IMAGE GALLERY -->
<?php if($imgs): ?>
<div style="position:relative;background:var(--bg2)">
  <div id="gallery" style="display:flex;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;scrollbar-width:none">
    <?php foreach($imgs as $i=>$img): ?>
    <div style="flex:0 0 100%;scroll-snap-align:start">
      <img src="<?=e($img['image_path'])?>" style="width:100%;aspect-ratio:16/9;object-fit:cover" alt="" loading="<?=$i?'lazy':'eager'?>">
    </div>
    <?php endforeach; ?>
  </div>
  <?php if(count($imgs)>1): ?>
  <div id="galDots" style="position:absolute;bottom:10px;left:50%;transform:translateX(-50%);display:flex;gap:5px">
    <?php foreach($imgs as $i=>$img): ?>
    <div style="width:<?=$i===0?10:7?>px;height:7px;border-radius:4px;background:<?=$i===0?'var(--gold)':'rgba(255,255,255,.4)'?>;transition:all .3s" id="dot<?=$i?>"></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php else: ?>
<div style="width:100%;aspect-ratio:16/9;background:var(--bg3);display:flex;align-items:center;justify-content:center;color:var(--txt3);font-size:3rem">
  <i class="fas fa-image"></i>
</div>
<?php endif; ?>

<div style="padding:16px 16px 90px">

  <?php if($msg): echo '<div class="alert alert-'.$msgType.'"><i class="fas fa-'.($msgType==='ok'?'check-circle':'times-circle').'"></i><span>'.$msg.'</span></div>'; endif; ?>

  <!-- CATEGORY + STATUS -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
    <span class="badge badge-gold"><i class="fas <?=e($listing['cat_icon'])?>"></i> <?=e($listing['cat_name'])?></span>
    <?php if($listing['status']==='sold'): ?>
    <span class="badge badge-err">مُباع</span>
    <?php elseif($listing['status']==='active'): ?>
    <span class="badge badge-ok">متاح</span>
    <?php endif; ?>
  </div>

  <!-- TITLE & PRICE -->
  <h1 style="font-size:1.15rem;font-weight:900;line-height:1.4;margin-bottom:10px"><?=e($listing['title'])?></h1>
  <div style="font-size:1.8rem;font-weight:900;color:var(--gold);font-family:'JetBrains Mono',monospace;margin-bottom:16px">
    <?=money((float)$listing['price'])?>
  </div>

  <!-- SELLER INFO -->
  <a href="profile.php?id=<?=$listing['user_id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--txt);margin-bottom:16px">
    <div class="user-chip-av">
      <?php if($listing['profile_pic']): ?><img src="<?=e(assetUrl($listing['profile_pic']))?>" alt=""><?php else: ?><?=strtoupper(mb_substr($listing['seller_name'],0,1,'UTF-8'))?><?php endif; ?>
    </div>
    <div style="flex:1">
      <div class="user-chip-name"><?=e($listing['seller_name'])?> <?=kycBadge($listing['seller_kyc'])?></div>
      <div class="user-chip-meta">
        <span class="stars"><?=str_repeat('★',min((int)$listing['seller_rating'],5))?></span>
        <?=$listing['seller_rating']?> نقطة · <?=$listing['total_sales']?> صفقة
      </div>
    </div>
    <i class="fas fa-chevron-left" style="color:var(--txt3)"></i>
  </a>

  <!-- DESCRIPTION -->
  <div class="card" style="margin-bottom:16px">
    <div class="card-hd"><i class="fas fa-align-right"></i> وصف المنتج</div>
    <div style="font-size:.87rem;line-height:1.8;color:var(--txt2);white-space:pre-wrap"><?=e($listing['description'])?></div>
  </div>

  <!-- META -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
    <div class="stat-box"><div class="stat-val"><?=number_format($listing['views'])?></div><div class="stat-lbl">مشاهدة</div></div>
    <div class="stat-box"><div class="stat-val"><?=timeAgo($listing['created_at'])?></div><div class="stat-lbl">تاريخ النشر</div></div>
  </div>

  <!-- SAFETY BANNER -->
  <div style="background:var(--bg3);border:1px solid #f0b42922;border-radius:var(--r2);padding:12px 14px;margin-bottom:16px;font-size:.78rem;line-height:1.7;color:var(--txt2)">
    <div style="font-weight:700;color:var(--gold);margin-bottom:4px"><i class="fas fa-shield-alt"></i> ضمان سوقي للمشتري</div>
    سيتم حجز مبلغك حتى تأكيد الصفقة في محادثة ثلاثية آمنة تجمعك مع البائع والأدمين. مدة المحادثة ساعتان.
  </div>

  <!-- BUY BUTTON -->
  <?php if($listing['status']==='active'): ?>
    <?php if(!isLoggedIn()): ?>
    <a href="login.php?next=listing.php?id=<?=$lid?>" class="btn btn-gold btn-block">
      <i class="fas fa-sign-in-alt"></i> سجل دخولك للشراء
    </a>
    <?php elseif(uid()===$listing['user_id']): ?>
    <div style="display:flex;gap:10px">
      <a href="sell.php?edit=<?=$lid?>" class="btn btn-outline" style="flex:1"><i class="fas fa-edit"></i> تعديل</a>
      <form method="POST" action="dashboard.php" style="flex:1">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="act" value="delete_listing">
        <input type="hidden" name="lid" value="<?=$lid?>">
        <button type="submit" class="btn btn-red btn-block" onclick="return confirm('حذف الإعلان؟')"><i class="fas fa-trash"></i> حذف</button>
      </form>
    </div>
    <?php else: ?>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <button type="submit" class="btn btn-gold btn-block" style="font-size:1rem;padding:16px">
        <i class="fas fa-shopping-cart"></i> شراء الآن — <?=money((float)$listing['price'])?>
      </button>
    </form>
    <?php if(isLoggedIn()): ?>
    <div style="text-align:center;font-size:.75rem;color:var(--txt3);margin-top:8px">رصيدك الحالي: <?=money((float)$pdo->query("SELECT balance FROM users WHERE id=".uid())->fetchColumn())?></div>
    <?php endif; ?>
    <?php endif; ?>
  <?php else: ?>
  <button class="btn btn-outline btn-block" disabled><i class="fas fa-times-circle"></i> <?=statusLabel($listing['status'])?></button>
  <?php endif; ?>

</div>
</div>

<script>
// Gallery scroll dots
const gal = document.getElementById('gallery');
if(gal){
  gal.addEventListener('scroll',()=>{
    const idx = Math.round(gal.scrollLeft/gal.offsetWidth);
    document.querySelectorAll('[id^="dot"]').forEach((d,i)=>{
      d.style.background = i===idx?'var(--gold)':'rgba(255,255,255,.4)';
      d.style.width = i===idx?'10px':'7px';
    });
  });
}
</script>
<?php pageFoot(); ?>
