<?php
// ══════════════════════════════════════════════════════
//  deal.php — غرفة الصفقة
//  بث داخلي: رسائل تظهر للبائع والمشتري فقط
//  الأطراف: مشتري + بائع + أدمن
//  زر إتمام للأدمن فقط — المال محجوز فوراً
// ══════════════════════════════════════════════════════
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid = uid();
$pid = isset($_GET['pid']) ? (int)$_GET['pid'] : 0;
if (!$pid) { header('Location: deals.php'); exit; }

// ─── LOAD DEAL ────────────────────────────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT p.*,
           l.title listing_title, l.id listing_id, l.account_details,
           b.id buyer_id, b.username buyer_name, b.profile_pic buyer_pic,
           s.id seller_id, s.username seller_name, s.profile_pic seller_pic,
           c.id room_id, c.status room_status, c.expires_at, c.activated_at,
           c.buyer_joined, c.seller_joined, c.admin_joined
    FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id
    JOIN users s ON p.seller_id=s.id
    JOIN chats c ON c.purchase_id=p.id
    WHERE p.id=?
");
$stmt->execute([$pid]);
$deal = $stmt->fetch();
if (!$deal) { header('Location: deals.php'); exit; }

$isBuyer  = ($uid === (int)$deal['buyer_id']);
$isSeller = ($uid === (int)$deal['seller_id']);
$isAdm    = isAdmin();
if (!$isBuyer && !$isSeller && !$isAdm) { header('Location: index.php'); exit; }

$roomId = (int)$deal['room_id'];

// ─── RECORD JOIN ──────────────────────────────────────────────────────────────
if ($deal['room_status'] === 'pending') {
    $col = null;
    if ($isBuyer  && !$deal['buyer_joined'])  $col = 'buyer_joined=1';
    if ($isSeller && !$deal['seller_joined']) $col = 'seller_joined=1';
    if ($isAdm    && !$deal['admin_joined'])  $col = 'admin_joined=1';
    if ($col) {
        $pdo->prepare("UPDATE chats SET $col WHERE id=?")->execute([$roomId]);
        $stmt->execute([$pid]);
        $deal = $stmt->fetch();
    }
    // All 3 joined → activate room
    if ($deal['buyer_joined'] && $deal['seller_joined'] && $deal['admin_joined']) {
        $hrs    = (int)getSetting($pdo,'chat_duration_hours','2');
        $expiry = date('Y-m-d H:i:s', time() + $hrs*3600);
        $pdo->prepare("UPDATE chats SET status='active',activated_at=NOW(),expires_at=? WHERE id=?")
            ->execute([$expiry,$roomId]);
        $sys = "✅ انضم جميع الأطراف — بدأت مهلة الصفقة ({$hrs} ساعات)\n"
             . "📢 غرفة بث مشترك — الجميع يرى نفس الرسائل\n"
             . "💰 المبلغ محجوز — يُحرَّر فور موافقة الإدارة على الإتمام";
        $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
            ->execute([$roomId,$sys]);
        foreach ([(int)$deal['buyer_id'],(int)$deal['seller_id']] as $nid) {
            addNotif($pdo,$nid,'chat_active',
                '🟢 بدأت غرفة الصفقة: '.mb_substr($deal['listing_title'],0,30,'UTF-8'),
                'deal.php?pid='.$pid);
        }
        $stmt->execute([$pid]);
        $deal = $stmt->fetch();
    }
}

// ─── AJAX POLL ────────────────────────────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'poll') {
    header('Content-Type: application/json; charset=utf-8');
    $lastId = isset($_GET['last']) ? (int)$_GET['last'] : 0;

    $pdo->prepare("UPDATE messages SET is_read=1 WHERE chat_id=? AND sender_id!=?")->execute([$roomId,$uid]);

    $q = $pdo->prepare("
        SELECT m.id, m.content, m.message_type, m.image_path, m.created_at, m.sender_id,
               u.username sender_name, u.profile_pic sender_pic, u.is_admin
        FROM messages m JOIN users u ON m.sender_id=u.id
        WHERE m.chat_id=? AND m.id>?
        ORDER BY m.id ASC LIMIT 50
    ");
    $q->execute([$roomId,$lastId]);

    $roomRow = $pdo->query("SELECT status,expires_at,buyer_joined,seller_joined,admin_joined FROM chats WHERE id=$roomId")->fetch();
    $tl = null;
    if ($roomRow['expires_at']) {
        $sec = max(0, strtotime($roomRow['expires_at'])-time());
        $tl  = sprintf('%02d:%02d:%02d',floor($sec/3600),floor(($sec%3600)/60),$sec%60);
    }
    echo json_encode([
        'ok'       => true,
        'messages' => $q->fetchAll(),
        'status'   => $roomRow['status'],
        'time_left'=> $tl,
        'joined'   => [(int)$roomRow['buyer_joined'],(int)$roomRow['seller_joined'],(int)$roomRow['admin_joined']],
    ]);
    exit;
}

// ─── POST ACTIONS ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    // SEND MESSAGE
    if ($act==='send') {
        if (!in_array($deal['room_status'],['active','extended'])) { header("Location:deal.php?pid=$pid"); exit; }
        $content = trim($_POST['content'] ?? '');
        $type    = 'text';
        $imgPath = null;

        if (!empty($_FILES['media']['name']) && $_FILES['media']['error']===UPLOAD_ERR_OK) {
            $upload = uploadFileMedia($_FILES['media'],'deals');
            if ($upload) {
                $imgPath = $upload['path'];
                $type    = $upload['type'];
                if (!$content) $content = $imgPath;
            }
        }
        if ($type==='text' && $content && preg_match('/https?:\/\//i',$content)) $type='link';

        if ($content || $imgPath) {
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content,image_path)VALUES(?,?,?,?,?)")
                ->execute([$roomId,$uid,$type,$content,$imgPath]);
            $notifyIds = [(int)$deal['buyer_id'],(int)$deal['seller_id']];
            foreach ($pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll() as $a)
                $notifyIds[]=(int)$a['id'];
            foreach (array_unique($notifyIds) as $nid)
                if ($nid!==$uid)
                    addNotif($pdo,$nid,'deal_message',
                        '💬 رسالة: '.mb_substr($deal['listing_title'],0,30,'UTF-8'),
                        'deal.php?pid='.$pid);
        }
        header("Location:deal.php?pid=$pid"); exit;
    }

    // ADMIN APPROVE
    if ($act==='admin_approve' && $isAdm) {
        if (in_array($deal['room_status'],['active','extended']) && $deal['status']==='held') {
            completePurchase($pdo,$pid);
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
                ->execute([$roomId,
                    "✅ أعلنت الإدارة إتمام الصفقة بنجاح!\n".
                    "💰 ".money((float)$deal['seller_net'])." حُوِّلت للبائع\n".
                    "شكراً لاستخدامكم سوقي 🛒"
                ]);
        }
        header("Location:deal.php?pid=$pid"); exit;
    }

    // ADMIN REFUND
    if ($act==='admin_refund' && $isAdm) {
        refundPurchase($pdo,$pid,$roomId,'cancelled');
        header("Location:deals.php"); exit;
    }

    // ADMIN EXTEND
    if ($act==='admin_extend' && $isAdm && $deal['expires_at']) {
        $newExp = date('Y-m-d H:i:s', strtotime($deal['expires_at'])+7200);
        $pdo->prepare("UPDATE chats SET expires_at=?,status='extended' WHERE id=?")->execute([$newExp,$roomId]);
        $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
            ->execute([$roomId,'⏱ تم تمديد وقت الغرفة بساعتين إضافيتين من قِبل الإدارة.']);
        header("Location:deal.php?pid=$pid"); exit;
    }

    // ADMIN FORCE ACTIVATE
    if ($act==='force_activate' && $isAdm && $deal['room_status']==='pending') {
        $hrs    = (int)getSetting($pdo,'chat_duration_hours','2');
        $expiry = date('Y-m-d H:i:s', time()+$hrs*3600);
        $pdo->prepare("UPDATE chats SET status='active',buyer_joined=1,seller_joined=1,admin_joined=1,activated_at=NOW(),expires_at=? WHERE id=?")
            ->execute([$expiry,$roomId]);
        $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")
            ->execute([$roomId,"⚡ تم تفعيل الغرفة يدوياً من قِبل الإدارة."]);
        header("Location:deal.php?pid=$pid"); exit;
    }
}

// ─── LOAD MESSAGES ────────────────────────────────────────────────────────────
$allMsgs = $pdo->prepare("
    SELECT m.id, m.content, m.message_type, m.image_path, m.created_at, m.sender_id,
           u.username sender_name, u.profile_pic sender_pic, u.is_admin
    FROM messages m JOIN users u ON m.sender_id=u.id
    WHERE m.chat_id=?
    ORDER BY m.id ASC
");
$allMsgs->execute([$roomId]);
$allMsgs = $allMsgs->fetchAll();

$pdo->prepare("UPDATE messages SET is_read=1 WHERE chat_id=? AND sender_id!=?")->execute([$roomId,$uid]);

$timeLeft  = '';
if ($deal['expires_at']) {
    $sec = max(0, strtotime($deal['expires_at'])-time());
    $timeLeft = sprintf('%02d:%02d:%02d',floor($sec/3600),floor(($sec%3600)/60),$sec%60);
}

$isActive  = in_array($deal['room_status'],['active','extended']);
$isPending = ($deal['room_status']==='pending');
$isDone    = in_array($deal['room_status'],['completed','expired','cancelled']);
$joinCount = (int)$deal['buyer_joined']+(int)$deal['seller_joined']+(int)$deal['admin_joined'];
$lastId    = !empty($allMsgs) ? (int)end($allMsgs)['id'] : 0;
$myLabel   = $isBuyer ? 'مشتري' : ($isSeller ? 'بائع' : 'إدارة');

pageHead(e($deal['listing_title']));
pageTopbar($pdo,'js:back','غرفة الصفقة');
?>
<style>
.room-hd{padding:12px 14px;background:var(--bg2);border-bottom:1px solid var(--border2)}
.timer{font-family:'JetBrains Mono',monospace;font-size:.85rem;color:var(--gold);font-weight:700;background:var(--bg3);padding:4px 10px;border-radius:20px;border:1px solid #f0b42930}
.party-dot{display:inline-flex;align-items:center;gap:4px;font-size:.65rem;font-weight:700;padding:3px 8px;border-radius:20px}
.party-dot.on{background:#16a34a1a;color:var(--green);border:1px solid #22c55e22}
.party-dot.off{background:#ef44441a;color:var(--red);border:1px solid #ef444422}

.msgs{flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:10px;min-height:0}
.mw{display:flex;gap:8px;max-width:90%}
.mw.me{flex-direction:row-reverse;align-self:flex-end}
.mw.them{align-self:flex-start}
.mw.sys{align-self:center;max-width:100%}
.av{width:30px;height:30px;border-radius:8px;background:var(--card2);border:1px solid var(--border2);overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:900;color:var(--gold);flex-shrink:0}
.av img{width:100%;height:100%;object-fit:cover}
.bub{padding:9px 12px;border-radius:14px;font-size:.84rem;line-height:1.55;max-width:100%;word-break:break-word}
.mw.me  .bub{background:linear-gradient(135deg,var(--gold),var(--gold3));color:#06040a;border-bottom-right-radius:4px}
.mw.them .bub{background:var(--card2);border:1px solid var(--border2);color:var(--txt);border-bottom-left-radius:4px}
.mw.adm .bub{background:linear-gradient(135deg,#3b82f615,#8b5cf615);border:1px solid #3b82f633;color:var(--txt);border-bottom-left-radius:4px}
.mt{font-size:.58rem;color:var(--txt3);margin-top:3px}
.sn{font-size:.62rem;font-weight:700;color:var(--txt3);margin-bottom:2px}
.adm-tag{display:inline-block;background:#3b82f622;color:var(--blue);font-size:.55rem;font-weight:900;padding:1px 5px;border-radius:4px;margin-left:4px;vertical-align:middle}
.sysbub{background:var(--bg3);border:1px solid var(--border2);border-radius:10px;padding:9px 14px;font-size:.77rem;color:var(--txt2);text-align:center;line-height:1.7;white-space:pre-wrap;width:100%}
.msg-img{max-width:220px;border-radius:10px;cursor:pointer;display:block}
.msg-link{color:var(--blue);text-decoration:underline;word-break:break-all}

.ibar{padding:10px 12px;background:var(--bg2);border-top:1px solid var(--border2);flex-shrink:0}
.irow{display:flex;align-items:flex-end;gap:8px}
.txta{flex:1;background:var(--bg3);border:1.5px solid var(--border2);border-radius:20px;padding:10px 14px;color:var(--txt);font-family:'Cairo',sans-serif;font-size:.88rem;outline:none;resize:none;max-height:100px;line-height:1.4;min-height:42px}
.txta:focus{border-color:var(--gold)}
.sbtn{width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold3));border:none;color:#06040a;display:flex;align-items:center;justify-content:center;font-size:.95rem;cursor:pointer;flex-shrink:0;transition:transform .15s}
.sbtn:active{transform:scale(.9)}
.ibtn{width:36px;height:36px;border-radius:50%;background:var(--bg3);border:1px solid var(--border2);color:var(--txt2);display:flex;align-items:center;justify-content:center;font-size:.88rem;cursor:pointer;flex-shrink:0;transition:all .2s}
.ibtn:hover{border-color:var(--gold);color:var(--gold)}
.prev-bar{display:none;align-items:center;gap:8px;padding:6px 12px;font-size:.75rem;color:var(--txt2);border-top:1px solid var(--border)}
.prev-bar img{height:40px;border-radius:6px;object-fit:cover}

.adm-panel{background:linear-gradient(135deg,#3b82f608,#8b5cf608);border:1px solid #3b82f625;border-radius:var(--r);padding:14px;margin:10px 12px;flex-shrink:0}
</style>

<div style="display:flex;flex-direction:column;height:calc(100vh - 56px);overflow:hidden">

<!-- ROOM HEADER -->
<div class="room-hd">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:.87rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($deal['listing_title'])?></div>
      <div style="font-size:.68rem;color:var(--txt2);margin-top:1px">
        <span style="color:var(--gold);font-weight:700;font-family:'JetBrains Mono',monospace"><?=money((float)$deal['amount'])?></span>
        · أنت: <span style="color:var(--gold);font-weight:700"><?=$myLabel?></span>
      </div>
    </div>
    <?php if($isActive && $timeLeft): ?>
    <div class="timer" id="tdisplay">⏱ <?=$timeLeft?></div>
    <?php endif; ?>
  </div>
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:5px">
    <div style="display:flex;gap:5px">
      <div class="party-dot <?=$deal['buyer_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> مشتري</div>
      <div class="party-dot <?=$deal['seller_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> بائع</div>
      <div class="party-dot <?=$deal['admin_joined']?'on':'off'?>"><i class="fas fa-circle" style="font-size:.4rem"></i> إدارة</div>
    </div>
    <?php
    $stLabel = ['pending'=>'⏳ انتظار','active'=>'● نشطة','extended'=>'● ممتدة',
                'completed'=>'✅ مكتملة','expired'=>'⏰ منتهية','cancelled'=>'❌ ملغاة'];
    $stBadge = ['pending'=>'badge-warn','active'=>'badge-ok','extended'=>'badge-ok',
                'completed'=>'badge-ok','expired'=>'badge-err','cancelled'=>'badge-err'];
    $rs = $deal['room_status'];
    ?>
    <span class="badge <?=$stBadge[$rs]??'badge-gray'?>" style="font-size:.62rem"><?=$stLabel[$rs]??$rs?> <?=$isPending?"($joinCount/3)":''?></span>
  </div>
</div>

<!-- MESSAGES -->
<div class="msgs" id="msgs">

<?php if($isPending): ?>
<div style="text-align:center;padding:28px 20px;background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r);margin:8px">
  <div style="font-size:2.2rem;margin-bottom:10px">⏳</div>
  <div style="font-weight:700;font-size:.9rem;margin-bottom:6px">الغرفة تنتظر انضمام جميع الأطراف</div>
  <div style="font-size:.74rem;color:var(--txt2);line-height:1.8">
    المحادثة لن تبدأ إلا عندما ينضم<br>المشتري + البائع + الإدارة معاً<br>
    <strong style="color:var(--gold)">المبلغ محجوز بأمان حتى تتم الصفقة</strong>
  </div>
  <div style="margin-top:14px;display:flex;justify-content:center;gap:8px;flex-wrap:wrap">
    <div class="party-dot <?=$deal['buyer_joined']?'on':'off'?>"><i class="fas fa-<?=$deal['buyer_joined']?'check':'times'?>-circle"></i> مشتري</div>
    <div class="party-dot <?=$deal['seller_joined']?'on':'off'?>"><i class="fas fa-<?=$deal['seller_joined']?'check':'times'?>-circle"></i> بائع</div>
    <div class="party-dot <?=$deal['admin_joined']?'on':'off'?>"><i class="fas fa-<?=$deal['admin_joined']?'check':'times'?>-circle"></i> إدارة</div>
  </div>
  <?php if($isAdm): ?>
  <form method="POST" style="margin-top:14px">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="force_activate">
    <button class="btn btn-ghost btn-sm"><i class="fas fa-bolt"></i> تفعيل يدوي</button>
  </form>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php foreach($allMsgs as $m):
  $isMe   = ($uid===(int)$m['sender_id']);
  $isSys  = ($m['message_type']==='system');
  $isAdmM = ((bool)$m['is_admin'] && !$isSys);
  $avLet  = strtoupper(mb_substr($m['sender_name'],0,1,'UTF-8'));
?>
<?php if($isSys): ?>
<div class="mw sys"><div class="sysbub"><?=nl2br(e($m['content']))?></div></div>
<?php else: ?>
<div class="mw <?=$isMe?'me':($isAdmM?'them adm':'them')?>">
  <?php if(!$isMe): ?><div class="av"><?php if($m['sender_pic']): ?><img src="<?=e(assetUrl($m['sender_pic']))?>" alt=""><?php else: ?><?=$avLet?><?php endif; ?></div><?php endif; ?>
  <div>
    <?php if(!$isMe): ?>
    <div class="sn"><?php if($isAdmM): ?><span class="adm-tag">إدارة</span><?php endif; ?><?=e($m['sender_name'])?></div>
    <?php endif; ?>
    <div class="bub"><?php
      $mt=$m['message_type']; $mc=$m['content'];
      if($mt==='image' && $m['image_path']){
        echo '<img src="'.e(assetUrl($m['image_path'])).'" class="msg-img" alt="" onclick="openImg(this.src)">';
        if($mc && $mc!==$m['image_path']) echo '<div style="margin-top:5px">'.e($mc).'</div>';
      } elseif($mt==='video' && $m['image_path']){
        echo '<video src="'.e(assetUrl($m['image_path'])).'" controls style="max-width:220px;border-radius:10px;display:block">';
      } elseif($mt==='link'){
        echo '<a href="'.e($mc).'" class="msg-link" target="_blank" rel="noopener">'.e($mc).'</a>';
      } else {
        echo nl2br(e($mc));
      }
    ?></div>
    <div class="mt" <?=$isMe?'style="text-align:right"':''?>><?=date('H:i',strtotime($m['created_at']))?></div>
  </div>
</div>
<?php endif; ?>
<?php endforeach; ?>
<div id="msgbottom"></div>
</div><!-- /msgs -->

<?php if($isDone): ?>
<div style="padding:18px;text-align:center;background:var(--bg2);border-top:1px solid var(--border2)">
  <?php if($deal['room_status']==='completed'): ?>
  <div style="color:var(--green);font-weight:700"><i class="fas fa-check-circle"></i> تمت الصفقة بنجاح — <?=money((float)$deal['seller_net'])?> للبائع</div>
  <?php elseif($deal['room_status']==='expired'): ?>
  <div style="color:var(--red);font-weight:700"><i class="fas fa-clock"></i> انتهت المهلة — تم استرجاع المبلغ للمشتري</div>
  <?php else: ?>
  <div style="color:var(--txt3);font-weight:700"><i class="fas fa-times-circle"></i> تم إلغاء الصفقة</div>
  <?php endif; ?>
  <a href="deals.php" class="btn btn-ghost btn-sm" style="margin-top:10px">العودة للصفقات</a>
</div>

<?php elseif($isActive): ?>

<!-- ADMIN PANEL -->
<?php if($isAdm): ?>
<div class="adm-panel">
  <div style="font-size:.7rem;font-weight:700;color:var(--blue);margin-bottom:8px"><i class="fas fa-shield-alt"></i> لوحة الإدارة</div>
  <div style="display:flex;gap:7px;flex-wrap:wrap">
    <form method="POST" style="flex:1;min-width:160px">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="admin_approve">
      <button class="btn btn-green btn-block btn-sm" onclick="return confirm('تأكيد إتمام الصفقة؟ سيتم تحويل الأموال للبائع فوراً.')">
        <i class="fas fa-check-double"></i> إتمام الصفقة — <?=money((float)$deal['seller_net'])?>
      </button>
    </form>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="admin_extend">
      <button class="btn btn-ghost btn-sm" title="تمديد ساعتين"><i class="fas fa-clock"></i> +2س</button>
    </form>
    <form method="POST" onsubmit="return confirm('استرجاع المبلغ للمشتري؟')">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="admin_refund">
      <button class="btn btn-red btn-sm"><i class="fas fa-undo"></i> استرجاع</button>
    </form>
  </div>
</div>
<?php else: ?>
<div style="padding:7px 14px;background:var(--bg3);border-top:1px solid var(--border);font-size:.72rem;color:var(--txt2);text-align:center;flex-shrink:0">
  <i class="fas fa-lock" style="color:var(--gold)"></i> <?=money((float)$deal['amount'])?> محجوز — يُحرَّر بموافقة الإدارة
</div>
<?php endif; ?>

<!-- INPUT BAR -->
<form method="POST" id="sform" enctype="multipart/form-data">
  <input type="hidden" name="_csrf" value="<?=csrf()?>">
  <input type="hidden" name="act" value="send">
  <input type="file" id="finput" name="media" accept="image/*,video/*" style="display:none">

  <div class="prev-bar" id="prevbar">
    <img id="previmg" alt="" style="display:none">
    <span id="prevname" style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span>
    <button type="button" onclick="clearFile()" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:.85rem;padding:2px 6px">✕</button>
  </div>

  <div class="ibar">
    <div class="irow">
      <button type="button" class="ibtn" onclick="document.getElementById('finput').click()" title="إرفاق صورة/فيديو">
        <i class="fas fa-image"></i>
      </button>
      <textarea class="txta" id="txta" name="content" rows="1"
        placeholder="رسالة، رابط، أو أرسل صورة…"
        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();document.getElementById('sform').submit()}"
        oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"></textarea>
      <button type="submit" class="sbtn"><i class="fas fa-paper-plane"></i></button>
    </div>
  </div>
</form>

<?php elseif($isPending): ?>
<div style="padding:14px;text-align:center;font-size:.76rem;color:var(--txt3);border-top:1px solid var(--border2);flex-shrink:0">
  <i class="fas fa-lock"></i> الغرفة ستُفعَّل عند انضمام جميع الأطراف
</div>
<?php endif; ?>

</div>

<!-- IMAGE LIGHTBOX -->
<div id="lightbox" onclick="this.style.display='none'" style="display:none;position:fixed;inset:0;background:#000c;z-index:9999;align-items:center;justify-content:center;cursor:zoom-out">
  <img id="lbimg" style="max-width:96vw;max-height:90vh;border-radius:10px;object-fit:contain" alt="">
</div>

<script>
var area   = document.getElementById('msgs');
var lastId = <?=$lastId?>;
var ASSET_BASE = '<?php $sd=str_replace(chr(92),chr(47),dirname($_SERVER["SCRIPT_FILENAME"]));$rd=str_replace(chr(92),chr(47),dirname(dirname(__FILE__)));$dep=substr_count(str_replace($rd,"",$sd),"/");echo $dep>0?str_repeat("../",$dep):"";?>';
var myUid  = <?=$uid?>;

function scrollBot(smooth){ area.scrollTo({top:area.scrollHeight,behavior:smooth?'smooth':'instant'}); }
scrollBot(false);

function openImg(src){
  document.getElementById('lbimg').src=src;
  document.getElementById('lightbox').style.display='flex';
}

// ── File preview ──
document.getElementById('finput').addEventListener('change',function(){
  var f=this.files[0]; if(!f) return;
  document.getElementById('prevbar').style.display='flex';
  document.getElementById('prevname').textContent=f.name;
  var pi=document.getElementById('previmg');
  if(f.type.startsWith('image/')){
    var fr=new FileReader();
    fr.onload=function(e){pi.src=e.target.result;pi.style.display='block';};
    fr.readAsDataURL(f);
  } else { pi.style.display='none'; }
});
function clearFile(){
  document.getElementById('finput').value='';
  document.getElementById('prevbar').style.display='none';
  document.getElementById('previmg').src='';
}

// ── Render a message object from poll ──
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function renderMsg(m){
  var isMe   = (parseInt(m.sender_id)===myUid);
  var isSys  = (m.message_type==='system');
  var isAdm  = (parseInt(m.is_admin)===1 && !isSys);
  var avLet  = (m.sender_name||'?')[0].toUpperCase();
  var avHtml = m.sender_pic
    ? '<img src="'+esc(ASSET_BASE+m.sender_pic)+'" style="width:100%;height:100%;object-fit:cover" alt="">'
    : avLet;
  var time   = m.created_at ? String(m.created_at).substr(11,5) : '';

  if(isSys){
    var d=document.createElement('div');
    d.className='mw sys';
    d.innerHTML='<div class="sysbub">'+esc(m.content).replace(/\n/g,'<br>')+'</div>';
    return d;
  }

  var body='';
  if(m.message_type==='image'&&m.image_path){
    body='<img src="'+esc(ASSET_BASE+m.image_path)+'" class="msg-img" alt="" onclick="openImg(this.src)">';
    if(m.content&&m.content!==m.image_path) body+='<div style="margin-top:5px">'+esc(m.content)+'</div>';
  } else if(m.message_type==='video'&&m.image_path){
    body='<video src="'+esc(ASSET_BASE+m.image_path)+'" controls style="max-width:220px;border-radius:10px;display:block">';
  } else if(m.message_type==='link'){
    body='<a href="'+esc(m.content)+'" class="msg-link" target="_blank" rel="noopener">'+esc(m.content)+'</a>';
  } else {
    body=esc(m.content).replace(/\n/g,'<br>');
  }

  var cls='mw '+(isMe?'me':(isAdm?'them adm':'them'));
  var sn=isAdm?'<span class="adm-tag">إدارة</span>'+esc(m.sender_name):esc(m.sender_name);
  var html='';
  if(!isMe) html+='<div class="av">'+avHtml+'</div>';
  html+='<div>';
  if(!isMe) html+='<div class="sn">'+sn+'</div>';
  html+='<div class="bub">'+body+'</div>';
  html+='<div class="mt"'+(isMe?' style="text-align:right"':'')+'>'+time+'</div>';
  html+='</div>';

  var wrap=document.createElement('div');
  wrap.className=cls;
  wrap.innerHTML=html;
  return wrap;
}

// ── HTTP Polling every 4s ──
var pollTimer;
function poll(){
  fetch('deal.php?pid=<?=$pid?>&ajax=poll&last='+lastId,{credentials:'same-origin'})
    .then(r=>r.json())
    .then(d=>{
      if(!d.ok) return;
      if(d.messages&&d.messages.length){
        var atBot = area.scrollHeight-area.scrollTop-area.clientHeight < 70;
        d.messages.forEach(function(m){
          var el=renderMsg(m);
          document.getElementById('msgbottom').before(el);
          lastId=Math.max(lastId,parseInt(m.id)||0);
        });
        if(atBot) scrollBot(true);
      }
      if(d.time_left){
        var td=document.getElementById('tdisplay');
        if(td) td.textContent='⏱ '+d.time_left;
      }
      // If status changed to done → reload
      var cur='<?=$deal['room_status']?>';
      if(d.status&&d.status!==cur&&['completed','expired','cancelled'].includes(d.status))
        window.location.reload();
    })
    .catch(()=>{})
    .finally(()=>{ pollTimer=setTimeout(poll,4000); });
}
document.addEventListener('visibilitychange',function(){ if(document.hidden) clearTimeout(pollTimer); else poll(); });
poll();
</script>

<?php pageFoot(); ?>
