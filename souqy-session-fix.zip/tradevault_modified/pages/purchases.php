<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$uid=uid();

$purchases=$pdo->prepare("
    SELECT p.*,l.title listing_title,l.id listing_id,
           s.username seller_name,s.profile_pic seller_pic,
           c.status chat_status,c.expires_at
    FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users s ON p.seller_id=s.id
    JOIN chats c ON c.purchase_id=p.id
    WHERE p.buyer_id=?
    ORDER BY p.created_at DESC
");
$purchases->execute([$uid]);
$purchases=$purchases->fetchAll();

pageHead('مشترياتي');
pageTopbar($pdo,'index.php','مشترياتي');
?>
<div class="page" style="padding:16px 16px 90px">

<?php if(empty($purchases)): ?>
<div class="empty fade-up">
  <i class="fas fa-shopping-cart"></i>
  <p>لم تشترِ شيئاً بعد<br><a href="index.php" class="gold" style="text-decoration:none">تصفح الإعلانات →</a></p>
</div>
<?php else: ?>

<div style="font-size:.78rem;color:var(--txt2);margin-bottom:12px"><?=count($purchases)?> عملية شراء</div>

<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach($purchases as $p):
  $sc=['completed'=>'var(--green)','refunded'=>'var(--blue)','disputed'=>'var(--red)','held'=>'var(--gold)'];
  $statusColor=isset($sc[$p['status']])?$sc[$p['status']]:'var(--txt2)';
  $timeLeft=max(0,strtotime($p['expires_at'])-time());
  $expired=$timeLeft<=0 && $p['chat_status']==='active';
?>
<a href="deal.php?pid=<?=$p['id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:14px;display:flex;gap:12px;align-items:flex-start;text-decoration:none;color:var(--txt);transition:all .2s;<?=$p['status']==='held'?'border-color:var(--gold3)':''?>">
  <div style="width:44px;height:44px;border-radius:var(--r2);background:var(--bg3);display:flex;align-items:center;justify-content:center;color:var(--txt3);flex-shrink:0;border:1px solid var(--border2)">
    <?php if($p['seller_pic']): ?><img src="<?=e(assetUrl($p['seller_pic']))?>" style="width:100%;height:100%;object-fit:cover;border-radius:var(--r2)" alt="">
    <?php else: ?><i class="fas fa-user"></i><?php endif; ?>
  </div>
  <div style="flex:1;min-width:0">
    <div style="font-weight:700;font-size:.88rem;margin-bottom:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($p['listing_title'])?></div>
    <div style="font-size:.72rem;color:var(--txt2);margin-bottom:6px">من <?=e($p['seller_name'])?></div>
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <span class="mono" style="font-size:.9rem;font-weight:700;color:<?=$statusColor?>"><?=money((float)$p['amount'])?></span>
      <span class="tag tag-<?=$p['status']?>"><?=statusLabel($p['status'])?></span>
      <?php if($expired): ?><span class="badge badge-err" style="font-size:.6rem">انتهت المهلة</span><?php endif; ?>
    </div>
    <?php if($p['status']==='held' && !$expired): ?>
    <div style="margin-top:6px;font-size:.7rem;color:var(--gold)">
      <i class="fas fa-clock"></i>
      متبقي: <?=floor($timeLeft/3600)?>س <?=floor(($timeLeft%3600)/60)?>د
    </div>
    <?php endif; ?>
    <?php if($p['status']==='completed'): ?>
    <div style="margin-top:6px;font-size:.7rem;color:var(--green)"><i class="fas fa-check-double"></i> اكتملت <?=timeAgo($p['completed_at']??$p['created_at'])?></div>
    <?php endif; ?>
  </div>
  <div style="flex-shrink:0;font-size:.65rem;color:var(--txt3);text-align:center">
    <i class="fas fa-chevron-left"></i>
    <div style="margin-top:4px"><?=timeAgo($p['created_at'])?></div>
  </div>
</a>
<?php endforeach; ?>
</div>

<!-- SUMMARY -->
<?php
$completed=array_filter($purchases,function($p){return $p['status']==='completed');
$totalSpent=array_sum(array_column(array_filter($purchases,function($p){return $p['status']==='completed'),'amount'));
?>
<div style="margin-top:16px;background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:14px">
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center">
    <div><div class="stat-val" style="font-size:1rem"><?=count($purchases)?></div><div class="stat-lbl">إجمالي</div></div>
    <div><div class="stat-val" style="font-size:1rem;color:var(--green)"><?=count($completed)?></div><div class="stat-lbl">مكتملة</div></div>
    <div><div class="stat-val" style="font-size:1rem"><?=money($totalSpent)?></div><div class="stat-lbl">أنفقت</div></div>
  </div>
</div>

<?php endif; ?>
</div>
<?php pageBottomNav('dashboard.php'); pageFoot(); ?>
