<?php
// ══════════════════════════════════════════════════════
//  deals.php — قائمة الصفقات (بديل محادثاتي)
// ══════════════════════════════════════════════════════
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid = uid();
autoCleanupChats($pdo);

$view = $_GET['view'] ?? 'active';

// ─── AJAX: Poll unread + timers ───────────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'poll') {
    header('Content-Type: application/json; charset=utf-8');
    $rows = $pdo->prepare("
        SELECT c.id room_id, p.id purchase_id, c.status, c.expires_at,
               (SELECT COUNT(*) FROM messages m
                WHERE m.chat_id=c.id AND m.is_read=0 AND m.sender_id!=?) unread
        FROM chats c
        JOIN purchases p ON c.purchase_id=p.id
        WHERE (p.buyer_id=? OR p.seller_id=?)
          AND c.status IN ('pending','active','extended')
    ");
    $rows->execute([$uid,$uid,$uid]);
    $out = [];
    foreach ($rows->fetchAll() as $r) {
        $tl = null;
        if ($r['expires_at']) {
            $sec = max(0, strtotime($r['expires_at']) - time());
            $tl  = sprintf('%02d:%02d:%02d', floor($sec/3600), floor(($sec%3600)/60), $sec%60);
        }
        $out[] = ['pid'=>$r['purchase_id'],'unread'=>(int)$r['unread'],'status'=>$r['status'],'time_left'=>$tl];
    }
    echo json_encode(['ok'=>true,'deals'=>$out]);
    exit;
}

// ─── Active deals ─────────────────────────────────────────────────────────────
$activeQ = $pdo->prepare("
    SELECT p.id purchase_id, p.amount, p.status purchase_status, p.created_at,
           l.title listing_title,
           b.id buyer_id, b.username buyer_name, b.profile_pic buyer_pic,
           s.id seller_id, s.username seller_name, s.profile_pic seller_pic,
           c.id room_id, c.status room_status, c.expires_at,
           c.buyer_joined, c.seller_joined, c.admin_joined,
           (SELECT COUNT(*) FROM messages m WHERE m.chat_id=c.id AND m.is_read=0 AND m.sender_id!=?) unread
    FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id
    JOIN users s ON p.seller_id=s.id
    JOIN chats c ON c.purchase_id=p.id
    WHERE (p.buyer_id=? OR p.seller_id=?)
      AND c.status IN ('pending','active','extended')
    ORDER BY p.created_at DESC
");
$activeQ->execute([$uid,$uid,$uid]);
$activeDeals = $activeQ->fetchAll();

// ─── History ──────────────────────────────────────────────────────────────────
if (isAdmin()) {
    $historyDeals = $pdo->query("
        SELECT p.id purchase_id, p.amount, p.status purchase_status, p.created_at,
               l.title listing_title,
               b.id buyer_id, b.username buyer_name,
               s.id seller_id, s.username seller_name,
               c.id room_id, c.status room_status, c.expires_at
        FROM purchases p
        JOIN listings l ON p.listing_id=l.id
        JOIN users b ON p.buyer_id=b.id
        JOIN users s ON p.seller_id=s.id
        JOIN chats c ON c.purchase_id=p.id
        WHERE c.status IN ('completed','expired','cancelled')
        ORDER BY p.created_at DESC LIMIT 200
    ")->fetchAll();
} else {
    $hq = $pdo->prepare("
        SELECT p.id purchase_id, p.amount, p.status purchase_status, p.created_at,
               l.title listing_title,
               b.id buyer_id, b.username buyer_name,
               s.id seller_id, s.username seller_name,
               c.id room_id, c.status room_status, c.expires_at
        FROM purchases p
        JOIN listings l ON p.listing_id=l.id
        JOIN users b ON p.buyer_id=b.id
        JOIN users s ON p.seller_id=s.id
        JOIN chats c ON c.purchase_id=p.id
        WHERE (p.buyer_id=? OR p.seller_id=?)
          AND c.status IN ('completed','expired','cancelled')
          AND TIMESTAMPDIFF(DAY, IFNULL(c.expires_at,c.created_at), NOW()) <= 7
        ORDER BY p.created_at DESC
    ");
    $hq->execute([$uid,$uid]);
    $historyDeals = $hq->fetchAll();
}

$acnt = count($activeDeals);
$hcnt = count($historyDeals);

pageHead('صفقاتي');
pageTopbar($pdo, 'index.php', 'صفقاتي');
?>
<div class="page" style="padding:16px 16px 90px">

<!-- TABS -->
<div style="display:flex;gap:4px;margin-bottom:16px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--r2);padding:4px">
  <a href="deals.php?view=active" style="flex:1;text-align:center;padding:9px 6px;border-radius:10px;font-size:.82rem;font-weight:700;text-decoration:none;transition:all .2s;<?=$view==='active'?'background:linear-gradient(135deg,var(--gold),var(--gold3));color:#06040a':'color:var(--txt2)'?>">
    <i class="fas fa-bolt"></i> نشطة
    <?php if($acnt>0): ?><span id="active-badge" style="background:#06040a44;border-radius:20px;padding:1px 7px;font-size:.7rem;margin-right:3px"><?=$acnt?></span><?php endif; ?>
  </a>
  <a href="deals.php?view=history" style="flex:1;text-align:center;padding:9px 6px;border-radius:10px;font-size:.82rem;font-weight:700;text-decoration:none;transition:all .2s;<?=$view==='history'?'background:var(--card2);color:var(--txt);border:1px solid var(--border2)':'color:var(--txt2)'?>">
    <i class="fas fa-history"></i> السجل
    <?php if($hcnt>0): ?><span style="background:var(--border2);border-radius:20px;padding:1px 7px;font-size:.7rem;margin-right:3px"><?=$hcnt?></span><?php endif; ?>
  </a>
</div>

<?php if($view==='active'): ?>
<?php if(empty($activeDeals)): ?>
<div class="empty fade-up">
  <i class="fas fa-handshake"></i>
  <p>لا توجد صفقات نشطة<br>ابدأ بشراء منتج لفتح غرفة صفقة آمنة</p>
  <a href="index.php" class="btn btn-gold btn-sm" style="margin-top:14px">تصفح الإعلانات</a>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:10px" id="deals-list">
<?php foreach($activeDeals as $d):
  $isBuyer     = ($uid===(int)$d['buyer_id']);
  $partner     = $isBuyer ? $d['seller_name'] : $d['buyer_name'];
  $partnerPic  = $isBuyer ? ($d['seller_pic']??'') : ($d['buyer_pic']??'');
  $isPending   = ($d['room_status']==='pending');
  $isActive    = in_array($d['room_status'],['active','extended']);
  $joinCount   = (int)$d['buyer_joined']+(int)$d['seller_joined']+(int)$d['admin_joined'];
  $unread      = (int)$d['unread'];
  $tl = '';
  if($isActive && $d['expires_at']){
    $sec = max(0, strtotime($d['expires_at'])-time());
    $tl  = sprintf('%02d:%02d:%02d', floor($sec/3600), floor(($sec%3600)/60), $sec%60);
  }
?>
<a href="deal.php?pid=<?=$d['purchase_id']?>"
   class="deal-row"
   data-pid="<?=$d['purchase_id']?>"
   style="background:var(--card);border:1.5px solid <?=$unread?'var(--gold3)':'var(--border)'?>;border-radius:var(--r);padding:14px;display:flex;gap:12px;align-items:center;text-decoration:none;color:var(--txt);transition:border .25s;position:relative">

  <!-- Avatar -->
  <div style="width:46px;height:46px;border-radius:var(--r2);background:var(--card2);border:1px solid var(--border2);overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:900;color:var(--gold);font-size:1rem;flex-shrink:0">
    <?php if($partnerPic): ?><img src="<?=e($partnerPic)?>" style="width:100%;height:100%;object-fit:cover" alt="">
    <?php else: ?><?=strtoupper(mb_substr($partner,0,1,'UTF-8'))?><?php endif; ?>
  </div>

  <!-- Info -->
  <div style="flex:1;min-width:0">
    <div style="font-weight:700;font-size:.87rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e(mb_substr($d['listing_title'],0,40,'UTF-8'))?></div>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:2px">مع <?=e($partner)?></div>
    <div style="margin-top:6px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
      <span style="font-size:.82rem;font-weight:900;color:var(--gold);font-family:'JetBrains Mono',monospace"><?=money((float)$d['amount'])?></span>
      <?php if($isPending): ?>
        <span class="badge badge-warn" style="font-size:.6rem">⏳ انتظار (<?=$joinCount?>/3)</span>
      <?php elseif($isActive): ?>
        <span class="badge badge-ok" style="font-size:.6rem">● نشطة</span>
        <?php if($tl): ?><span class="timer-txt mono" style="font-size:.62rem;color:var(--txt3)">⏱ <?=$tl?></span><?php endif; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Unread badge -->
  <div class="unread-area" style="text-align:center;flex-shrink:0">
    <?php if($unread>0): ?>
    <div style="background:var(--gold);color:#06040a;font-weight:900;font-size:.7rem;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center"><?=$unread?></div>
    <div style="font-size:.58rem;color:var(--txt3);margin-top:3px">جديد</div>
    <?php else: ?>
    <div style="font-size:.65rem;color:var(--txt3)"><?=timeAgo($d['created_at'])?></div>
    <?php endif; ?>
  </div>

</a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php else: /* HISTORY */ ?>
<?php if(empty($historyDeals)): ?>
<div class="empty fade-up"><i class="fas fa-history"></i><p>لا توجد صفقات منتهية</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach($historyDeals as $d):
  $isBuyer = ($uid===(int)$d['buyer_id']);
  $partner = $isBuyer ? $d['seller_name'] : $d['buyer_name'];
  $colMap  = ['completed'=>'var(--green)','expired'=>'var(--red)','cancelled'=>'var(--txt3)'];
  $icMap   = ['completed'=>'✅','expired'=>'⏰','cancelled'=>'❌'];
  $lblMap  = ['completed'=>'مكتملة','expired'=>'منتهية','cancelled'=>'ملغاة'];
  $col = $colMap[$d['room_status']] ?? 'var(--txt2)';
  $ic  = $icMap[$d['room_status']]  ?? '•';
  $lbl = $lblMap[$d['room_status']] ?? $d['room_status'];
?>
<a href="deal.php?pid=<?=$d['purchase_id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:14px;display:flex;gap:12px;align-items:center;text-decoration:none;color:var(--txt);opacity:.8">
  <div style="width:46px;height:46px;border-radius:var(--r2);background:var(--card2);border:1px solid var(--border2);display:flex;align-items:center;justify-content:center;font-weight:900;color:var(--txt3);font-size:1rem;flex-shrink:0;filter:grayscale(.7)">
    <?=strtoupper(mb_substr($partner,0,1,'UTF-8'))?>
  </div>
  <div style="flex:1;min-width:0">
    <div style="font-weight:700;font-size:.87rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e(mb_substr($d['listing_title'],0,40,'UTF-8'))?></div>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:2px">مع <?=e($partner)?></div>
    <div style="margin-top:6px;display:flex;align-items:center;gap:6px">
      <span style="font-size:.82rem;font-weight:900;color:<?=$col?>;font-family:'JetBrains Mono',monospace"><?=money((float)$d['amount'])?></span>
      <span style="font-size:.7rem;color:<?=$col?>;font-weight:700"><?=$ic?> <?=$lbl?></span>
    </div>
  </div>
  <div style="font-size:.65rem;color:var(--txt3)"><?=timeAgo($d['created_at'])?></div>
</a>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php endif; ?>

</div>

<?php if($view==='active' && !empty($activeDeals)): ?>
<script>
(function(){
  var INTERVAL = 5000;
  var timer;
  function poll(){
    fetch('deals.php?ajax=poll',{credentials:'same-origin'})
      .then(r=>r.json()).then(data=>{
        if(!data.ok) return;
        data.deals.forEach(d=>{
          var row = document.querySelector('.deal-row[data-pid="'+d.pid+'"]');
          if(!row) return;
          // border
          row.style.border = d.unread>0 ? '1.5px solid var(--gold3)' : '1.5px solid var(--border)';
          // unread area
          var ua = row.querySelector('.unread-area');
          if(ua && d.unread>0){
            ua.innerHTML = '<div style="background:var(--gold);color:#06040a;font-weight:900;font-size:.7rem;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center">'+d.unread+'</div><div style="font-size:.58rem;color:var(--txt3);margin-top:3px">جديد</div>';
          }
          // timer
          if(d.time_left){
            var tt = row.querySelector('.timer-txt');
            if(tt) tt.textContent = '⏱ '+d.time_left;
          }
        });
      }).catch(()=>{})
      .finally(()=>{ timer=setTimeout(poll,INTERVAL); });
  }
  document.addEventListener('visibilitychange',()=>{ if(document.hidden) clearTimeout(timer); else poll(); });
  poll();
})();
</script>
<?php endif; ?>

<?php pageBottomNav('deals.php'); pageFoot(); ?>
