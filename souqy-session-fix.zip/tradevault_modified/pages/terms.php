<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$terms = getSetting($pdo,'terms_content','');
$how   = getSetting($pdo,'how_it_works','');
pageHead('الشروط والأحكام');
pageTopbar($pdo,'index.php','الشروط والأحكام');
?>
<div class="page" style="padding:16px 16px 90px">
<div class="card" style="margin-bottom:14px">
  <div class="card-hd"><i class="fas fa-file-contract"></i> الشروط والأحكام</div>
  <div style="font-size:.85rem;line-height:1.9;color:var(--txt2);white-space:pre-wrap"><?=e($terms)?:nl2br("1. يُحظر نشر محتوى مسروق أو وهمي.\n2. يُحظر الاحتيال وخداع المشترين.\n3. تُطبَّق عمولة 5% على كل صفقة.\n4. يحق للإدارة إلغاء أي صفقة مشبوهة.\n5. الحسابات المنتهكة تُعلَّق فوراً.")?></div>
</div>
<div class="card">
  <div class="card-hd"><i class="fas fa-question-circle"></i> كيف تعمل المنصة</div>
  <div style="font-size:.85rem;line-height:1.9;color:var(--txt2);white-space:pre-wrap"><?=e($how)?:nl2br("1. سجّل وأكمل التحقق من هويتك KYC.\n2. انشر إعلانك أو تصفح الإعلانات المتاحة.\n3. عند الشراء، يُحجز المبلغ تلقائياً.\n4. تنشأ محادثة ثلاثية (بائع + مشتري + أدمن) مدتها ساعتان.\n5. عند موافقة الثلاثة، تكتمل الصفقة ويُحرَّر المبلغ.")?></div>
</div>
</div>
<?php pageFoot(); ?>
