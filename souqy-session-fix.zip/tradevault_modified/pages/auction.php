<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
require_once '../includes/auction_helpers.php';

requireLogin(); // 🔒 حماية — يجب تسجيل الدخول أولاً

try { settleExpiredAuctions($pdo); } catch(Exception $e){}

$aid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$a   = null;
try { $a = getAuction($pdo, $aid); } catch(Exception $e){}
if (!$a) { header('Location:auctions.php'); exit; }

try { $pdo->prepare("UPDATE auctions SET views=views+1 WHERE id=?")->execute([$aid]); } catch(Exception $e){}

$uid  = uid();
$user = null;
if($uid) try { $user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch(); } catch(Exception $e){}

$msg = ''; $msgType = 'ok';

// BID ACTION
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf() && $uid && $user){
    if(strtotime($user['created_at']) > time()-86400){
        $msg='يجب انتظار 24 ساعة من تسجيل حسابك قبل المزايدة'; $msgType='err';
    } elseif(!checkBidRateLimit($pdo,$uid,$aid)){
        $msg='مزايدات كثيرة جداً — انتظر دقيقة'; $msgType='err';
    } else {
        $bidAmount = (float)str_replace(',','',$_POST['bid_amount']??0);
        try {
            $result  = placeBid($pdo,$aid,$uid,$bidAmount);
            $msg     = $result['msg'];
            $msgType = $result['ok']?'ok':'err';
        } catch(Exception $e){ $msg='خطأ: '.$e->getMessage(); $msgType='err'; }
        try { $a    = getAuction($pdo,$aid); } catch(Exception $e){}
        try { $user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch(); } catch(Exception $e){}
    }
}

$bids     = [];
$topBid   = null;
$myTopBid = null;
$roomId   = null;
try { $bids    = getRecentBids($pdo,$aid,20); } catch(Exception $e){}
try { $topBid  = getTopBid($pdo,$aid); } catch(Exception $e){}
if($uid) try {
    $mb = $pdo->prepare("SELECT MAX(bid_amount) FROM bids WHERE auction_id=? AND user_id=?");
    $mb->execute([$aid,$uid]); $myTopBid = $mb->fetchColumn() ?: null;
} catch(Exception $e){}
// جلب غرفة الشات إن وجدت
if($uid && $a['status']==='completed') try {
    $rq = $pdo->prepare("SELECT id FROM chats WHERE auction_id=? AND (winner_id=? OR seller_id2=?) LIMIT 1");
    $rq->execute([$aid,$uid,$uid]);
    $roomId = $rq->fetchColumn() ?: null;
} catch(Exception $e){}

$isEnded  = $a['status']!=='active' || strtotime($a['end_date'])<time();
$isWinner = $uid && (int)$a['winner_id']===$uid;
$isSeller = $uid && (int)$a['seller_id']===$uid;
$endTs    = strtotime($a['end_date'])*1000;
$startTs  = strtotime($a['start_date'])*1000;
$minInc   = (float)getSetting($pdo,'auction_min_increment','1');
$minNext  = round((float)$a['current_price']+$minInc,2);
$userBal  = $user ? (float)$user['balance'] : 0;
$userHeld = $user ? (float)$user['held_balance'] : 0;

pageHead(e($a['title']),'<style>
.bid-panel{background:linear-gradient(135deg,rgba(232,164,0,.07),rgba(232,164,0,.02));border:1px solid rgba(232,164,0,.25);border-radius:var(--r2);padding:16px;margin-bottom:14px}
.cur-price{font-size:1.8rem;font-weight:900;color:var(--gold);font-family:"JetBrains Mono",monospace;line-height:1}
.bal-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}
.bal-box{background:rgba(0,0,0,.25);border:1px solid var(--b1);border-radius:var(--r3);padding:10px;text-align:center}
.bal-v{font-size:.95rem;font-weight:900;font-family:"JetBrains Mono",monospace}
.bal-l{font-size:.6rem;color:var(--t2);margin-top:2px}
.bid-input-wrap{display:flex;gap:8px;margin-top:12px}
.bid-input{flex:1;background:rgba(0,0,0,.35);border:1.5px solid var(--b2);border-radius:var(--r3);padding:12px 14px;color:var(--t1);font-size:1rem;font-weight:700;font-family:"JetBrains Mono",monospace;outline:none;transition:.18s;direction:ltr;text-align:center;width:100%}
.bid-input:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(232,164,0,.1)}
.bid-btn{background:linear-gradient(135deg,var(--gold2),var(--gold),var(--gold3));color:#000;border:none;border-radius:var(--r3);padding:12px 20px;font-weight:900;font-size:.88rem;cursor:pointer;flex-shrink:0;transition:.18s}
.bid-btn:active{transform:scale(.96)}
.bid-btn:disabled{opacity:.35;cursor:not-allowed}
.hint{font-size:.63rem;color:var(--t2);margin-top:6px;text-align:center}
.cd-row{display:flex;gap:5px;justify-content:center;margin:10px 0}
.cd-b{background:rgba(0,0,0,.4);border:1px solid rgba(232,164,0,.15);border-radius:9px;padding:7px 8px;min-width:50px;text-align:center}
.cd-n{font-size:1.4rem;font-weight:900;color:var(--gold2);font-family:"JetBrains Mono",monospace;line-height:1;display:block}
.cd-l{font-size:.5rem;color:var(--t2);margin-top:2px;display:block}
.cd-sep{font-size:1.1rem;font-weight:900;color:rgba(232,164,0,.25);align-self:center;margin-bottom:10px}
.cd-bar-wrap{height:3px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden;margin-top:8px}
.cd-bar-fill{height:100%;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:3px}
.bid-hist{background:var(--card);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:14px}
.bid-hist-hd{padding:10px 14px;font-weight:800;font-size:.8rem;border-bottom:1px solid var(--b1);display:flex;align-items:center;gap:7px}
.bid-row{display:flex;align-items:center;gap:10px;padding:9px 14px;border-bottom:1px solid rgba(255,255,255,.03)}
.bid-row:last-child{border-bottom:none}
.bid-row.top-bid{background:rgba(232,164,0,.05)}
.ended-banner{background:rgba(255,71,87,.08);border:1px solid rgba(255,71,87,.2);border-radius:var(--r2);padding:14px;text-align:center;margin-bottom:14px}
.won-banner{background:rgba(16,217,122,.08);border:1px solid rgba(16,217,122,.25);border-radius:var(--r2);padding:14px;text-align:center;margin-bottom:14px}
</style>');
pageTopbar($pdo,'auctions.php',e(mb_substr($a['title'],0,30,'UTF-8')));
?>
<div class="page" style="padding:14px 14px 90px">

<?php if($msg) echo flash($msgType,$msg); ?>
<?php if(isset($_GET['created'])) echo flash('ok','✅ تم نشر مزادك بنجاح! يستمر 7 أيام.'); ?>

<?php if($a['image_path']): ?>
<div style="border-radius:var(--r2);overflow:hidden;margin-bottom:14px;height:200px">
  <img src="<?=e(assetUrl($a['image_path']))?>" style="width:100%;height:200px;object-fit:cover" alt="">
</div>
<?php endif; ?>

<div style="margin-bottom:14px">
  <div style="font-size:1.05rem;font-weight:900;margin-bottom:5px"><?=e($a['title'])?></div>
  <div style="font-size:.68rem;color:var(--t2);display:flex;gap:10px;flex-wrap:wrap">
    <span><i class="fas fa-eye" style="font-size:.55rem"></i> <?=$a['views']?></span>
    <span><i class="fas fa-gavel" style="font-size:.55rem"></i> <?=$a['bid_count']?> مزايدة</span>
    <span>البائع: @<?=e($a['seller_name'])?></span>
  </div>
</div>

<?php if($isWinner): ?>
<div class="won-banner">
  <div style="font-size:1.4rem;margin-bottom:5px">🏆</div>
  <div style="font-weight:900;color:var(--green);font-size:.95rem">تهانينا! فزت بهذا المزاد</div>
  <div style="font-size:.72rem;color:var(--t2);margin-top:3px">بمبلغ <?=money((float)$a['current_price'])?></div>
  <?php if($roomId): ?>
  <a href="auction_deal.php?rid=<?=$roomId?>" class="btn btn-gold" style="margin-top:10px;display:inline-flex;font-size:.8rem">
    <i class="fas fa-comments"></i> غرفة التسليم
  </a>
  <?php endif; ?>
</div>
<?php elseif($isSeller && $a['status']==='completed'): ?>
<div style="background:rgba(16,217,122,.07);border:1px solid rgba(16,217,122,.2);border-radius:var(--r2);padding:12px;text-align:center;margin-bottom:14px">
  <div style="font-weight:800;color:var(--green);font-size:.88rem">✅ انتهى مزادك بنجاح</div>
  <?php if($roomId): ?>
  <a href="auction_deal.php?rid=<?=$roomId?>" class="btn btn-gold" style="margin-top:8px;display:inline-flex;font-size:.8rem">
    <i class="fas fa-comments"></i> غرفة التسليم مع الفائز
  </a>
  <?php endif; ?>
</div>
<?php elseif($isEnded): ?>
<div class="ended-banner">
  <i class="fas fa-gavel" style="color:var(--red);font-size:1.2rem;display:block;margin-bottom:5px"></i>
  <div style="font-weight:800;color:var(--red)">انتهى المزاد</div>
  <?php if($a['winner_id']): ?>
    <div style="font-size:.7rem;color:var(--t2);margin-top:3px">الفائز: @<?=e($topBid['username']??'—')?> بمبلغ <?=money((float)$a['current_price'])?></div>
  <?php else: ?><div style="font-size:.7rem;color:var(--t2);margin-top:3px">لم تكن هناك مزايدات</div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- BID PANEL -->
<div class="bid-panel">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px">
    <div>
      <div class="cur-price"><?=money((float)$a['current_price'])?></div>
      <div style="font-size:.62rem;color:var(--t2);margin-top:2px">السعر الحالي</div>
    </div>
    <?php if(!$isEnded): ?>
    <div style="text-align:left">
      <div style="font-size:.58rem;color:var(--t2);margin-bottom:3px">ينتهي خلال</div>
      <div id="qcd" style="font-size:.8rem;font-weight:900;color:var(--red);font-family:'JetBrains Mono',monospace">--</div>
    </div>
    <?php endif; ?>
  </div>

  <?php if(!$isEnded): ?>
  <div class="cd-row">
    <div class="cd-b"><span class="cd-n" id="cdd">00</span><span class="cd-l">يوم</span></div>
    <div class="cd-sep">:</div>
    <div class="cd-b"><span class="cd-n" id="cdh">00</span><span class="cd-l">ساعة</span></div>
    <div class="cd-sep">:</div>
    <div class="cd-b"><span class="cd-n" id="cdm">00</span><span class="cd-l">دقيقة</span></div>
    <div class="cd-sep">:</div>
    <div class="cd-b"><span class="cd-n" id="cds">00</span><span class="cd-l">ثانية</span></div>
  </div>
  <div class="cd-bar-wrap"><div class="cd-bar-fill" id="cd-fill" style="width:0%"></div></div>
  <?php endif; ?>

  <?php if($uid && !$isEnded && !$isSeller): ?>
  <div class="bal-row">
    <div class="bal-box">
      <div class="bal-v"><?=money($userBal)?></div>
      <div class="bal-l">رصيدك المتاح</div>
    </div>
    <div class="bal-box">
      <div class="bal-v" style="color:var(--t2)"><?=money($userHeld)?></div>
      <div class="bal-l">محجوز</div>
    </div>
  </div>
  <?php if($myTopBid): ?>
  <div style="font-size:.7rem;color:var(--gold);text-align:center;margin-bottom:8px">
    <i class="fas fa-bolt"></i> مزايدتك: <strong><?=money((float)$myTopBid)?></strong>
    <?php if($topBid && (int)$topBid['user_id']===$uid): ?>
      <span style="color:var(--green)">— أنت الأعلى ✓</span>
    <?php else: ?><span style="color:var(--red)">— تم تجاوزك!</span><?php endif; ?>
  </div>
  <?php endif; ?>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <div class="bid-input-wrap">
      <input type="number" name="bid_amount" id="bidInp" class="bid-input"
             min="<?=$minNext?>" step="<?=$minInc?>"
             value="<?=number_format($minNext,2,'.','')?>" required>
      <button type="submit" class="bid-btn" id="bidBtn">
        <i class="fas fa-gavel"></i> زايد
      </button>
    </div>
    <div class="hint">أدنى مزايدة: <strong><?=money($minNext)?></strong> · رصيدك: <strong><?=money($userBal)?></strong></div>
  </form>
  <?php elseif(!$uid && !$isEnded): ?>
  <a href="login.php" class="btn btn-gold btn-block" style="margin-top:12px;justify-content:center">
    <i class="fas fa-sign-in-alt"></i> سجّل دخولك للمزايدة
  </a>
  <?php elseif($isSeller && !$isEnded): ?>
  <div style="text-align:center;padding:10px;font-size:.75rem;color:var(--t2);margin-top:8px">
    <i class="fas fa-info-circle" style="color:var(--gold)"></i> هذا مزادك — لا يمكنك المزايدة عليه
  </div>
  <?php endif; ?>
</div>

<?php if($a['description']): ?>
<div style="background:var(--card);border:1px solid var(--b1);border-radius:var(--r2);padding:14px;margin-bottom:14px">
  <div style="font-weight:800;font-size:.78rem;margin-bottom:7px"><i class="fas fa-align-left" style="color:var(--gold)"></i> تفاصيل المزاد</div>
  <div style="font-size:.78rem;color:var(--t2);line-height:1.7;white-space:pre-line"><?=e($a['description'])?></div>
</div>
<?php endif; ?>

<div class="bid-hist">
  <div class="bid-hist-hd">
    <i class="fas fa-history" style="color:var(--t2)"></i>
    سجل المزايدات
    <span style="margin-right:auto;font-size:.62rem;color:var(--t3);font-weight:400"><?=$a['bid_count']?> مزايدة</span>
  </div>
  <?php if(empty($bids)): ?>
    <div style="padding:20px;text-align:center;color:var(--t2);font-size:.75rem">لا توجد مزايدات — كن الأول!</div>
  <?php else: foreach($bids as $i=>$b): ?>
    <div class="bid-row <?=$i===0?'top-bid':''?>">
      <?php if($i===0): ?><i class="fas fa-crown" style="color:var(--gold);font-size:.65rem"></i><?php endif; ?>
      <div style="flex:1;font-size:.75rem;font-family:'JetBrains Mono',monospace;color:var(--t2)"><?=maskUsername($b['username'])?></div>
      <div style="font-size:.8rem;font-weight:800;color:var(--gold);font-family:'JetBrains Mono',monospace"><?=money((float)$b['bid_amount'])?></div>
      <div style="font-size:.6rem;color:var(--t3)"><?=timeAgo($b['created_at'])?></div>
    </div>
  <?php endforeach; endif; ?>
</div>

</div>
<script>
(function(){
  var end=<?=$endTs?>,start=<?=$startTs?>,total=end-start;
  function p(n){return String(n).padStart(2,'0');}
  function tick(){
    var now=Date.now(),diff=Math.max(0,end-now);
    var d=Math.floor(diff/86400000),h=Math.floor(diff%86400000/3600000),m=Math.floor(diff%3600000/60000),s=Math.floor(diff%60000/1000);
    var dEl=document.getElementById('cdd');
    if(dEl){dEl.textContent=p(d);document.getElementById('cdh').textContent=p(h);document.getElementById('cdm').textContent=p(m);document.getElementById('cds').textContent=p(s);}
    var qEl=document.getElementById('qcd');
    if(qEl) qEl.textContent=d>0?(d+'ي '+p(h)+'س'):(h>0?(p(h)+':'+p(m)):(p(m)+':'+p(s)));
    var fill=document.getElementById('cd-fill');
    if(fill) fill.style.width=Math.min(100,(Date.now()-start)/total*100).toFixed(1)+'%';
    if(diff===0&&!window._reloaded){window._reloaded=true;setTimeout(function(){location.reload();},3000);}
  }
  tick(); setInterval(tick,7000);
  var inp=document.getElementById('bidInp');
  var bal=<?=$userBal?>;
  if(inp) inp.addEventListener('input',function(){
    var btn=document.getElementById('bidBtn');
    if(btn) btn.disabled=(parseFloat(this.value)||0)>bal;
  });
})();
</script>
<?php pageBottomNav(); pageFoot(); ?>
