<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

// Filter by ad type
$typeFilter = (int)($_GET['type'] ?? 0);

$typesList = $pdo->query("SELECT * FROM ad_types WHERE status='active' ORDER BY name")->fetchAll();

if ($typeFilter) {
    $stmt = $pdo->prepare("SELECT a.*, u.username, at.name type_name, at.icon type_icon
        FROM ads a
        JOIN users u ON a.user_id = u.id
        JOIN ad_types at ON a.ad_type_id = at.id
        WHERE a.status='active' AND (a.end_date IS NULL OR a.end_date >= CURDATE()) AND a.ad_type_id=?
        ORDER BY a.created_at DESC");
    $stmt->execute([$typeFilter]);
} else {
    $stmt = $pdo->query("SELECT a.*, u.username, at.name type_name, at.icon type_icon
        FROM ads a
        JOIN users u ON a.user_id = u.id
        JOIN ad_types at ON a.ad_type_id = at.id
        WHERE a.status='active' AND (a.end_date IS NULL OR a.end_date >= CURDATE())
        ORDER BY a.created_at DESC");
}
$ads = $stmt->fetchAll();

pageHead('الإعلانات', '');
pageTopbar($pdo, 'index.php', '📢 الإعلانات');
?>
<div class="page" style="padding:16px 16px 90px">

<!-- Filter by type -->
<div style="overflow-x:auto;white-space:nowrap;margin-bottom:14px;padding-bottom:4px">
  <a href="ads.php" style="display:inline-block;padding:6px 14px;border-radius:20px;font-size:.75rem;font-weight:700;margin-left:6px;text-decoration:none;
    background:<?=$typeFilter===0?'var(--gold)':'var(--card)'?>;
    color:<?=$typeFilter===0?'#000':'var(--txt2)'?>;
    border:1px solid <?=$typeFilter===0?'var(--gold)':'var(--border)'?>">الكل</a>
  <?php foreach($typesList as $t): ?>
  <a href="ads.php?type=<?=$t['id']?>" style="display:inline-block;padding:6px 14px;border-radius:20px;font-size:.75rem;font-weight:700;margin-left:6px;text-decoration:none;
    background:<?=$typeFilter==(int)$t['id']?'var(--gold)':'var(--card)'?>;
    color:<?=$typeFilter==(int)$t['id']?'#000':'var(--txt2)'?>;
    border:1px solid <?=$typeFilter==(int)$t['id']?'var(--gold)':'var(--border)'?>"><?=e($t['name'])?></a>
  <?php endforeach; ?>
</div>

<?php if(isLoggedIn()): ?>
<a href="create-ad.php" class="btn btn-gold btn-block" style="margin-bottom:14px"><i class="fas fa-plus-circle"></i> إضافة إعلان جديد</a>
<?php endif; ?>

<?php if(!$ads): ?>
<div class="card" style="text-align:center;padding:40px 20px;color:var(--txt3)">
  <i class="fas fa-ad" style="font-size:2rem;margin-bottom:12px;display:block"></i>
  لا توجد إعلانات نشطة حالياً
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:10px">
<?php foreach($ads as $ad): ?>
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:14px">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <div style="display:flex;align-items:center;gap:8px">
      <span style="background:var(--gold)22;color:var(--gold);border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700">
        <?php if($ad['type_icon']): ?><i class="<?=e($ad['type_icon'])?>"></i> <?php endif; ?>
        <?=e($ad['type_name'])?>
      </span>
    </div>
    <span style="font-size:.65rem;color:var(--txt3)"><?=timeAgo($ad['created_at'])?></span>
  </div>
  <?php if($ad['title']): ?>
  <div style="font-weight:700;font-size:.9rem;margin-bottom:6px"><?=e($ad['title'])?></div>
  <?php endif; ?>
  <div style="font-size:.82rem;color:var(--txt2);word-break:break-all;margin-bottom:10px">
    <?php
    $content = $ad['content'];
    if(filter_var($content, FILTER_VALIDATE_URL)):
    ?>
    <a href="<?=e($content)?>" target="_blank" rel="nofollow noopener" style="color:var(--gold)"><i class="fas fa-link"></i> <?=e(mb_substr($content,0,60,'UTF-8')).(mb_strlen($content,'UTF-8')>60?'...':'')?></a>
    <?php else: ?>
    <?=e(mb_substr($content,0,200,'UTF-8')).(mb_strlen($content,'UTF-8')>200?'...':'')?>
    <?php endif; ?>
  </div>
  <div style="display:flex;align-items:center;justify-content:space-between;font-size:.72rem;color:var(--txt3)">
    <span><i class="fas fa-user"></i> <?=e($ad['username'])?></span>
    <?php if($ad['end_date']): ?>
    <span><i class="fas fa-calendar-alt"></i> ينتهي: <?=e($ad['end_date'])?></span>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

</div>
<?php pageFoot(); ?>
