<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$uid = uid();
$msg = ''; $msgType = 'ok';

// Handle form submission
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()) {
    $adTypeId = (int)($_POST['ad_type_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $duration = (int)($_POST['duration'] ?? getSetting($pdo,'ad_default_duration','30'));

    if(!$adTypeId || !$content) {
        $msg = '❌ يرجى ملء جميع الحقول المطلوبة'; $msgType = 'err';
    } else {
        // Check daily limit
        $dailyLimit = (int)getSetting($pdo,'ad_daily_limit','2');
        $todayCount = (int)$pdo->prepare("SELECT COUNT(*) FROM ads WHERE user_id=? AND DATE(created_at)=CURDATE()")->execute([$uid]) ?
            $pdo->prepare("SELECT COUNT(*) FROM ads WHERE user_id=? AND DATE(created_at)=CURDATE()")->execute([$uid]) : 0;
        $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM ads WHERE user_id=? AND DATE(created_at)=CURDATE()");
        $stmtCount->execute([$uid]);
        $todayCount = (int)$stmtCount->fetchColumn();

        if($todayCount >= $dailyLimit) {
            $msg = "❌ لقد تجاوزت الحد اليومي للإعلانات ($dailyLimit إعلانات في اليوم)"; $msgType = 'err';
        } else {
            // Get price from ad type or base price
            $adType = $pdo->prepare("SELECT * FROM ad_types WHERE id=? AND status='active'");
            $adType->execute([$adTypeId]);
            $adType = $adType->fetch();
            if(!$adType) { $msg='❌ نوع الإعلان غير صالح'; $msgType='err'; }
            else {
                $price = ($adType['price'] > 0) ? (float)$adType['price'] : (float)getSetting($pdo,'ad_base_price','5');
                $startDate = date('Y-m-d');
                $endDate = date('Y-m-d', strtotime("+$duration days"));
                $pdo->prepare("INSERT INTO ads(user_id,ad_type_id,title,content,price,duration,start_date,end_date,status)VALUES(?,?,?,?,?,?,?,?,'pending')")
                    ->execute([$uid,$adTypeId,$title?:null,$content,$price,$duration,$startDate,$endDate]);
                // Notify admin
                $admins = $pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll();
                foreach($admins as $admin) {
                    addNotif($pdo,$admin['id'],'new_ad','📢 إعلان جديد بانتظار الموافقة','../admin/ads.php');
                }
                header('Location: ads.php?created=1'); exit;
            }
        }
    }
}

$adTypes = $pdo->query("SELECT * FROM ad_types WHERE status='active' ORDER BY name")->fetchAll();
$defaultDuration = getSetting($pdo,'ad_default_duration','30');
$basePrice = getSetting($pdo,'ad_base_price','5');

pageHead('إنشاء إعلان جديد','');
pageTopbar($pdo,'index.php','📢 إعلان جديد');
?>
<div class="page" style="padding:16px 16px 90px">

<?php if($msg): echo '<div class="alert alert-'.$msgType.'"><i class="fas fa-'.($msgType==='ok'?'check-circle':'times-circle').'"></i><span>'.e($msg).'</span></div>'; endif; ?>

<div class="card">
  <div class="card-hd"><i class="fas fa-plus-circle"></i> إنشاء إعلان جديد</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">

    <div class="fg">
      <label>نوع الإعلان <span style="color:var(--red)">*</span></label>
      <select name="ad_type_id" id="adTypeSelect" class="fsel" required onchange="updatePrice(this)">
        <option value="">— اختر نوع الإعلان —</option>
        <?php foreach($adTypes as $t): ?>
        <option value="<?=$t['id']?>" data-price="<?=e($t['price'])?>">
          <?=e($t['name'])?>
          <?php if($t['price']>0): ?> (<?=money((float)$t['price'])?>)<?php endif; ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="fg">
      <label>عنوان الإعلان (اختياري)</label>
      <input type="text" name="title" class="fi" placeholder="عنوان مختصر للإعلان...">
    </div>

    <div class="fg">
      <label>رابط أو نص الإعلان <span style="color:var(--red)">*</span></label>
      <textarea name="content" class="fta" rows="4" required placeholder="أدخل الرابط أو وصف الإعلان..."></textarea>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg">
        <label>السعر</label>
        <input type="text" id="priceDisplay" class="fi" value="<?=money((float)$basePrice)?>" readonly style="background:var(--bg3);color:var(--gold);font-weight:700">
      </div>
      <div class="fg">
        <label>المدة (أيام)</label>
        <input type="number" name="duration" class="fi" min="1" max="365" value="<?=e($defaultDuration)?>">
      </div>
    </div>

    <div class="form-hint" style="margin-bottom:12px;color:var(--txt3);font-size:.78rem">
      <i class="fas fa-info-circle"></i> بعد إرسال الإعلان، سيتم مراجعته من الأدمن قبل نشره.
    </div>

    <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-paper-plane"></i> إرسال للمراجعة</button>
  </form>
</div>

<a href="ads.php" class="btn btn-ghost btn-block" style="margin-top:10px"><i class="fas fa-arrow-right"></i> عرض الإعلانات</a>

</div>
<script>
const basePrice = <?=json_encode($basePrice)?>;
function updatePrice(sel){
  const opt = sel.options[sel.selectedIndex];
  const p = opt.dataset.price;
  const price = (p && parseFloat(p) > 0) ? parseFloat(p) : parseFloat(basePrice);
  document.getElementById('priceDisplay').value = '$' + price.toFixed(2);
}
</script>
<?php pageFoot(); ?>
