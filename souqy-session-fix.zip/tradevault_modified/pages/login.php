<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
if(isLoggedIn()){ header('Location:dashboard.php'); exit; }

$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $login=trim($_POST['login']??'');
    $pw=$_POST['password']??'';
    if(!$login||!$pw){ $errors[]='جميع الحقول مطلوبة'; }
    else {
        $stmt=$pdo->prepare("SELECT * FROM users WHERE username=? OR email=? OR unique_id=? LIMIT 1");
        $stmt->execute([$login,$login,$login]);
        $user=$stmt->fetch();
        if(!$user || !verifyPassword($pw,$user['password'])){
            $errors[]='بيانات تسجيل الدخول غير صحيحة';
        } elseif($user['is_banned']){
            $errors[]='تم حظر هذا الحساب. تواصل مع الدعم.';
        } else {
            ensureUniqueId($pdo,(int)$user['id']);
            // ✅ نحدد بيانات الجلسة أولاً، ثم نجدد الـ ID بأمان
            // session_regenerate_id مع true قد تسبب فقدان الكوكي في WebViews
            // لذلك نكتفي بـ false (نحتفظ بالبيانات ونغير الـ ID فقط)
            session_regenerate_id(false);
            $_SESSION['uid']       = (int)$user['id'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['is_admin']  = (int)$user['is_admin'];
            $_SESSION['_db_check'] = time();
            // حفظ الجلسة يدوياً قبل الـ redirect لضمان كتابتها على الديسك
            session_write_close();
            addActivityLog($pdo,'user','تسجيل دخول: '.$user['username'],(int)$user['id'],'user');
            $redirect = $_SESSION['_redirect_after_login'] ?? '';
            if ($user['is_admin']) {
                header('Location: ../admin/index.php', true, 302); exit;
            } elseif ($redirect && strpos($redirect, '/pages/') !== false) {
                header('Location: ' . $redirect, true, 302); exit;
            } else {
                header('Location: dashboard.php', true, 302); exit;
            }
        }
    }
}
$siteName = getSiteName($pdo);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#060810">
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link rel="shortcut icon" href="../assets/img/favicon.svg">
<title>تسجيل الدخول — <?=e($siteName)?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{min-height:100vh;background:#060810;color:#f0f3ff;font-family:'Tajawal',sans-serif;direction:rtl;overflow-x:hidden}
body{display:flex;align-items:stretch;justify-content:center;position:relative}

.noise{position:fixed;inset:0;z-index:0;opacity:.025;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");background-size:200px;pointer-events:none}

.glow-orb{position:fixed;border-radius:50%;filter:blur(90px);pointer-events:none;z-index:0}
.orb1{width:550px;height:400px;background:radial-gradient(circle,rgba(232,164,0,0.07),transparent 70%);top:-120px;left:-80px;animation:orbA 14s ease-in-out infinite}
.orb2{width:400px;height:400px;background:radial-gradient(circle,rgba(16,217,122,0.04),transparent 70%);bottom:-80px;right:-60px;animation:orbA 11s ease-in-out infinite reverse}
@keyframes orbA{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(15px,-25px) scale(1.05)}}

.grid-bg{position:fixed;inset:0;z-index:0;background-image:linear-gradient(rgba(255,255,255,.022) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.022) 1px,transparent 1px);background-size:55px 55px;mask-image:radial-gradient(ellipse 70% 70% at 50% 50%,black,transparent)}

/* top accent line */
.top-line{position:fixed;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent 0%,#e8a400 30%,#f5c842 50%,#e8a400 70%,transparent 100%);z-index:10;animation:lineGrow .8s ease both}
@keyframes lineGrow{from{opacity:0;transform:scaleX(0)}to{opacity:1;transform:scaleX(1)}}

.wrap{position:relative;z-index:1;width:100%;max-width:430px;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px 18px 48px}

.logo-row{display:flex;align-items:center;gap:10px;margin-bottom:26px;animation:fsd .6s cubic-bezier(.22,1,.36,1) both}
.logo-gem{width:42px;height:42px;border-radius:13px;background:linear-gradient(135deg,#e8a400,#b87d00);display:flex;align-items:center;justify-content:center;font-size:1.15rem;box-shadow:0 4px 20px rgba(232,164,0,.35),inset 0 1px 0 rgba(255,255,255,.2)}
.logo-name{font-size:1.25rem;font-weight:900;letter-spacing:-.4px}
.logo-name em{color:#e8a400;font-style:normal}
@keyframes fsd{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:translateY(0)}}

.card{width:100%;background:linear-gradient(155deg,rgba(255,255,255,.048) 0%,rgba(255,255,255,.018) 100%);border:1px solid rgba(255,255,255,.08);border-top:1px solid rgba(255,255,255,.13);border-radius:22px;padding:28px 22px;backdrop-filter:blur(24px);box-shadow:0 28px 65px rgba(0,0,0,.52),inset 0 1px 0 rgba(255,255,255,.06);animation:fsu .65s cubic-bezier(.22,1,.36,1) .12s both}
@keyframes fsu{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:translateY(0)}}

.head{text-align:center;margin-bottom:24px}
.head-icon{width:58px;height:58px;border-radius:17px;margin:0 auto 13px;background:linear-gradient(135deg,rgba(232,164,0,.16),rgba(232,164,0,.04));border:1px solid rgba(232,164,0,.2);display:flex;align-items:center;justify-content:center;font-size:1.55rem;animation:iconP 3s ease-in-out infinite}
@keyframes iconP{0%,100%{box-shadow:0 0 0 0 rgba(232,164,0,.18)}60%{box-shadow:0 0 0 10px rgba(232,164,0,0)}}
.head h1{font-size:1.22rem;font-weight:900;margin-bottom:5px}
.head p{font-size:.78rem;color:#8b95b5}

/* welcome badge */
.welcome-badge{display:flex;align-items:center;justify-content:center;gap:8px;background:rgba(232,164,0,.06);border:1px solid rgba(232,164,0,.12);border-radius:30px;padding:7px 16px;font-size:.75rem;color:#e8a400;font-weight:700;margin-bottom:20px}
.welcome-dot{width:6px;height:6px;border-radius:50%;background:#e8a400;animation:dotBlink 1.5s ease-in-out infinite}
@keyframes dotBlink{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}

.errs{background:rgba(255,71,87,.08);border:1px solid rgba(255,71,87,.18);border-radius:12px;padding:12px 14px;margin-bottom:16px}
.errs-row{display:flex;align-items:center;gap:8px;font-size:.82rem;font-weight:700;color:#ff8591}
.errs-row i{flex-shrink:0}

.fg{margin-bottom:14px}
.fg label{display:flex;align-items:center;gap:7px;font-size:.76rem;font-weight:700;color:#8b95b5;margin-bottom:6px;letter-spacing:.2px}
.fg label i{font-size:.66rem;color:#e8a400;opacity:.85}
.fi{width:100%;padding:12px 14px;background:rgba(255,255,255,.035);border:1.5px solid rgba(255,255,255,.07);border-radius:11px;color:#f0f3ff;font-size:.88rem;font-family:'Tajawal',sans-serif;transition:all .2s ease;outline:none;-webkit-appearance:none}
.fi::placeholder{color:#3d4868}
.fi:focus{border-color:#e8a400;background:rgba(232,164,0,.03);box-shadow:0 0 0 3px rgba(232,164,0,.09)}

.pw-wrap{position:relative}
.pw-wrap .fi{padding-left:44px}
.pw-eye{position:absolute;left:13px;top:50%;transform:translateY(-50%);background:none;border:none;color:#3d4868;cursor:pointer;font-size:.88rem;transition:color .2s;padding:4px}
.pw-eye:hover{color:#8b95b5}

.btn-login{width:100%;padding:14px;border-radius:13px;border:none;background:linear-gradient(135deg,#e8a400,#b87d00);color:#000;font-size:.94rem;font-weight:900;font-family:'Tajawal',sans-serif;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .25s ease;margin-top:6px;box-shadow:0 6px 22px rgba(232,164,0,.28);letter-spacing:.2px;position:relative;overflow:hidden}
.btn-login::before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.13),transparent);transform:translateX(-100%);transition:transform .5s}
.btn-login:hover::before{transform:translateX(100%)}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 10px 30px rgba(232,164,0,.42)}
.btn-login:active{transform:translateY(0)}
.btn-login.loading{opacity:.72;pointer-events:none}
.spin{width:17px;height:17px;border:2.5px solid rgba(0,0,0,.18);border-top-color:#000;border-radius:50%;animation:spin .6s linear infinite;display:none}
@keyframes spin{to{transform:rotate(360deg)}}

/* security features row */
.sec-row{display:flex;justify-content:center;gap:14px;margin-top:16px;flex-wrap:wrap}
.sec-item{display:flex;align-items:center;gap:5px;font-size:.67rem;color:#3d4868}
.sec-item i{color:#10d97a;font-size:.6rem}

.div-or{display:flex;align-items:center;gap:10px;margin:18px 0 14px}
.div-or::before,.div-or::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.06)}
.div-or span{font-size:.7rem;color:#3d4868}

.foot-link{text-align:center;font-size:.83rem;color:#8b95b5}
.foot-link a{color:#e8a400;font-weight:800;text-decoration:none;transition:color .2s}
.foot-link a:hover{color:#f5c842}

/* input shake animation on error */
@keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-6px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(4px)}}
.shake{animation:shake .4s ease}
</style>
</head>
<body>
<div class="top-line"></div>
<div class="noise"></div>
<div class="glow-orb orb1"></div>
<div class="glow-orb orb2"></div>
<div class="grid-bg"></div>

<div class="wrap">
  <div class="logo-row">
    <div class="logo-gem">💎</div>
    <div class="logo-name">Trade<em>Vault</em></div>
  </div>

  <div class="card">
    <div class="head">
      <div class="head-icon">🔑</div>
      <h1>مرحباً بعودتك</h1>
      <p><?=e($siteName)?> — سوق رقمي موثوق للبيع والشراء الآمن</p>
    </div>

    <div class="welcome-badge">
      <div class="welcome-dot"></div>
      المنصة نشطة ومتاحة الآن
    </div>

    <?php if($errors): ?>
    <div class="errs" id="errBox">
      <?php foreach($errors as $err): ?>
      <div class="errs-row"><i class="fas fa-exclamation-circle"></i> <?=e($err)?></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <form method="POST" id="loginForm" novalidate>
      <input type="hidden" name="_csrf" value="<?=csrf()?>">

      <div class="fg">
        <label><i class="fas fa-user"></i> اسم المستخدم / البريد / المعرف</label>
        <input type="text" name="login" class="fi <?=$errors?'shake':''?>" id="loginIn"
               placeholder="أدخل اسم المستخدم أو البريد أو TV..."
               required value="<?=e($_POST['login']??'')?>"
               autocomplete="username" autocapitalize="none">
      </div>

      <div class="fg">
        <label><i class="fas fa-lock"></i> كلمة المرور</label>
        <div class="pw-wrap">
          <input type="password" name="password" class="fi <?=$errors?'shake':''?>" id="pwIn"
                 placeholder="كلمة المرور" required autocomplete="current-password">
          <button type="button" class="pw-eye" onclick="togglePw()"><i class="fas fa-eye" id="eyeIco"></i></button>
        </div>
      </div>

      <button type="submit" class="btn-login" id="subBtn">
        <span id="btnTxt"><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</span>
        <div class="spin" id="btnSpin"></div>
      </button>
    </form>

    <div class="sec-row">
      <div class="sec-item"><i class="fas fa-shield-alt"></i> اتصال آمن</div>
      <div class="sec-item"><i class="fas fa-lock"></i> مشفّر SSL</div>
      <div class="sec-item"><i class="fas fa-user-shield"></i> حماية كاملة</div>
    </div>

    <div class="div-or"><span>أو</span></div>
    <div class="foot-link">ليس لديك حساب؟ <a href="register.php">إنشاء حساب مجاني</a></div>
  </div>
</div>

<script>
function togglePw(){
  const i=document.getElementById('pwIn'),ic=document.getElementById('eyeIco');
  i.type=i.type==='password'?'text':'password';
  ic.className=i.type==='password'?'fas fa-eye':'fas fa-eye-slash';
}
document.getElementById('loginForm').addEventListener('submit',function(){
  const b=document.getElementById('subBtn');
  b.classList.add('loading');
  document.getElementById('btnTxt').style.display='none';
  document.getElementById('btnSpin').style.display='block';
});
// Auto-focus first empty field
window.addEventListener('load',function(){
  const li=document.getElementById('loginIn');
  if(!li.value) li.focus();
  else document.getElementById('pwIn').focus();
});
</script>
</body>
</html>
