<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
// حماية الصفحة — يجب تسجيل الدخول
requireLogin();

// Featured listings
$cats = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();
$selCat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$q = "SELECT l.*,c.name cat_name,c.icon cat_icon,u.username seller_name,u.seller_rating,u.profile_pic
      FROM listings l
      JOIN categories c ON l.category_id=c.id
      JOIN users u ON l.user_id=u.id
      WHERE l.status='active' AND l.expires_at>NOW()";
if($selCat) $q .= " AND l.category_id=$selCat";
$q .= " ORDER BY l.created_at DESC LIMIT 40";
$listings = $pdo->query($q)->fetchAll();

// Stats
$totalListings = $pdo->query("SELECT COUNT(*) FROM listings WHERE status='active'")->fetchColumn();
$totalUsers    = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0")->fetchColumn();
$totalSales    = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status='completed'")->fetchColumn();

pageHead('الرئيسية');
pageTopbar($pdo);
?>
<div class="page">

<!-- HERO -->
<div class="hero" style="padding:24px 16px 20px">
  <div style="font-size:1.55rem;font-weight:900;line-height:1.3;margin-bottom:6px">
    اشترِ وبع <span class="gold">حساباتك الرقمية</span><br>بأمان تام 🔐
  </div>
  <p style="font-size:.82rem;color:var(--txt2);margin-bottom:18px;line-height:1.6">
    منصة وساطة آمنة لبيع وشراء الحسابات الرقمية — مع ضمان استلام المنتج أو استرداد المبلغ كامل 🔐
  </p>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:18px">
    <div class="stat-box"><div class="stat-val"><?=number_format((int)$totalListings)?></div><div class="stat-lbl">إعلان نشط</div></div>
    <div class="stat-box"><div class="stat-val"><?=number_format((int)$totalUsers)?></div><div class="stat-lbl">مستخدم موثق</div></div>
    <div class="stat-box"><div class="stat-val"><?=number_format((int)$totalSales)?></div><div class="stat-lbl">صفقة ناجحة</div></div>
  </div>
  <?php if(!isLoggedIn()): ?>
  <div style="display:flex;gap:10px">
    <a href="register.php" class="btn btn-gold" style="flex:1">ابدأ الآن</a>
    <a href="login.php" class="btn btn-outline" style="flex:1">تسجيل الدخول</a>
  </div>
  <?php else: ?>
  <a href="sell.php" class="btn btn-gold btn-block">+ نشر إعلان جديد</a>
  <?php endif; ?>
</div>

<!-- CATEGORIES SCROLL -->
<div style="padding:16px 0 4px;overflow-x:auto;-webkit-overflow-scrolling:touch">
  <div style="display:flex;gap:8px;padding:0 16px;min-width:max-content">
    <a href="index.php" class="<?=$selCat===0?'btn btn-gold btn-sm':'btn btn-ghost btn-sm'?>">الكل</a>
    <?php foreach($cats as $c): ?>
    <a href="?cat=<?=$c['id']?>" class="<?=$selCat===$c['id']?'btn btn-gold btn-sm':'btn btn-ghost btn-sm'?>">
      <i class="fas <?=e($c['icon'])?>"></i> <?=e($c['name'])?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- LISTINGS GRID -->
<div class="sec">
  <div class="sec-hd">
    <div class="sec-title">الإعلانات النشطة</div>
    <a href="category.php" class="sec-link">عرض الكل</a>
  </div>
</div>

<?php if(empty($listings)): ?>
<div class="empty fade-up"><i class="fas fa-box-open"></i><p>لا توجد إعلانات بعد<br>كن أول من ينشر!</p></div>
<?php else: ?>
<div class="grid-2 fade-up" style="padding:0 16px 16px">
  <?php foreach($listings as $l): echo listingCard($pdo,$l); endforeach; ?>
</div>
<?php endif; ?>

<!-- HOW IT WORKS -->
<div class="sec" style="padding-bottom:16px">
  <div class="sec-hd"><div class="sec-title">كيف يعمل سوقي؟</div></div>
  <div style="display:flex;flex-direction:column;gap:10px">
    <?php
    $steps=[
      ['fa-user-shield','سجّل وتحقق من هويتك KYC','يُطلب منك رفع بطاقتك وصورة شخصية مرة واحدة فقط لضمان الموثوقية'],
      ['fa-store','انشر منتجك الرقمي أو تصفح العروض','حدد الفئة والسعر والوصف وأضف صوراً توضيحية للمنتج'],
      ['fa-comments','محادثة ثلاثية آمنة — ضمان التسليم','بائع + مشتري + أدمن في محادثة مشتركة للتأكد من صحة المنتج'],
      ['fa-check-double','إتمام الصفقة وتحرير الأموال','بعد تأكيد الاستلام يُحوَّل المبلغ للبائع وتُستكمل الصفقة بنجاح'],
    ];
    foreach($steps as $i=>[$ic,$title,$desc]):
    ?>
    <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:14px;display:flex;gap:12px;align-items:flex-start">
      <div style="width:36px;height:36px;border-radius:var(--r3);background:var(--gold-glow);border:1px solid var(--gold3);display:flex;align-items:center;justify-content:center;color:var(--gold);flex-shrink:0">
        <i class="fas <?=$ic?>"></i>
      </div>
      <div>
        <div style="font-size:.85rem;font-weight:700;margin-bottom:3px"><?=e($title)?></div>
        <div style="font-size:.75rem;color:var(--txt2);line-height:1.5"><?=e($desc)?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- TOP SELLERS PREVIEW -->
<?php
$topSellers = $pdo->query("SELECT username,seller_rating,total_sales,profile_pic FROM users WHERE is_admin=0 AND is_banned=0 ORDER BY seller_rating DESC LIMIT 5")->fetchAll();
if($topSellers):
?>
<div class="sec" style="padding-bottom:16px">
  <div class="sec-hd">
    <div class="sec-title">أفضل البائعين</div>
    <a href="top-users.php" class="sec-link">المزيد</a>
  </div>
  <div style="display:flex;flex-direction:column;gap:8px">
    <?php foreach($topSellers as $i=>$u): ?>
    <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="font-size:.8rem;font-weight:900;color:var(--txt3);width:20px;text-align:center"><?=$i+1?></div>
      <div class="user-chip-av">
        <?php if($u['profile_pic']): ?><img src="<?=e(assetUrl($u['profile_pic']))?>" alt=""><?php else: ?><?=strtoupper(mb_substr($u['username'],0,1,'UTF-8'))?><?php endif; ?>
      </div>
      <div style="flex:1">
        <div class="user-chip-name"><?=e($u['username'])?></div>
        <div class="user-chip-meta"><?=$u['total_sales']?> صفقة ناجحة</div>
      </div>
      <div class="stars"><?=str_repeat('★',min((int)$u['seller_rating'],5))?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

</div>

<?php pageBottomNav('index.php'); pageFoot(); ?>
