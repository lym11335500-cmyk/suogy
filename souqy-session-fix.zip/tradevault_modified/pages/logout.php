<?php
/**
 * logout.php — تسجيل الخروج
 * يمسح الجلسة ويوجّه للتسجيل
 */
require_once '../includes/db.php';

// تسجيل نشاط الخروج قبل مسح الجلسة
if (isset($_SESSION['uid']) && isset($pdo)) {
    try {
        addActivityLog($pdo, 'user', 'تسجيل خروج: '.($_SESSION['username']??''), (int)$_SESSION['uid'], 'user');
    } catch(Exception $e) { /* silent */ }
}

// مسح الجلسة بشكل كامل وآمن
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $p = session_get_cookie_params();
    setcookie(
        session_name(), '',
        time() - 42000,
        $p["path"], $p["domain"],
        $p["secure"], $p["httponly"]
    );
}
session_destroy();

// ← التوجيه الصحيح: صفحة تسجيل الدخول
header('Location: login.php', true, 302);
exit;
