<?php
/**
 * u.php — تم تعطيل الروابط العامة للمستخدمين
 * أي محاولة للوصول تُوجَّه لصفحة تسجيل الدخول
 */
require_once '../includes/db.php';

// 🔒 حماية — يجب تسجيل الدخول
if (!isLoggedIn()) {
    header('Location: login.php', true, 302);
    exit;
}

// حتى المسجّلين يُوجَّهون لبروفايلهم الخاص فقط
header('Location: profile.php', true, 302);
exit;
