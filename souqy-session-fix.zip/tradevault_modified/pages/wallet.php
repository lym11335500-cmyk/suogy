<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();
$uid=uid();
$user=$pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

$msg='';$msgType='ok';
$tab=$_GET['tab']??'overview';

// ─── ACTIONS ──────────────────────────────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act=$_POST['act']??'';

    if($act==='submit_deposit'||$act==='submit_withdraw'){
        $type=$act==='submit_deposit'?'deposit':'withdraw';
        $methodId=(int)($_POST['method_id']??0);
        $amount=(float)($_POST['amount']??0);
        $userAcc=trim($_POST['user_account']??'');
        $txHash = trim($_POST['tx_hash']??'');
        $network = trim($_POST['network']??'');

        $method=$pdo->prepare("SELECT * FROM payment_methods WHERE id=? AND is_active=1 AND type IN(?,?)");
        $method->execute([$methodId,$type,'both']);
        $method=$method->fetch();

        if(!$method){ $msg='طريقة الدفع غير متاحة'; $msgType='err'; }
        elseif($amount<$method['min_amount']||$amount>$method['max_amount']){
            $msg='المبلغ يجب أن يكون بين '.money($method['min_amount']).' و'.money($method['max_amount']); $msgType='err';
        } elseif($type==='withdraw' && $amount>(float)$user['balance']){
            $msg='رصيدك غير كافٍ. رصيدك الحالي: '.money((float)$user['balance']); $msgType='err';
        } elseif($type==='deposit' && empty($txHash)){
            $msg='هاش العملية (Transaction Hash) مطلوب للإيداع'; $msgType='err';
        } elseif($type==='deposit' && empty($_FILES['proof']['name'])){
            $msg='صورة إيصال التحويل مطلوبة للإيداع'; $msgType='err';
        } else {
            $fee=round($amount*$method['fee_percent']/100 + $method['fee_fixed'],2);
            $net=$type==='deposit' ? $amount-$fee : $amount+$fee;

            // Upload proof
            $proofPath=null;
            if(!empty($_FILES['proof']['name'])&&$_FILES['proof']['error']===UPLOAD_ERR_OK){
                $proofPath=uploadFile($_FILES['proof'],'payments');
            }

            $depositDays=(int)getSetting($pdo,'deposit_days','1');
            $withdrawDays=(int)getSetting($pdo,'withdraw_days','2');
            $pdo->prepare("INSERT INTO payment_requests(user_id,method_id,type,amount,fee,net_amount,user_account,proof_image,tx_hash,network)VALUES(?,?,?,?,?,?,?,?,?,?)")
                ->execute([$uid,$methodId,$type,$amount,$fee,$net,$userAcc,$proofPath,$txHash,$network]);

            // Notify admins
            $admins=$pdo->query("SELECT id FROM users WHERE is_admin=1")->fetchAll();
            foreach($admins as $adm) addNotif($pdo,$adm['id'],'payment_request','💰 طلب '.($type==='deposit'?'إيداع':'سحب').' جديد: '.money($amount),'../admin/deposits.php');

            $days = $type==='deposit'?$depositDays:$withdrawDays;
            $msg='✅ تم تقديم طلبك بنجاح — سيتم المعالجة خلال '.($days==1?'يوم عمل واحد':$days.' أيام عمل');
            $tab='history';
        }
    }
}

// Data
$methods=$pdo->query("SELECT * FROM payment_methods WHERE is_active=1 ORDER BY sort_order")->fetchAll();
$myRequests=$pdo->prepare("SELECT r.*,m.name_ar mname,m.icon micon FROM payment_requests r JOIN payment_methods m ON r.method_id=m.id WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 30");
$myRequests->execute([$uid]);
$myRequests=$myRequests->fetchAll();
$txs=$pdo->prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 30");
$txs->execute([$uid]);
$txs=$txs->fetchAll();

pageHead('المحفظة');
pageTopbar($pdo,'index.php','المحفظة');
?>
<div class="page" style="padding:16px 16px 90px">

<!-- BALANCE HERO -->
<div style="background:linear-gradient(135deg,#0d1219,#171f2e);border:1px solid var(--gold3);border-radius:var(--r);padding:24px 20px;margin-bottom:16px;text-align:center;position:relative;overflow:hidden">
  <div style="position:absolute;inset:0;background:radial-gradient(circle at 50% 0%,#f0b42912,transparent 60%);pointer-events:none"></div>
  <div style="font-size:.72rem;color:var(--txt2);letter-spacing:2px;margin-bottom:6px;text-transform:uppercase">رصيدك المتاح</div>
  <div style="font-size:2.6rem;font-weight:900;color:var(--gold);font-family:'JetBrains Mono',monospace;line-height:1;margin-bottom:6px"><?=money((float)$user['balance'])?></div>
  <?php if((float)$user['held_balance']>0): ?>
  <div style="font-size:.8rem;color:var(--txt2);margin-bottom:16px">محجوز: <span style="color:#fbbf24"><?=money((float)$user['held_balance'])?></span></div>
  <?php else: ?>
  <div style="margin-bottom:16px"></div>
  <?php endif; ?>
  <div style="display:flex;gap:10px">
    <button onclick="showSection('depositSection')" class="btn btn-gold" style="flex:1"><i class="fas fa-plus-circle"></i> إيداع</button>
    <button onclick="showSection('withdrawSection')" class="btn btn-outline" style="flex:1"><i class="fas fa-minus-circle"></i> سحب</button>
  </div>
</div>

<?php if($msg): echo '<div class="alert alert-'.$msgType.'"><i class="fas fa-'.($msgType==='ok'?'check-circle':'times-circle').'"></i><span>'.e($msg).'</span></div>'; endif; ?>

<!-- TABS -->
<div style="display:flex;background:var(--bg2);border-radius:var(--r2);padding:4px;gap:4px;margin-bottom:14px">
  <?php foreach(['overview'=>['fa-chart-pie','نظرة عامة'],'history'=>['fa-receipt','السجل'],'requests'=>['fa-clock','طلباتي']] as $t=>[$ic,$lbl]): ?>
  <button onclick="setTab('<?=$t?>')" id="tab_<?=$t?>" class="bnav-item <?=$tab===$t?'active':''?>" style="flex:1;border-radius:var(--r3);font-size:.75rem;padding:9px;border:<?=$tab===$t?'1px solid var(--border2)':'1px solid transparent'?>;background:<?=$tab===$t?'var(--card)':'transparent'?>">
    <i class="fas <?=$ic?>" style="display:block;margin-bottom:2px"></i><?=$lbl?>
  </button>
  <?php endforeach; ?>
</div>

<!-- OVERVIEW TAB -->
<div id="tabContent_overview" style="display:<?=$tab==='overview'?'block':'none'?>">
  <?php
  $totalIn=(float)($pdo->query("SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type IN('release','deposit','refund')")->fetchColumn()??0);
  $totalOut=(float)($pdo->query("SELECT SUM(amount) FROM transactions WHERE user_id=$uid AND type IN('withdraw','hold')")->fetchColumn()??0);
  ?>
  <div class="grid-2" style="margin-bottom:14px">
    <div class="stat-box"><div class="stat-val" style="color:var(--green)"><?=money($totalIn)?></div><div class="stat-lbl">إجمالي الوارد</div></div>
    <div class="stat-box"><div class="stat-val" style="color:var(--txt2)"><?=money($totalOut)?></div><div class="stat-lbl">إجمالي الصادر</div></div>
    <div class="stat-box"><div class="stat-val"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE user_id=$uid AND type='deposit'")->fetchColumn()?></div><div class="stat-lbl">عمليات إيداع</div></div>
    <div class="stat-box"><div class="stat-val"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE user_id=$uid AND type='withdraw'")->fetchColumn()?></div><div class="stat-lbl">عمليات سحب</div></div>
  </div>
  <!-- طرق الدفع المتاحة -->
  <div style="font-size:.78rem;font-weight:700;color:var(--txt2);letter-spacing:1px;margin-bottom:10px;display:flex;align-items:center;gap:6px">
    <span style="width:3px;height:12px;background:var(--gold);border-radius:2px;display:block"></span>
    طرق الدفع المتاحة
  </div>
  <div style="display:flex;flex-direction:column;gap:8px">
    <?php foreach($methods as $m): ?>
    <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:12px 14px;display:flex;align-items:center;gap:12px">
      <div style="width:36px;height:36px;border-radius:var(--r3);background:var(--gold-glow);border:1px solid var(--gold3);display:flex;align-items:center;justify-content:center;color:var(--gold);flex-shrink:0">
        <i class="fas <?=e($m['icon'])?>"></i>
      </div>
      <div style="flex:1">
        <div style="font-weight:700;font-size:.88rem"><?=e($m['name_ar']?:$m['name'])?></div>
        <div style="font-size:.7rem;color:var(--txt2);margin-top:2px">
          رسوم: <?=$m['fee_percent']>0?$m['fee_percent'].'%':''?><?=$m['fee_percent']>0&&$m['fee_fixed']>0?' + ':''?><?=$m['fee_fixed']>0?money($m['fee_fixed']):''?><?=$m['fee_percent']==0&&$m['fee_fixed']==0?'مجاناً':''?>
          &nbsp;·&nbsp; <?=money($m['min_amount'])?> – <?=money($m['max_amount'])?>
        </div>
      </div>
      <div style="font-size:.65rem;color:var(--txt3)">
        <?=$m['type']==='both'?'⇅':($m['type']==='deposit'?'↓ إيداع':'↑ سحب')?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- DEPOSIT SECTION (hidden by default) -->
<div id="depositSection" style="display:none;margin-bottom:14px">
  <div class="card">
    <div class="card-hd"><i class="fas fa-plus-circle" style="color:var(--green)"></i> إيداع رصيد</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="submit_deposit">
      <div class="fg">
        <label>طريقة الإيداع</label>
        <select name="method_id" class="fsel" required onchange="updateMethodInfo(this,'deposit')">
          <option value="">اختر الطريقة</option>
          <?php foreach($methods as $m) if($m['type']==='deposit'||$m['type']==='both'): ?>
          <option value="<?=$m['id']?>" data-min="<?=$m['min_amount']?>" data-max="<?=$m['max_amount']?>" data-fee_p="<?=$m['fee_percent']?>" data-fee_f="<?=$m['fee_fixed']?>" data-info="<?=e($m['account_info'])?>" data-instructions="<?=e($m['instructions'])?>">
            <?=e($m['name_ar']?:$m['name'])?>
          </option>
          <?php endif; ?>
        </select>
      </div>
      <div id="depositMethodInfo" style="display:none;background:var(--bg3);border:1px solid var(--gold3);border-radius:var(--r2);padding:12px;margin-bottom:12px;font-size:.8rem;color:var(--txt2)"></div>
      <div class="fg">
        <label>المبلغ ($)</label>
        <div style="position:relative">
          <input type="number" name="amount" id="depositAmt" class="fi" min="1" step="0.01" placeholder="0.00" style="padding-right:44px" oninput="calcFee(this,'deposit')">
          <span style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--gold);font-weight:900;font-family:'JetBrains Mono',monospace">$</span>
        </div>
        <div id="depositFeeInfo" style="font-size:.72rem;color:var(--txt2);margin-top:4px"></div>
      </div>
      <!-- USDT Networks selector (shown for USDT methods) -->
      <div class="fg" id="networkField" style="display:none">
        <label>شبكة USDT <span style="color:var(--red)">*</span></label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <?php foreach([['ETH','Ethereum (ERC20)','#627eea'],['BNB','Binance (BEP20)','#f0b429'],['TRC20','Tron (TRC20)','#ef4444'],['POLYGON','Polygon (MATIC)','#8247e5']] as [$nv,$nl,$nc]): ?>
          <label style="display:flex;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--r3);padding:10px;cursor:pointer;transition:.2s" class="network-opt">
            <input type="radio" name="network" value="<?=e($nv)?>" style="accent-color:<?=e($nc)?>">
            <span style="font-size:.8rem;font-weight:700"><?=e($nl)?></span>
          </label>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- Transaction Hash - REQUIRED for deposit -->
      <div class="fg" id="txHashField">
        <label>هاش العملية (Transaction Hash) <span style="color:var(--red)">*</span></label>
        <input type="text" name="tx_hash" class="fi mono" required placeholder="0x... أو رقم الهاش الخاص بعمليتك" style="font-size:.75rem">
        <div class="form-hint"><i class="fas fa-info-circle"></i> انسخ الـ Hash من محفظتك بعد إرسال العملية</div>
      </div>
      <div class="fg">
        <label>إيصال الدفع (صورة) <span style="color:var(--red)">*</span></label>
        <div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r3);padding:8px 12px;margin-bottom:8px;font-size:.78rem;color:var(--txt2)">
          <i class="fas fa-clock" style="color:var(--gold)"></i> مدة معالجة الإيداع: <strong>يوم عمل واحد</strong>
        </div>
        <div onclick="document.getElementById('depProof').click()" style="border:2px dashed var(--border2);border-radius:var(--r2);padding:20px;text-align:center;cursor:pointer;background:var(--bg2)" id="depDropZone">
          <i class="fas fa-camera" style="font-size:1.5rem;color:var(--txt3);display:block;margin-bottom:6px"></i>
          <div style="font-size:.8rem;color:var(--txt2)">أرفق صورة الإيصال أو تأكيد الدفع</div>
          <div id="depProofPreview"></div>
        </div>
        <input type="file" name="proof" id="depProof" accept="image/*" style="display:none" onchange="previewProof(this,'depProofPreview','depDropZone')">
      </div>
      <button type="submit" class="btn btn-green btn-block"><i class="fas fa-paper-plane"></i> إرسال طلب الإيداع</button>
    </form>
  </div>
</div>

<!-- WITHDRAW SECTION -->
<div id="withdrawSection" style="display:none;margin-bottom:14px">
  <div class="card">
    <div class="card-hd"><i class="fas fa-minus-circle" style="color:var(--red)"></i> سحب رصيد</div>
    <div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--r3);padding:10px 12px;margin-bottom:12px;font-size:.8rem;color:var(--txt2)">
      رصيدك المتاح للسحب: <strong class="gold"><?=money((float)$user['balance'])?></strong>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="submit_withdraw">
      <div class="fg">
        <label>طريقة السحب</label>
        <select name="method_id" class="fsel" required onchange="updateMethodInfo(this,'withdraw')">
          <option value="">اختر الطريقة</option>
          <?php foreach($methods as $m) if($m['type']==='withdraw'||$m['type']==='both'): ?>
          <option value="<?=$m['id']?>" data-min="<?=$m['min_amount']?>" data-max="<?=$m['max_amount']?>" data-fee_p="<?=$m['fee_percent']?>" data-fee_f="<?=$m['fee_fixed']?>" data-info="<?=e($m['account_info'])?>" data-instructions="<?=e($m['instructions'])?>">
            <?=e($m['name_ar']?:$m['name'])?>
          </option>
          <?php endif; ?>
        </select>
      </div>
      <div id="withdrawMethodInfo" style="display:none;background:var(--bg3);border:1px solid var(--border2);border-radius:var(--r2);padding:12px;margin-bottom:12px;font-size:.8rem;color:var(--txt2)"></div>
      <div class="fg">
        <label>المبلغ ($)</label>
        <div style="position:relative">
          <input type="number" name="amount" id="withdrawAmt" class="fi" min="1" step="0.01" placeholder="0.00" max="<?=(float)$user['balance']?>" style="padding-right:44px" oninput="calcFee(this,'withdraw')">
          <span style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--gold);font-weight:900;font-family:'JetBrains Mono',monospace">$</span>
        </div>
        <div id="withdrawFeeInfo" style="font-size:.72rem;color:var(--txt2);margin-top:4px"></div>
      </div>
      <!-- USDT Networks for withdraw -->
      <div class="fg" id="wNetworkField" style="display:none">
        <label>شبكة الاستلام <span style="color:var(--red)">*</span></label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <?php foreach([['ETH','Ethereum (ERC20)','#627eea'],['BNB','Binance (BEP20)','#f0b429'],['TRC20','Tron (TRC20)','#ef4444'],['POLYGON','Polygon (MATIC)','#8247e5']] as [$nv,$nl,$nc]): ?>
          <label style="display:flex;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--r3);padding:10px;cursor:pointer" class="network-opt">
            <input type="radio" name="network" value="<?=e($nv)?>" style="accent-color:<?=e($nc)?>">
            <span style="font-size:.8rem;font-weight:700"><?=e($nl)?></span>
          </label>
          <?php endforeach; ?>
          <label style="display:flex;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--r3);padding:10px;cursor:pointer" class="network-opt">
            <input type="radio" name="network" value="BINANCE_ID" style="accent-color:#f0b429">
            <span style="font-size:.8rem;font-weight:700">Binance ID</span>
          </label>
        </div>
      </div>
      <div class="fg">
        <label>عنوان محفظتك / Binance ID <span style="color:var(--red)">*</span></label>
        <input type="text" name="user_account" class="fi" required placeholder="عنوان USDT أو Binance ID الخاص بك">
        <div class="form-hint"><i class="fas fa-clock" style="color:var(--gold)"></i> مدة معالجة السحب: يومان عمل</div>
      </div>
      <button type="submit" class="btn btn-outline btn-block" onclick="return confirm('تأكيد طلب السحب؟')"><i class="fas fa-paper-plane"></i> إرسال طلب السحب</button>
    </form>
  </div>
</div>

<!-- HISTORY TAB -->
<div id="tabContent_history" style="display:<?=$tab==='history'?'block':'none'?>">
  <?php if(empty($txs)): ?>
  <div class="empty"><i class="fas fa-receipt"></i><p>لا توجد معاملات بعد</p></div>
  <?php else: ?>
  <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);overflow:hidden">
    <?php
    $typeInfo=['deposit'=>['fa-plus-circle','var(--green)','إيداع'],'withdraw'=>['fa-minus-circle','var(--red)','سحب'],'hold'=>['fa-lock','#fbbf24','حجز'],'release'=>['fa-unlock','var(--green)','إطلاق'],'commission'=>['fa-percentage','var(--purple)','عمولة'],'refund'=>['fa-undo','var(--blue)','استرجاع']];
    foreach($txs as $i=>$t):
      [$ic,$col,$lbl]=$typeInfo[$t['type']]??['fa-circle','var(--txt3)',$t['type']];
      $plus=in_array($t['type'],['deposit','release','refund']);
    ?>
    <div style="padding:13px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px<?=$i===count($txs)-1?';border-bottom:none':''?>">
      <div style="width:36px;height:36px;border-radius:var(--r3);background:<?=$col?>18;border:1px solid <?=$col?>33;display:flex;align-items:center;justify-content:center;color:<?=$col?>;flex-shrink:0"><i class="fas <?=$ic?>"></i></div>
      <div style="flex:1;min-width:0">
        <div style="font-size:.83rem;font-weight:700"><?=$lbl?></div>
        <?php if($t['note']): ?><div style="font-size:.7rem;color:var(--txt2);margin-top:1px"><?=e($t['note'])?></div><?php endif; ?>
        <div style="font-size:.65rem;color:var(--txt3);margin-top:2px"><?=timeAgo($t['created_at'])?></div>
      </div>
      <div style="text-align:center;flex-shrink:0">
        <div style="font-family:'JetBrains Mono',monospace;font-weight:700;color:<?=$plus?'var(--green)':'var(--red)'?>;font-size:.9rem"><?=$plus?'+':'-'?><?=money(abs((float)$t['amount']))?></div>
        <div style="font-size:.62rem;color:var(--txt3)"><?=money((float)$t['balance_after'])?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- REQUESTS TAB -->
<div id="tabContent_requests" style="display:<?=$tab==='requests'?'block':'none'?>">
  <?php if(empty($myRequests)): ?>
  <div class="empty"><i class="fas fa-clock"></i><p>لا توجد طلبات بعد</p></div>
  <?php else: ?>
  <div style="display:flex;flex-direction:column;gap:8px">
    <?php foreach($myRequests as $r): ?>
    <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:13px 14px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div style="display:flex;align-items:center;gap:8px">
          <i class="fas <?=e($r['micon'])?>" style="color:var(--gold)"></i>
          <span style="font-weight:700;font-size:.88rem"><?=e($r['mname'])?></span>
          <span class="tag <?=$r['type']==='deposit'?'tag-active':'tag-held'?>"><?=$r['type']==='deposit'?'إيداع':'سحب'?></span>
        </div>
        <?php $bc=['pending'=>'badge-warn','approved'=>'badge-ok','rejected'=>'badge-err'];
        $bclass=isset($bc[$r['status']])?$bc[$r['status']]:'badge-gray'; ?>
        <span class="badge <?=$bclass?>"><?=statusLabel($r['status'])?></span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--txt2)">
        <span>المبلغ: <strong class="mono gold"><?=money((float)$r['amount'])?></strong></span>
        <span>الرسوم: <strong><?=money((float)$r['fee'])?></strong></span>
        <span>الصافي: <strong class="mono"><?=money((float)$r['net_amount'])?></strong></span>
      </div>
      <?php if($r['admin_note']): ?>
      <div style="margin-top:8px;background:var(--bg3);border-radius:var(--r3);padding:8px;font-size:.75rem;color:var(--txt2)"><i class="fas fa-comment"></i> <?=e($r['admin_note'])?></div>
      <?php endif; ?>
      <div style="font-size:.65rem;color:var(--txt3);margin-top:6px"><?=timeAgo($r['created_at'])?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

</div>

<script>
// Tab system
function setTab(t){
  ['overview','history','requests'].forEach(id=>{
    document.getElementById('tabContent_'+id).style.display=id===t?'block':'none';
    const btn=document.getElementById('tab_'+id);
    btn.classList.toggle('active',id===t);
    btn.style.background=id===t?'var(--card)':'transparent';
    btn.style.border=id===t?'1px solid var(--border2)':'1px solid transparent';
  });
  // Hide deposit/withdraw sections
  document.getElementById('depositSection').style.display='none';
  document.getElementById('withdrawSection').style.display='none';
}

function showSection(id){
  ['depositSection','withdrawSection'].forEach(s=>document.getElementById(s).style.display='none');
  ['tabContent_overview','tabContent_history','tabContent_requests'].forEach(t=>document.getElementById(t).style.display='none');
  document.getElementById(id).style.display='block';
}

function updateMethodInfo(sel,prefix){
  const opt=sel.options[sel.selectedIndex];
  const box=document.getElementById(prefix+'MethodInfo');
  if(!opt.value){ box.style.display='none'; return; }
  const info=opt.dataset.instructions||'';
  const acc=opt.dataset.info||'';
  box.innerHTML='<strong style="color:var(--gold);display:block;margin-bottom:4px"><i class="fas fa-info-circle"></i> التعليمات:</strong>'+
    (info?info+'<br>':'')+(acc?'<strong style="color:var(--txt)">الحساب: </strong><span class="mono" style="color:var(--gold)">'+acc+'</span>':'');
  box.style.display='block';
}

function calcFee(inp,prefix){
  // Show/hide USDT network fields
  document.querySelectorAll('select[name="method_id"]').forEach(sel=>{
    sel.addEventListener('change',function(){
      const name = this.options[this.selectedIndex]?.text?.toLowerCase()||'';
      const isUsdt = name.includes('usdt')||name.includes('trc')||name.includes('erc')||name.includes('crypto')||name.includes('binance')||name.includes('بينانس')||name.includes('يو اس دي');
      // For deposit form
      const nf=document.getElementById('networkField');
      const tf=document.getElementById('txHashField');
      // txHashField is always shown for deposits - hash is always required
      if(nf&&this.closest('#depositSection')){nf.style.display=isUsdt?'block':'none';}
      // For withdraw form
      const wnf=document.getElementById('wNetworkField');
      if(wnf&&this.closest('#withdrawSection')){wnf.style.display=isUsdt?'block':'none';}
    });
  });
  const sel=document.querySelector('[name="method_id"]');
  const opt=sel?sel.options[sel.selectedIndex]:null;
  if(!opt||!opt.value) return;
  const amt=parseFloat(inp.value)||0;
  const fp=parseFloat(opt.dataset.fee_p)||0;
  const ff=parseFloat(opt.dataset.fee_f)||0;
  const fee=Math.round((amt*fp/100+ff)*100)/100;
  const net=prefix==='deposit'?amt-fee:amt+fee;
  const box=document.getElementById(prefix+'FeeInfo');
  if(amt>0) box.textContent='الرسوم: $'+fee.toFixed(2)+' — الصافي المستلم: $'+net.toFixed(2);
  else box.textContent='';
}

function previewProof(inp,previewId,dropId){
  if(!inp.files[0]) return;
  const r=new FileReader();
  r.onload=e=>{
    document.getElementById(previewId).innerHTML='<img src="'+e.target.result+'" style="max-height:100px;border-radius:8px;margin-top:8px;border:1px solid var(--border)">';
    document.getElementById(dropId).style.borderColor='var(--gold)';
  };
  r.readAsDataURL(inp.files[0]);
}
</script>
<?php pageBottomNav('wallet.php'); pageFoot(); ?>
