<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$q = trim($_GET['q'] ?? '');
$catId = (int)($_GET['cat'] ?? 0);
$sort = $_GET['sort'] ?? 'new';
$page = max(1,(int)($_GET['p']??1));
$perPage = 16;
$offset = ($page-1)*$perPage;

$cats = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();

$where = "WHERE l.status='active' AND l.expires_at>NOW()";
$params = [];
if($q){ $where .= " AND l.title LIKE ?"; $params[] = "%$q%"; }
if($catId){ $where .= " AND l.category_id=?"; $params[] = $catId; }

$ob=['price_asc'=>'l.price ASC','price_desc'=>'l.price DESC','views'=>'l.views DESC'];
$orderBy=isset($ob[$sort])?$ob[$sort]:'l.created_at DESC';

$cnt = $pdo->prepare("SELECT COUNT(*) FROM listings l $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total/$perPage));

$stmt = $pdo->prepare("SELECT l.*,c.name_ar cat_name,c.icon cat_icon,u.username seller_name
    FROM listings l
    JOIN categories c ON l.category_id=c.id
    JOIN users u ON l.user_id=u.id
    $where ORDER BY $orderBy LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$results = $stmt->fetchAll();

pageHead($q ? "نتائج: $q" : 'البحث');
pageTopbar($pdo, 'js:back', 'بحث');
?>
<div class="page">
<div style="padding:14px 16px 0">
  <form method="GET" action="">
    <div class="search-box" style="margin-bottom:12px">
      <i class="fas fa-search"></i>
      <input type="text" name="q" placeholder="ابحث عن حساب، لعبة، شبكة اجتماعية..." value="<?=e($q)?>" autofocus>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:8px">
      <select name="sort" class="fsel" style="flex:1;padding:9px 12px;font-size:.8rem" onchange="this.form.submit()">
        <option value="new" <?=$sort==='new'?'selected':''?>>الأحدث</option>
        <option value="price_asc" <?=$sort==='price_asc'?'selected':''?>>السعر: الأقل</option>
        <option value="price_desc" <?=$sort==='price_desc'?'selected':''?>>السعر: الأعلى</option>
      </select>
      <button type="submit" class="btn btn-gold" style="padding:9px 18px"><i class="fas fa-search"></i></button>
    </div>
    <?php if($q):?><input type="hidden" name="q" value="<?=e($q)?>"><?php endif;?>
  </form>

  <!-- Categories filter -->
  <div class="cats-scroll" style="padding:4px 0 12px">
    <a href="search.php<?=$q?'?q='.urlencode($q):''?>" class="cat-chip <?=!$catId?'active':''?>"><i class="fas fa-border-all"></i> الكل</a>
    <?php foreach($cats as $c):?>
    <a href="?<?=http_build_query(array_merge($_GET,['cat'=>$c['id'],'p'=>1]))?>" class="cat-chip <?=$catId==$c['id']?'active':''?>">
      <i class="fas <?=e($c['icon'])?>"></i> <?=e($c['name_ar'])?>
    </a>
    <?php endforeach;?>
  </div>

  <?php if($q || $catId):?>
  <div style="font-size:.78rem;color:var(--t2);margin-bottom:12px">
    <?=number_format($total)?> نتيجة<?=$q?" لـ \"$q\"":''?>
  </div>
  <?php endif;?>

  <?php if(empty($results)):?>
  <div class="empty">
    <i class="fas fa-search"></i>
    <p>لا توجد نتائج<?=$q?" لـ \"$q\"":''?></p>
  </div>
  <?php else:?>
  <div class="listing-grid">
    <?php foreach($results as $l): echo listingCard($pdo,$l); endforeach;?>
  </div>

  <?php if($pages>1):?>
  <div class="pager">
    <?php for($i=1;$i<=min($pages,8);$i++):?>
    <a href="?<?=http_build_query(array_merge($_GET,['p'=>$i]))?>" class="<?=$i===$page?'active':''?>"><?=$i?></a>
    <?php endfor;?>
  </div>
  <?php endif;?>
  <?php endif;?>
</div>
</div>
<?php pageBottomNav('search'); pageFoot();?>
