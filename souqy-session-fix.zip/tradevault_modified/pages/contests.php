<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
require_once '../includes/referral_helpers.php';
requireLogin();

$uid  = uid();
$user = $pdo->query("SELECT * FROM users WHERE id=$uid")->fetch();

// رمز الإحالة
try { $refCode = ensureReferralCode($pdo, $uid); } catch(Exception $e){ $refCode = strtoupper(substr(md5($uid),0,8)); }

// المسابقة النشطة
try { $active = getActiveContest($pdo); } catch(Exception $e){ $active = null; }

// كل المسابقات
try {
$allContests = $pdo->query("
    SELECT c.*,
        (SELECT COUNT(*) FROM referrals WHERE contest_id=c.id) AS total_refs,
        (SELECT COUNT(*) FROM referrals WHERE contest_id=c.id AND referrer_id=$uid) AS my_refs
    FROM contests c ORDER BY c.start_date DESC
")->fetchAll();
} catch(Exception $e){ $allContests = []; }

// إحصائيات المستخدم
try {
$totalRefs   = getReferralCount($pdo, $uid);
$contestRefs = $active ? getReferralCount($pdo, $uid, $active['id']) : 0;
$myRank      = ($active && $contestRefs > 0) ? getUserContestRank($pdo, $uid, $active['id']) : null;
} catch(Exception $e){ $totalRefs=0; $contestRefs=0; $myRank=null; }

// رابط الإحالة
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
$refLink  = rtrim($protocol.'://'.$_SERVER['HTTP_HOST'].dirname(dirname($_SERVER['SCRIPT_NAME'])),'/').'/pages/register.php?ref='.$refCode;

// وقت انتهاء المسابقة
$endTs   = $active ? strtotime($active['end_date'].' 23:59:59') : 0;
$startTs = $active ? strtotime($active['start_date']) : 0;

pageHead('المسابقات', '<style>
:root{
  --gold:#e8a400;--gold2:#ffcc44;--gold3:rgba(232,164,0,.18);
  --bg:#060810;--card:rgba(255,255,255,.04);--border:rgba(255,255,255,.08);
  --txt:#f0f3ff;--txt2:#8b95b5;--r:14px;--r2:10px;--grn:#10d97a;--red:#ff4d6d;
}

/* ── countdown ── */
.cdown{
  background:linear-gradient(135deg,rgba(232,164,0,.1),rgba(232,164,0,.03));
  border:1px solid rgba(232,164,0,.28);border-radius:18px;
  padding:20px 16px 14px;margin-bottom:14px;text-align:center;
  position:relative;overflow:hidden;
}
.cdown::before{
  content:"";position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(ellipse 80% 50% at 50% 0%,rgba(232,164,0,.07),transparent);
}
.cdown-label{font-size:.68rem;letter-spacing:2.5px;color:var(--gold);font-weight:800;margin-bottom:12px}
.cdown-row{display:flex;justify-content:center;align-items:center;gap:6px}
.cdown-blk{
  background:rgba(0,0,0,.4);border:1px solid rgba(232,164,0,.18);
  border-radius:11px;padding:9px 10px;min-width:58px;text-align:center;
}
.cdown-num{
  font-size:1.8rem;font-weight:900;color:var(--gold2);display:block;
  font-family:"JetBrains Mono",monospace;line-height:1;
  text-shadow:0 0 18px rgba(232,164,0,.45);
}
.cdown-lbl{font-size:.57rem;color:var(--txt2);margin-top:3px;display:block}
.cdown-sep{font-size:1.4rem;font-weight:900;color:rgba(232,164,0,.3);margin-bottom:10px}
.cdown-bar{height:4px;background:rgba(255,255,255,.06);border-radius:4px;margin-top:12px;overflow:hidden}
.cdown-fill{height:100%;background:linear-gradient(90deg,var(--gold),var(--gold2));border-radius:4px;transition:width .6s}
.cdown-dates{font-size:.62rem;color:var(--txt2);margin-top:7px}

/* ── ref link ── */
.ref-box{
  background:rgba(232,164,0,.04);border:1px solid rgba(232,164,0,.2);
  border-radius:var(--r);padding:14px;margin-bottom:14px;
}
.ref-lbl{font-size:.68rem;color:var(--gold);font-weight:700;margin-bottom:8px}
.ref-row{display:flex;gap:8px}
.ref-val{
  flex:1;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.1);
  border-radius:8px;padding:9px 12px;font-size:.68rem;color:var(--gold2);
  font-family:"JetBrains Mono",monospace;word-break:break-all;cursor:pointer;
}
.cpbtn{
  background:var(--gold);color:#000;border:none;border-radius:8px;
  padding:9px 14px;font-weight:800;cursor:pointer;font-size:.75rem;
  flex-shrink:0;transition:.2s;white-space:nowrap;
}
.cpbtn.ok{background:var(--grn);color:#fff}
.share-row{display:flex;gap:7px;margin-top:9px}
.sbtn{flex:1;border:none;border-radius:7px;padding:8px;cursor:pointer;font-size:.68rem;font-weight:700;display:flex;align-items:center;justify-content:center;gap:5px;transition:opacity .2s}
.sbtn:hover{opacity:.85}
.s-wa{background:#25d366;color:#fff}
.s-tg{background:#2aabee;color:#fff}
.code-chip{
  display:inline-flex;align-items:center;gap:6px;margin-top:9px;
  background:rgba(0,0,0,.3);border:1px solid rgba(232,164,0,.15);
  border-radius:8px;padding:6px 12px;font-size:.7rem;color:var(--txt2);
}
.code-chip code{color:var(--gold2);font-family:"JetBrains Mono",monospace;font-weight:700}

/* ── stats ── */
.stats-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:14px}
.sbox{background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:11px 8px;text-align:center}
.sbox-v{font-size:1.25rem;font-weight:900;color:var(--gold)}
.sbox-l{font-size:.6rem;color:var(--txt2);margin-top:3px}

/* ── contest card ── */
.ccard{
  background:var(--card);border:1px solid var(--border);
  border-radius:var(--r);overflow:hidden;margin-bottom:12px;
}
.ccard-head{
  padding:12px 14px;display:flex;align-items:center;gap:10px;
  border-bottom:1px solid rgba(255,255,255,.05);
}
.ccard-title{flex:1;font-weight:800;font-size:.85rem}
.ccard-body{padding:12px 14px}
.ccard-dates{font-size:.68rem;color:var(--txt2);margin-bottom:10px}

/* ── leaderboard ── */
.lb-row{display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.lb-row:last-child{border-bottom:none}
.lb-row.me{background:rgba(232,164,0,.05);margin:0 -14px;padding:9px 14px;border-bottom:1px solid rgba(232,164,0,.1)}
.rk{width:24px;height:24px;border-radius:50%;font-size:.68rem;font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.rk1{background:linear-gradient(135deg,#e8a400,#ffd700);color:#000}
.rk2{background:linear-gradient(135deg,#aaa,#ddd);color:#000}
.rk3{background:linear-gradient(135deg,#cd7f32,#e8a47a);color:#000}
.rkn{background:rgba(255,255,255,.07);color:var(--txt2)}
.lb-av{width:28px;height:28px;border-radius:50%;background:var(--gold3);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;flex-shrink:0;overflow:hidden}
.lb-av img{width:100%;height:100%;object-fit:cover}
.lb-name{flex:1;font-size:.78rem;font-weight:600}
.lb-cnt{font-size:.78rem;color:var(--gold);font-weight:800;font-family:"JetBrains Mono",monospace}
.lb-cnt small{font-weight:400;color:var(--txt2);font-size:.6rem}

.empty{text-align:center;padding:24px 16px;color:var(--txt2);font-size:.78rem}
.empty i{font-size:1.8rem;display:block;margin-bottom:8px;opacity:.2}

.status-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:.63rem;font-weight:800}
.s-active{background:rgba(16,217,122,.1);color:var(--grn);border:1px solid rgba(16,217,122,.2)}
.s-ended{background:rgba(255,255,255,.05);color:var(--txt2);border:1px solid var(--border)}
.s-upcoming{background:rgba(74,143,245,.1);color:#4a8ff5;border:1px solid rgba(74,143,245,.2)}
</style>');
pageTopbar($pdo, 'profile.php', 'المسابقات');
?>

<div class="page" style="padding:16px 16px 90px">

<?php if($active): ?>
<!-- ══ COUNTDOWN ══ -->
<div class="cdown">
  <div class="cdown-label">⏳ الوقت المتبقي لنهاية المسابقة</div>
  <div class="cdown-row">
    <div class="cdown-blk"><span class="cdown-num" id="cd-d">00</span><span class="cdown-lbl">يوم</span></div>
    <div class="cdown-sep">:</div>
    <div class="cdown-blk"><span class="cdown-num" id="cd-h">00</span><span class="cdown-lbl">ساعة</span></div>
    <div class="cdown-sep">:</div>
    <div class="cdown-blk"><span class="cdown-num" id="cd-m">00</span><span class="cdown-lbl">دقيقة</span></div>
    <div class="cdown-sep">:</div>
    <div class="cdown-blk"><span class="cdown-num" id="cd-s">00</span><span class="cdown-lbl">ثانية</span></div>
  </div>
  <div class="cdown-bar"><div class="cdown-fill" id="cd-fill" style="width:0%"></div></div>
  <div class="cdown-dates">
    <?=date('Y/m/d',strtotime($active['start_date']))?> &larr; <?=date('Y/m/d',strtotime($active['end_date']))?>
  </div>
</div>
<script>
!function(){
  var e=<?=$endTs?>*1000,s=<?=$startTs?>*1000,t=e-s;
  function p(n){return String(n).padStart(2,'0')}
  function tick(){
    var now=Date.now(),d=Math.max(0,e-now);
    document.getElementById('cd-d').textContent=p(Math.floor(d/86400000));
    document.getElementById('cd-h').textContent=p(Math.floor(d%86400000/3600000));
    document.getElementById('cd-m').textContent=p(Math.floor(d%3600000/60000));
    document.getElementById('cd-s').textContent=p(Math.floor(d%60000/1000));
    document.getElementById('cd-fill').style.width=Math.min(100,(Date.now()-s)/t*100).toFixed(1)+'%';
  }
  tick();setInterval(tick,7000);
}();
</script>
<?php endif; ?>

<!-- ══ REFERRAL LINK ══ -->
<div class="ref-box">
  <div class="ref-lbl">🔗 رابط إحالتك — شاركه واجمع أكبر عدد من الإحالات للفوز</div>
  <div class="ref-row">
    <div class="ref-val" onclick="cpLink()"><?=e($refLink)?></div>
    <button class="cpbtn" id="cpBtn" onclick="cpLink()"><i class="fas fa-copy"></i> نسخ</button>
  </div>
  <div class="share-row">
    <a class="sbtn s-wa"
       href="https://wa.me/?text=<?=urlencode('🏆 انضم معي وشارك في مسابقة الإحالة! '.$refLink)?>"
       target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> واتساب</a>
    <a class="sbtn s-tg"
       href="https://t.me/share/url?url=<?=urlencode($refLink)?>&text=<?=urlencode('🏆 انضم وشارك في المسابقة!')?>"
       target="_blank" rel="noopener"><i class="fab fa-telegram"></i> تيليجرام</a>
  </div>
  <div class="code-chip">
    <i class="fas fa-tag" style="color:var(--gold);font-size:.65rem"></i>
    كودك: <code><?=e($refCode)?></code>
  </div>
</div>
<script>
function cpLink(){
  navigator.clipboard?.writeText(<?=json_encode($refLink)?>).then(function(){
    var b=document.getElementById('cpBtn');
    b.textContent='✓ تم!';b.classList.add('ok');
    setTimeout(function(){b.innerHTML='<i class="fas fa-copy"></i> نسخ';b.classList.remove('ok');},2000);
  });
}
</script>

<!-- ══ MY STATS ══ -->
<div class="stats-row">
  <div class="sbox">
    <div class="sbox-v"><?=$totalRefs?></div>
    <div class="sbox-l">إجمالي إحالاتي</div>
  </div>
  <div class="sbox" style="border-color:rgba(232,164,0,.22)">
    <div class="sbox-v"><?=$contestRefs?></div>
    <div class="sbox-l">إحالات هذه الفترة</div>
  </div>
  <div class="sbox" style="<?=$myRank&&$myRank<=5?'border-color:rgba(16,217,122,.22)':''?>">
    <div class="sbox-v" style="<?=$myRank&&$myRank<=5?'color:var(--grn)':''?>">
      <?=$myRank?'#'.$myRank:'—'?>
    </div>
    <div class="sbox-l">ترتيبك</div>
  </div>
</div>

<!-- ══ ALL CONTESTS ══ -->
<?php
$today = date('Y-m-d');
foreach($allContests as $c):
  $isActive   = $c['status'] === 'active';
  $isUpcoming = $c['status'] === 'active' && $c['start_date'] > $today;
  $isEnded    = $c['status'] === 'ended' || $c['status'] === 'cancelled';

  if($isUpcoming){ $badge='<span class="status-badge s-upcoming"><i class="fas fa-clock"></i> قادمة</span>'; }
  elseif($isActive){ $badge='<span class="status-badge s-active"><i class="fas fa-circle" style="font-size:.4rem"></i> نشطة</span>'; }
  else { $badge='<span class="status-badge s-ended">منتهية</span>'; }

  try { $leaders = getContestLeaderboard($pdo, (int)$c['id'], 5); } catch(Exception $e){ $leaders=[]; }
  $myResult = null;
  if($isEnded){
    try {
      $r=$pdo->prepare("SELECT * FROM contest_results WHERE contest_id=? AND user_id=?");
      $r->execute([$c['id'],$uid]);
      $myResult=$r->fetch();
    } catch(Exception $e){}
  }
?>
<div class="ccard">
  <div class="ccard-head">
    <div style="font-size:1.2rem"><?=$isActive&&!$isUpcoming?'🏆':($isUpcoming?'📅':'🏅')?></div>
    <div class="ccard-title"><?=e($c['title'])?></div>
    <?=$badge?>
  </div>
  <div class="ccard-body">
    <div class="ccard-dates">
      <i class="fas fa-calendar-alt" style="color:var(--gold);font-size:.65rem"></i>
      <?=date('Y/m/d',strtotime($c['start_date']))?> ← <?=date('Y/m/d',strtotime($c['end_date']))?>
      &nbsp;·&nbsp; <?=$c['total_refs']?> إحالة إجمالية
    </div>

    <?php if($myResult): ?>
    <!-- فائز في هذه المسابقة -->
    <div style="background:rgba(232,164,0,.08);border:1px solid rgba(232,164,0,.25);border-radius:10px;padding:10px 12px;margin-bottom:10px;display:flex;align-items:center;gap:10px">
      <div style="font-size:1.3rem"><?=['🥇','🥈','🥉','4️⃣','5️⃣'][$myResult['rank_pos']-1]??'🏅'?></div>
      <div>
        <div style="font-weight:800;font-size:.82rem;color:var(--gold)">المركز <?=$myResult['rank_pos']?> — <?=$myResult['referral_count']?> إحالة</div>
        <?php if($myResult['reward']): ?>
        <div style="font-size:.7rem;color:var(--grn)">🎁 مكافأة: <?=number_format($myResult['reward'],2)?></div>
        <?php else: ?>
        <div style="font-size:.7rem;color:var(--txt2)">في انتظار تحديد المكافأة من الأدمن</div>
        <?php endif; ?>
      </div>
    </div>
    <?php elseif($isActive && !$isUpcoming): ?>
    <!-- إحالاتي في المسابقة الحالية -->
    <div style="font-size:.72rem;color:var(--txt2);margin-bottom:10px">
      إحالاتك في هذه الفترة: <strong style="color:var(--gold)"><?=$c['my_refs']?></strong>
      <?php if($myRank): ?> · ترتيبك: <strong style="color:var(--grn)">#<?=$myRank?></strong><?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Leaderboard -->
    <?php if(!empty($leaders)): ?>
    <?php foreach($leaders as $i=>$l):
      $rkCls = ['rk1','rk2','rk3'][$i] ?? 'rkn';
      $isMe  = $l['id'] == $uid;
      $av    = strtoupper(mb_substr($l['username'],0,1,'UTF-8'));
    ?>
    <div class="lb-row <?=$isMe?'me':''?>">
      <div class="rk <?=$rkCls?>"><?=$i+1?></div>
      <div class="lb-av"><?php if($l['profile_pic']): ?><img src="<?=e(assetUrl($l['profile_pic']))?>" alt=""><?php else: ?><?=$av?><?php endif; ?></div>
      <div class="lb-name"><?=e($l['username'])?><?=$isMe?' <small style="color:var(--gold)">أنت</small>':''?></div>
      <div class="lb-cnt"><?=$l['cnt']?> <small>إحالة</small></div>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div class="empty"><i class="fas fa-users"></i> لا توجد إحالات بعد</div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>

<?php if(empty($allContests)): ?>
<div class="ccard">
  <div class="empty" style="padding:40px">
    <i class="fas fa-trophy"></i>
    لا توجد مسابقات حتى الآن<br>
    <span style="font-size:.7rem;margin-top:8px;display:block">ابدأ مشاركة رابطك الآن استعداداً للمسابقات القادمة!</span>
  </div>
</div>
<?php endif; ?>

<!-- ── How it works ── -->
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:14px;margin-bottom:80px">
  <div style="font-weight:800;font-size:.8rem;margin-bottom:10px"><i class="fas fa-info-circle" style="color:var(--gold)"></i> كيف يعمل النظام؟</div>
  <?php foreach([
    ['fa-share-alt','شارك رابطك مع أصدقائك'],
    ['fa-user-check','عند تسجيلهم عبر رابطك تُحتسب إحالة ناجحة'],
    ['fa-trophy','أفضل 5 محيلين في نهاية كل فترة يفوزون بمكافآت'],
    ['fa-bell','ستصلك إشعارات فور فوزك أو عند التعادل'],
  ] as [$ic,$t]): ?>
  <div style="display:flex;gap:8px;align-items:flex-start;margin-bottom:8px">
    <i class="fas <?=$ic?>" style="color:var(--gold);margin-top:2px;width:12px;flex-shrink:0;font-size:.72rem"></i>
    <span style="font-size:.75rem;color:var(--txt2)"><?=$t?></span>
  </div>
  <?php endforeach; ?>
</div>

</div>
<?php pageBottomNav(); pageFoot(); ?>
