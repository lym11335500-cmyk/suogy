<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$catId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sort  = $_GET['sort']??'new';
$cats  = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order,name")->fetchAll();
$cat   = $catId ? $pdo->query("SELECT * FROM categories WHERE id=$catId")->fetch() : null;

$ob=['price_asc'=>'l.price ASC','price_desc'=>'l.price DESC','views'=>'l.views DESC'];
$orderBy=isset($ob[$sort])?$ob[$sort]:'l.created_at DESC';

$where = "l.status='active' AND l.expires_at>NOW()";
if($catId) $where.=" AND l.category_id=$catId";

$listings=$pdo->query("SELECT l.*,c.name cat_name,c.icon cat_icon,u.username seller_name,u.profile_pic,u.seller_rating FROM listings l JOIN categories c ON l.category_id=c.id JOIN users u ON l.user_id=u.id WHERE $where ORDER BY $orderBy LIMIT 60")->fetchAll();

pageHead($cat?e($cat['name']):'تصفح الإعلانات');
pageTopbar($pdo,'index.php',$cat?e($cat['name']):'تصفح الإعلانات');
?>
<div class="page">

<!-- CATEGORIES -->
<div style="padding:12px 0 4px;overflow-x:auto">
  <div style="display:flex;gap:8px;padding:0 16px;min-width:max-content">
    <a href="category.php" class="<?=!$catId?'btn btn-gold btn-sm':'btn btn-ghost btn-sm'?>">الكل</a>
    <?php foreach($cats as $c): ?>
    <a href="?id=<?=$c['id']?>&sort=<?=$sort?>" class="<?=$catId===$c['id']?'btn btn-gold btn-sm':'btn btn-ghost btn-sm'?>">
      <i class="fas <?=e($c['icon'])?>"></i> <?=e($c['name'])?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- SORT + COUNT -->
<div style="padding:10px 16px;display:flex;align-items:center;justify-content:space-between">
  <span style="font-size:.75rem;color:var(--txt2)"><?=count($listings)?> نتيجة</span>
  <select onchange="location.href='?'.new URLSearchParams({<?=$catId?'id:'.$catId.',':''?>sort:this.value})" class="fsel" style="width:auto;padding:7px 10px;font-size:.75rem">
    <option value="new" <?=$sort==='new'?'selected':''?>>الأحدث</option>
    <option value="price_asc" <?=$sort==='price_asc'?'selected':''?>>السعر: الأقل</option>
    <option value="price_desc" <?=$sort==='price_desc'?'selected':''?>>السعر: الأعلى</option>
    <option value="views" <?=$sort==='views'?'selected':''?>>الأكثر مشاهدة</option>
  </select>
</div>

<!-- GRID -->
<?php if(empty($listings)): ?>
<div class="empty fade-up"><i class="fas fa-box-open"></i><p>لا توجد إعلانات في هذه الفئة</p></div>
<?php else: ?>
<div class="grid-2 fade-up" style="padding:0 16px 16px">
  <?php foreach($listings as $l): echo listingCard($pdo,$l); endforeach; ?>
</div>
<?php endif; ?>

</div>
<?php pageBottomNav(); pageFoot(); ?>
