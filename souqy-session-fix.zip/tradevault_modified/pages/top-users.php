<?php
require_once '../includes/db.php';
require_once '../includes/layout.php';
requireLogin();

$tab = $_GET['tab']??'sellers';
$sellers = $pdo->query("SELECT id,username,profile_pic,seller_rating,total_sales,kyc_status FROM users WHERE is_admin=0 AND is_banned=0 ORDER BY seller_rating DESC LIMIT 30")->fetchAll();
$buyers  = $pdo->query("SELECT id,username,profile_pic,buyer_rating,total_purchases,kyc_status FROM users WHERE is_admin=0 AND is_banned=0 ORDER BY buyer_rating DESC LIMIT 30")->fetchAll();

pageHead('أفضل المستخدمين');
pageTopbar($pdo,'index.php','المتصدرون');
?>
<div class="page" style="padding:16px 16px 90px">

<div style="display:flex;background:var(--bg2);border-radius:var(--r2);padding:4px;gap:4px;margin-bottom:16px">
  <a href="?tab=sellers" style="flex:1;text-align:center;padding:10px;border-radius:var(--r3);font-size:.82rem;font-weight:700;text-decoration:none;background:<?=$tab==='sellers'?'var(--card)':'transparent'?>;color:<?=$tab==='sellers'?'var(--gold)':'var(--txt3)'>; border:<?=$tab==='sellers'?'1px solid var(--border2)':'1px solid transparent'?>">
    <i class="fas fa-store"></i> أفضل البائعين
  </a>
  <a href="?tab=buyers" style="flex:1;text-align:center;padding:10px;border-radius:var(--r3);font-size:.82rem;font-weight:700;text-decoration:none;background:<?=$tab==='buyers'?'var(--card)':'transparent'?>;color:<?=$tab==='buyers'?'var(--gold)':'var(--txt3)'>; border:<?=$tab==='buyers'?'1px solid var(--border2)':'1px solid transparent'?>">
    <i class="fas fa-user"></i> أفضل المشترين
  </a>
</div>

<?php $list = $tab==='sellers'?$sellers:$buyers; $ratingKey=$tab==='sellers'?'seller_rating':'buyer_rating'; $countKey=$tab==='sellers'?'total_sales':'total_purchases'; ?>
<div style="display:flex;flex-direction:column;gap:8px">
<?php foreach($list as $i=>$u): ?>
<a href="profile.php?id=<?=$u['id']?>" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r2);padding:13px 14px;display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--txt);transition:border .2s" class="<?=$i<3?'border-'.$i:''?>">
  <div style="font-size:<?=$i<3?'1.3':'1'?>rem;width:32px;text-align:center;font-weight:900;color:<?=['var(--gold)','var(--txt2)','#cd7f32'][$i]??'var(--txt3)'>">
    <?=$i===0?'🥇':($i===1?'🥈':($i===2?'🥉':$i+1))?>
  </div>
  <div class="user-chip-av" style="width:44px;height:44px;border-radius:var(--r2);font-size:1.1rem;<?=$i<3?'border:2px solid var(--gold3)':''?>">
    <?php if($u['profile_pic']): ?><img src="<?=e(assetUrl($u['profile_pic']))?>" alt="">
    <?php else: ?><?=strtoupper(mb_substr($u['username'],0,1,'UTF-8'))?><?php endif; ?>
  </div>
  <div style="flex:1">
    <div style="font-weight:700;font-size:.9rem"><?=e($u['username'])?> <?=kycBadge($u['kyc_status'])?></div>
    <div style="font-size:.7rem;color:var(--txt2);margin-top:3px"><?=$u[$countKey]?> <?=$tab==='sellers'?'صفقة بيع':'عملية شراء'?></div>
    <div class="stars" style="margin-top:3px"><?=str_repeat('★',min((int)$u[$ratingKey],10))?></div>
  </div>
  <div class="mono gold" style="font-size:1rem;font-weight:900"><?=$u[$ratingKey]?></div>
</a>
<?php endforeach; ?>
</div>
</div>
<?php pageBottomNav(); pageFoot(); ?>
