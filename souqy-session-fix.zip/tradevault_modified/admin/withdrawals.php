<?php
require_once __DIR__ . '/../includes/admin_layout.php';
adminCheck();

$msg=''; $msgType='ok';
if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $rid=(int)($_POST['rid']??0); $act=$_POST['act']??'';
    if($rid && in_array($act,['approve','reject'])){
        $req=$pdo->prepare("SELECT * FROM payment_requests WHERE id=? AND type='withdraw' LIMIT 1");
        $req->execute([$rid]); $req=$req->fetch();
        if($req && $req['status']==='pending'){
            if($act==='approve'){
                $pdo->prepare("UPDATE payment_requests SET status='approved',processed_at=NOW() WHERE id=?")->execute([$rid]);
                $user=$pdo->query("SELECT balance FROM users WHERE id={$req['user_id']}")->fetch();
                $newBal = max(0, $user['balance'] - (float)$req['net_amount']);
                $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$newBal,$req['user_id']]);
                addTx($pdo,(int)$req['user_id'],'withdraw',(float)$req['net_amount'],$user['balance'],$newBal,$rid,'سحب مقبول');
                addNotif($pdo,(int)$req['user_id'],'withdraw_ok','✅ تمت الموافقة على طلب سحبك: '.money((float)$req['net_amount']),'wallet.php');
                $msg='تمت الموافقة على طلب السحب وخصم المبلغ من رصيد المستخدم.';
            } else {
                $note = e($_POST['note']??'');
                $pdo->prepare("UPDATE payment_requests SET status='rejected',admin_note=?,processed_at=NOW() WHERE id=?")->execute([$note,$rid]);
                addNotif($pdo,(int)$req['user_id'],'withdraw_rejected','❌ تم رفض طلب سحبك'.($note?': '.$note:''),'wallet.php');
                $msg='تم رفض الطلب وإشعار المستخدم.';
                $msgType='err';
            }
        }
    }
}

$filter=$_GET['f']??'pending';
$safeFilter = in_array($filter,['pending','approved','rejected'])?$filter:'pending';
$reqs=$pdo->query("SELECT r.*,u.username,u.email,m.name method_name FROM payment_requests r
    JOIN users u ON r.user_id=u.id
    LEFT JOIN payment_methods m ON r.method_id=m.id
    WHERE r.type='withdraw' AND r.status='$safeFilter'
    ORDER BY r.created_at DESC LIMIT 100")->fetchAll();
$pending=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='withdraw' AND status='pending'")->fetchColumn();
$approved=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='withdraw' AND status='approved'")->fetchColumn();

adminHead('طلبات السحب','withdrawals');
adminTopbar('طلبات السحب 💸', $pending>0?"$pending طلب ينتظر الموافقة":'لا توجد طلبات معلقة');
?>
<?php if($msg):?><div class="alert alert-<?=$msgType?>"><i class="fas fa-<?=$msgType==='ok'?'check-circle':'times-circle'?>"></i><span><?=e($msg)?></span></div><?php endif;?>

<!-- Stats Row -->
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card"><div class="stat-icon gold"><i class="fas fa-clock"></i></div><div><div class="stat-val"><?=$pending?></div><div class="stat-lbl">في الانتظار</div></div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="fas fa-check-double"></i></div><div><div class="stat-val"><?=$approved?></div><div class="stat-lbl">مقبول</div></div></div>
  <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-dollar-sign"></i></div><div><div class="stat-val"><?=money((float)($pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='withdraw' AND status='approved'")->fetchColumn()))?></div><div class="stat-lbl">إجمالي المسحوب</div></div></div>
  <div class="stat-card"><div class="stat-icon red"><i class="fas fa-times"></i></div><div><div class="stat-val"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='withdraw' AND status='rejected'")->fetchColumn()?></div><div class="stat-lbl">مرفوض</div></div></div>
</div>

<!-- Filter Tabs -->
<div class="ftabs" style="margin-bottom:20px">
  <a href="?f=pending" class="ftab <?=$safeFilter==='pending'?'active':''?>">انتظار <span class="cnt"><?=$pending?></span></a>
  <a href="?f=approved" class="ftab <?=$safeFilter==='approved'?'active':''?>">مقبول</a>
  <a href="?f=rejected" class="ftab <?=$safeFilter==='rejected'?'active':''?>">مرفوض</a>
</div>

<?php if(empty($reqs)):?>
<div class="sec-card">
  <div class="empty"><i class="fas fa-money-bill-wave"></i><p>لا توجد طلبات <?=$safeFilter==='pending'?'معلقة':($safeFilter==='approved'?'مقبولة':'مرفوضة')?></p></div>
</div>
<?php else: foreach($reqs as $r):?>
<div class="sec-card" style="border-color:<?=$r['status']==='pending'?'rgba(232,164,0,.15)':($r['status']==='approved'?'rgba(16,217,122,.15)':'rgba(255,71,87,.15)')?>">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap">
    <div style="flex:1;min-width:0">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <div style="font-size:1.3rem;font-weight:900;color:var(--gold);font-family:'JetBrains Mono',monospace"><?=money((float)$r['net_amount'])?></div>
        <?php if($r['fee']>0):?><div style="font-size:.72rem;color:var(--t3)">+ رسوم <?=money((float)$r['fee'])?></div><?php endif;?>
      </div>
      <div style="font-size:.85rem;font-weight:700;margin-bottom:4px">
        <?=e($r['username'])?> <span style="font-weight:400;color:var(--t2);font-size:.78rem"><?=e($r['email'])?></span>
      </div>
      <div style="margin-top:8px;display:flex;gap:12px;flex-wrap:wrap;font-size:.78rem;color:var(--t2)">
        <span><i class="fas fa-wallet" style="margin-left:4px"></i><?=e($r['method_name']??'—')?></span>
        <span class="mono" style="color:var(--t3);word-break:break-all"><?=e(mb_substr($r['user_account']??'',0,40,'UTF-8'))?></span>
      </div>
      <?php if($r['tx_hash']):?><div style="margin-top:6px;font-size:.72rem;font-family:'JetBrains Mono',monospace;color:var(--cyan)">TX: <?=e(mb_substr($r['tx_hash'],0,30,'UTF-8'))?>...</div><?php endif;?>
      <div style="margin-top:8px;font-size:.7rem;color:var(--t3)"><i class="fas fa-clock" style="margin-left:4px"></i><?=timeAgo($r['created_at'])?></div>
      <?php if($r['admin_note']):?><div style="margin-top:8px;padding:8px 12px;background:rgba(255,71,87,.08);border:1px solid rgba(255,71,87,.2);border-radius:8px;font-size:.78rem;color:var(--red)"><?=e($r['admin_note'])?></div><?php endif;?>
    </div>
    <?php if($safeFilter==='pending'):?>
    <div style="display:flex;gap:8px;flex-direction:column;flex-shrink:0;min-width:180px">
      <form method="POST">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="rid" value="<?=$r['id']?>">
        <button name="act" value="approve" class="btn btn-green btn-sm btn-block" onclick="return confirm('موافقة وخصم المبلغ من رصيد المستخدم؟')">
          <i class="fas fa-check"></i> موافقة
        </button>
      </form>
      <form method="POST">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="rid" value="<?=$r['id']?>">
        <input class="fi" type="text" name="note" placeholder="سبب الرفض (اختياري)" style="font-size:.78rem;padding:8px 12px;margin-bottom:8px;width:100%">
        <button name="act" value="reject" class="btn btn-red btn-sm btn-block">
          <i class="fas fa-times"></i> رفض
        </button>
      </form>
    </div>
    <?php else:?>
    <span class="badge <?=$r['status']==='approved'?'badge-green':'badge-red'?>">
      <?=$r['status']==='approved'?'✓ مقبول':'✕ مرفوض'?>
    </span>
    <?php endif;?>
  </div>
</div>
<?php endforeach; endif;?>
<?php adminFoot();?>
