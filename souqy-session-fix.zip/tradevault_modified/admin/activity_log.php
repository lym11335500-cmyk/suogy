<?php
/**
 * admin/activity_log.php — سجل النشاطات الكامل
 */
require_once 'admin_check.php';

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset  = ($page-1)*$perPage;
$filter  = $_GET['type'] ?? 'all';
$search  = trim($_GET['q'] ?? '');

// Build query
$where = "WHERE 1=1";
$params = [];
if ($filter !== 'all') {
    $where .= " AND al.action_type = ?";
    $params[] = $filter;
}
if ($search) {
    $where .= " AND (al.description LIKE ? OR al.actor_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Try activity_log table, fall back to synthesized log from existing tables
$hasLogTable = false;
try {
    $pdo->query("SELECT 1 FROM activity_log LIMIT 1");
    $hasLogTable = true;
} catch(Exception $e){}

if ($hasLogTable) {
    $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM activity_log al $where");
    $totalStmt->execute($params);
    $total = (int)$totalStmt->fetchColumn();
    $pages = max(1, ceil($total/$perPage));

    $stmt = $pdo->prepare("SELECT al.*,
        COALESCE(u.username, al.actor_name) actor_display
        FROM activity_log al
        LEFT JOIN users u ON al.actor_id=u.id
        $where ORDER BY al.created_at DESC LIMIT $perPage OFFSET $offset");
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
} else {
    // Synthesize activity from existing tables
    $synthetic = [];

    // Recent purchases
    try {
        $rows = $pdo->query("SELECT 'صفقة جديدة' desc_, 'deal' type_, b.username actor, p.created_at ts,
            p.amount deal_amount, p.status deal_status
            FROM purchases p
            JOIN users b ON p.buyer_id=b.id
            JOIN users s ON p.seller_id=s.id
            ORDER BY p.created_at DESC LIMIT 8")->fetchAll();
        foreach($rows as $r) $synthetic[] = ['action_type'=>'deal','description'=>'صفقة جديدة — '.$r['actor'].' بقيمة '.money((float)$r['deal_amount']).' — الحالة: '.$r['deal_status'],'actor_name'=>$r['actor'],'actor_role'=>'user','created_at'=>$r['ts']];
    } catch(Exception $e){}

    // Recent deposits
    try {
        $rows = $pdo->query("SELECT pr.*, u.username FROM payment_requests pr
            LEFT JOIN users u ON pr.user_id=u.id
            ORDER BY pr.created_at DESC LIMIT 8")->fetchAll();
        foreach($rows as $r) $synthetic[] = ['action_type'=>'finance','description'=>'طلب '.($r['type']==='deposit'?'إيداع':'سحب').' من '.$r['username'].' بمبلغ $'.$r['amount'],'actor_name'=>$r['username'],'actor_role'=>'user','created_at'=>$r['created_at']];
    } catch(Exception $e){}

    // Recent users
    try {
        $rows = $pdo->query("SELECT id,username,created_at FROM users WHERE is_admin=0 ORDER BY created_at DESC LIMIT 8")->fetchAll();
        foreach($rows as $r) $synthetic[] = ['action_type'=>'user','description'=>'تسجيل مستخدم جديد: '.$r['username'],'actor_name'=>$r['username'],'actor_role'=>'user','created_at'=>$r['created_at']];
    } catch(Exception $e){}

    // KYC
    try {
        $rows = $pdo->query("SELECT kd.*, u.username FROM kyc_documents kd
            JOIN users u ON kd.user_id=u.id ORDER BY kd.submitted_at DESC LIMIT 6")->fetchAll();
        foreach($rows as $r) $synthetic[] = ['action_type'=>'security','description'=>'طلب توثيق KYC من '.$r['username'].' — الحالة: '.$r['status'],'actor_name'=>$r['username'],'actor_role'=>'user','created_at'=>$r['submitted_at']];
    } catch(Exception $e){}

    // Sort by date
    usort($synthetic, function($a,$b){ return strtotime($b['created_at']) - strtotime($a['created_at']); });

    // Filter
    if ($filter !== 'all') $synthetic = array_filter($synthetic, function($x) use($filter){ return $x['action_type']===$filter; });
    if ($search) $synthetic = array_filter($synthetic, function($x) use($search){ return (strpos($x['description'],$search)!==false)||(strpos(isset($x['actor_name'])?$x['actor_name']:'',$search)!==false); });
    $synthetic = array_values($synthetic);

    $total = count($synthetic);
    $pages = max(1, ceil($total/$perPage));
    $logs  = array_slice($synthetic, $offset, $perPage);
}

// Type labels and icons
function actTypeIcon($t) {
    $map=[
        'deal'     =>['fa-handshake','rgba(74,143,245,.12)','var(--blue)','deal','صفقة'],
        'finance'  =>['fa-coins','rgba(16,217,122,.12)','var(--green)','finance','مالية'],
        'user'     =>['fa-user-plus','rgba(232,164,0,.12)','var(--gold)','user','مستخدم'],
        'security' =>['fa-shield-alt','rgba(255,71,87,.12)','var(--red)','security','أمان'],
        'system'   =>['fa-cog','rgba(168,85,247,.12)','var(--purple)','system','نظام'],
        'kyc'      =>['fa-id-card','rgba(245,200,66,.12)','#f5c842','security','KYC'],
        'settings' =>['fa-sliders-h','rgba(168,85,247,.12)','var(--purple)','system','إعدادات'],
        'broadcast'=>['fa-bullhorn','rgba(232,164,0,.12)','var(--gold)','admin','إذاعة'],
        'admin'    =>['fa-user-shield','rgba(232,164,0,.12)','var(--gold)','admin','مدير'],
    ];
    return isset($map[$t])?$map[$t]:['fa-circle','rgba(255,255,255,.08)','var(--t2)','system','أخرى'];
}

function actRoleBadge($r) {
    $rmap=[
        'admin'   =>'<span class="act-badge admin"><i class="fas fa-user-shield"></i> مدير</span>',
        'user'    =>'<span class="act-badge user"><i class="fas fa-user"></i> مستخدم</span>',
        'system'  =>'<span class="act-badge system"><i class="fas fa-cog"></i> نظام</span>',
        'finance' =>'<span class="act-badge finance"><i class="fas fa-coins"></i> مالية</span>',
        'security'=>'<span class="act-badge security"><i class="fas fa-shield-alt"></i> أمان</span>',
    ];
    return isset($rmap[$r])?$rmap[$r]:'<span class="act-badge system">'.$r.'</span>';
}

adminHead('سجل النشاطات','activity_log');
?>

<div class="adm-topbar">
  <div style="display:flex;align-items:center;gap:12px">
    <div class="adm-title">سجل النشاطات <small>كل إجراء مسجّل بوقته ومن نفّذه</small></div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="index.php" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-right"></i> الرئيسية</a>
  </div>
</div>

<!-- FILTER TABS -->
<div class="ftabs" style="margin-bottom:18px">
  <?php
  $types = ['all'=>'الكل','deal'=>'الصفقات','finance'=>'المالية','user'=>'المستخدمون','security'=>'الأمان','system'=>'النظام'];
  foreach($types as $k=>$v): ?>
  <a href="?type=<?=$k?>&q=<?=urlencode($search)?>" class="ftab<?=$filter===$k?' active':''?>">
    <?=$v?>
  </a>
  <?php endforeach; ?>

  <!-- Search -->
  <form method="GET" style="display:flex;gap:8px;margin-right:auto;align-items:center">
    <input type="hidden" name="type" value="<?=e($filter)?>">
    <div class="search-bar" style="min-width:200px">
      <i class="fas fa-search"></i>
      <input type="text" name="q" value="<?=e($search)?>" placeholder="بحث في السجل...">
    </div>
    <button type="submit" class="btn btn-ghost btn-sm"><i class="fas fa-search"></i></button>
    <?php if($search): ?>
    <a href="?type=<?=e($filter)?>" class="btn btn-ghost btn-sm"><i class="fas fa-times"></i></a>
    <?php endif; ?>
  </form>
</div>

<!-- STATS ROW -->
<div class="stats-grid" style="margin-bottom:18px">
  <div class="stat-card">
    <div class="stat-card-icon blue"><i class="fas fa-history"></i></div>
    <div><div class="stat-card-val"><?= number_format($total) ?></div><div class="stat-card-lbl">إجمالي السجلات</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon gold"><i class="fas fa-calendar-day"></i></div>
    <div><div class="stat-card-val"><?php
      try { echo number_format((int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE DATE(created_at)=CURDATE()")->fetchColumn()); } catch(Exception $e){ echo '—'; }
    ?></div><div class="stat-card-lbl">صفقات اليوم</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green"><i class="fas fa-user-plus"></i></div>
    <div><div class="stat-card-val"><?php
      try { echo number_format((int)$pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()")->fetchColumn()); } catch(Exception $e){ echo '0'; }
    ?></div><div class="stat-card-lbl">مسجلون اليوم</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon purple"><i class="fas fa-coins"></i></div>
    <div><div class="stat-card-val"><?php
      try { echo number_format((int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE DATE(created_at)=CURDATE()")->fetchColumn()); } catch(Exception $e){ echo '0'; }
    ?></div><div class="stat-card-lbl">معاملات مالية اليوم</div></div>
  </div>
</div>

<!-- LOG LIST -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-list-ul"></i> سجل الأحداث <span style="font-size:.75rem;font-weight:400;color:var(--t3);margin-right:8px">صفحة <?=$page?> من <?=$pages?></span></div>

  <?php if (empty($logs)): ?>
    <div class="empty"><i class="fas fa-inbox"></i><p>لا توجد سجلات مطابقة للفلتر الحالي</p></div>
  <?php else: foreach ($logs as $log):
    $ico  = actTypeIcon($log['action_type'] ?? 'system');
    $role = $log['actor_role'] ?? ($log['action_type']==='admin' ? 'admin' : 'system');
  ?>
    <div class="act-item">
      <div class="act-icon" style="background:<?=$ico[1]?>">
        <i class="fas <?=$ico[0]?>" style="color:<?=$ico[2]?>"></i>
      </div>
      <div class="act-body">
        <div class="act-msg"><?=e($log['description'] ?? ($log['desc_'] ?? '—'))?></div>
        <div class="act-meta">
          <?=actRoleBadge($role)?>
          <?php if (!empty($log['actor_name']) || !empty($log['actor_display'])): ?>
          <span style="display:flex;align-items:center;gap:4px">
            <i class="fas fa-user" style="font-size:.6rem"></i>
            <?=e($log['actor_display'] ?? $log['actor_name'] ?? '—')?>
          </span>
          <?php endif; ?>
          <span><i class="fas fa-clock" style="font-size:.6rem"></i> <?=timeAgo($log['created_at'])?></span>
          <span style="color:var(--t3);font-size:.62rem"><?=date('Y-m-d H:i',strtotime($log['created_at']))?></span>
          <span class="act-badge <?=$ico[3]?>" style="font-size:.55rem"><?=$ico[4]?></span>
        </div>
      </div>
    </div>
  <?php endforeach; endif; ?>

  <!-- PAGINATION -->
  <?php if ($pages>1): ?>
  <div class="pager" style="margin-top:10px">
    <?php for($p=1;$p<=$pages;$p++): ?>
    <a href="?type=<?=e($filter)?>&q=<?=urlencode($search)?>&page=<?=$p?>" class="<?=$p===$page?'active':''"><?=$p?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php adminFoot(); ?>
