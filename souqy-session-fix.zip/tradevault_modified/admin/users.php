<?php
require_once 'admin_check.php';

$msg = '';
$err = '';

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';
    $uid = (int)($_POST['uid'] ?? 0);

    if ($act === 'ban' && $uid) {
        $pdo->prepare("UPDATE users SET is_banned=1 WHERE id=? AND is_admin=0")->execute([$uid]);
        $msg = 'تم إيقاف المستخدم.';
    } elseif ($act === 'unban' && $uid) {
        $pdo->prepare("UPDATE users SET is_banned=0 WHERE id=?")->execute([$uid]);
        $msg = 'تم رفع الإيقاف.';
    } elseif ($act === 'adjust_balance' && $uid) {
        $amount = (float)($_POST['amount'] ?? 0);
        $note   = trim($_POST['note'] ?? 'تعديل يدوي من الأدمن');
        $user   = $pdo->query("SELECT balance FROM users WHERE id=$uid")->fetch();
        if ($user) {
            $newBal = max(0, $user['balance'] + $amount);
            $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$newBal, $uid]);
            addTx($pdo, $uid, $amount >= 0 ? 'admin_credit' : 'admin_debit',
                  abs($amount), $user['balance'], $newBal, 0, $note);
            addNotif($pdo, $uid, 'wallet', ($amount >= 0 ? '💰 تم إضافة ' : '💸 تم خصم ') . money(abs($amount)) . ' — ' . $note, 'wallet.php');
            $msg = 'تم تعديل الرصيد.';
        }
    } elseif ($act === 'delete' && $uid) {
        $pdo->prepare("DELETE FROM users WHERE id=? AND is_admin=0")->execute([$uid]);
        $msg = 'تم حذف المستخدم.';
    } elseif ($act === 'make_admin' && $uid) {
        $pdo->prepare("UPDATE users SET is_admin=1 WHERE id=?")->execute([$uid]);
        $msg = 'تم ترقية المستخدم لأدمن.';
    } elseif ($act === 'edit_user' && $uid) {
        $newUsername = trim($_POST['new_username'] ?? '');
        $newEmail    = trim($_POST['new_email'] ?? '');
        $newPhone    = trim($_POST['new_phone'] ?? '');
        $newBal      = (float)($_POST['new_balance'] ?? -1);
        $newKyc      = $_POST['new_kyc'] ?? '';
        $sets = []; $params2 = [];
        if ($newUsername) { $sets[] = 'username=?'; $params2[] = $newUsername; }
        if ($newEmail)    { $sets[] = 'email=?';    $params2[] = $newEmail; }
        if ($newPhone)    { $sets[] = 'phone=?';    $params2[] = $newPhone; }
        if ($_POST['new_balance'] !== '') { $sets[] = 'balance=?'; $params2[] = max(0, (float)$_POST['new_balance']); }
        if ($newKyc && in_array($newKyc, ['not_submitted','pending','approved','rejected'])) {
            $sets[] = 'kyc_status=?'; $params2[] = $newKyc;
        }
        if (!empty($sets)) {
            $params2[] = $uid;
            $pdo->prepare("UPDATE users SET ".implode(',',$sets)." WHERE id=? AND is_admin=0")->execute($params2);
            $msg = 'تم تعديل بيانات المستخدم بنجاح.';
        }
    } elseif ($act === 'reset_password' && $uid) {
        $newPw = trim($_POST['new_password'] ?? '');
        if (strlen($newPw) >= 6) {
            $pdo->prepare("UPDATE users SET password=? WHERE id=? AND is_admin=0")->execute([$newPw, $uid]);
            $msg = 'تم تغيير كلمة مرور المستخدم.';
        } else {
            $err = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.';
        }
    }
}

// Detail view
$detail = null;
if (isset($_GET['detail']) && (int)$_GET['detail']) {
    $detail = $pdo->query("SELECT u.*,
        (SELECT COUNT(*) FROM listings WHERE user_id=u.id) listings_count,
        (SELECT COUNT(*) FROM purchases WHERE buyer_id=u.id) purchases_count,
        (SELECT COUNT(*) FROM purchases WHERE seller_id=u.id) sales_count
        FROM users u WHERE u.id=" . (int)$_GET['detail'])->fetch();
}

// Search & Filters
$search  = trim($_GET['q'] ?? '');
$filter  = $_GET['f'] ?? 'all';
$page    = max(1, (int)($_GET['p'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where = "WHERE u.is_admin=0";
$params = [];
if ($search) {
    $where .= " AND (u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $like = "%$search%";
    $params = [$like, $like, $like];
}
if ($filter === 'banned')    $where .= " AND u.is_banned=1";
if ($filter === 'kyc')       $where .= " AND u.kyc_status='pending'";
if ($filter === 'approved')  $where .= " AND u.kyc_status='approved'";

$total = (int)$pdo->prepare("SELECT COUNT(*) FROM users u $where")->execute($params) ?
         $pdo->prepare("SELECT COUNT(*) FROM users u $where")->execute($params) || 1 : 0;
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM users u $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, ceil($total / $perPage));

$stmt = $pdo->prepare("SELECT u.*,
    (SELECT COUNT(*) FROM listings WHERE user_id=u.id) lc,
    (SELECT COUNT(*) FROM purchases WHERE buyer_id=u.id OR seller_id=u.id) pc
    FROM users u $where ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$users = $stmt->fetchAll();

adminHead('المستخدمون', 'users.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      المستخدمون
      <small>إجمالي: <?= number_format($total) ?> مستخدم</small>
    </div>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?= e($msg) ?></span></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-err"><i class="fas fa-times-circle"></i><span><?= e($err) ?></span></div><?php endif; ?>

<!-- FILTERS -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;align-items:center">
  <?php foreach (['all'=>'الكل','banned'=>'موقوف','kyc'=>'KYC معلق','approved'=>'موثق'] as $k=>$v): ?>
  <a href="?f=<?=$k?>&q=<?=urlencode($search)?>"
     class="btn btn-sm <?=$filter===$k?'btn-gold':'btn-ghost'?>" style="font-size:.75rem"><?=$v?></a>
  <?php endforeach; ?>
  <form method="GET" style="margin-right:auto;display:flex;gap:6px">
    <input type="hidden" name="f" value="<?=e($filter)?>">
    <div class="search-bar" style="min-width:220px">
      <i class="fas fa-search"></i>
      <input type="text" name="q" value="<?=e($search)?>" placeholder="بحث باسم أو إيميل أو هاتف...">
    </div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-search"></i></button>
  </form>
</div>

<!-- TABLE -->
<div class="data-table-wrap">
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>المستخدم</th>
          <th>الإيميل</th>
          <th>الرصيد</th>
          <th>KYC</th>
          <th>إعلانات</th>
          <th>طلبات</th>
          <th>تاريخ التسجيل</th>
          <th>الحالة</th>
          <th>إجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($users)): ?>
        <tr><td colspan="10" style="text-align:center;padding:30px;color:var(--txt3)">لا يوجد مستخدمون</td></tr>
        <?php else: foreach ($users as $u): ?>
        <tr>
          <td class="mono txt2" style="font-size:.72rem"><?= $u['id'] ?></td>
          <td>
            <div class="user-row">
              <div class="user-av">
                <?php if ($u['profile_pic']): ?><img src="../<?=e($u['profile_pic'])?>" alt=""><?php
                else: echo strtoupper(mb_substr($u['username'],0,1,'UTF-8')); endif; ?>
              </div>
              <div>
                <div style="font-weight:700;font-size:.83rem"><?=e($u['username'])?></div>
                <div style="font-size:.65rem;color:var(--txt3)"><?=e($u['phone_country_flag']??'') . ' ' . e($u['phone']??'')?></div>
              </div>
            </div>
          </td>
          <td class="txt2 truncate" style="font-size:.75rem"><?=e($u['email'])?></td>
          <td class="mono gold"><?=money((float)$u['balance'])?></td>
          <td><?=kycBadge($u['kyc_status'])?></td>
          <td class="mono" style="text-align:center"><?=$u['lc']?></td>
          <td class="mono" style="text-align:center"><?=$u['pc']?></td>
          <td class="txt2" style="font-size:.72rem"><?=timeAgo($u['created_at'])?></td>
          <td>
            <?php if ($u['is_admin']): ?>
              <span class="badge badge-gold">أدمن</span>
            <?php elseif ($u['is_banned']): ?>
              <span class="badge badge-err">موقوف</span>
            <?php else: ?>
              <span class="badge badge-ok">نشط</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="table-actions">
              <a href="?detail=<?=$u['id']?>" class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3)" title="تفاصيل">
                <i class="fas fa-eye"></i>
              </a>
              <form method="POST" style="display:inline">
                <input type="hidden" name="_csrf" value="<?=csrf()?>">
                <input type="hidden" name="uid" value="<?=$u['id']?>">
                <?php if ($u['is_banned']): ?>
                <button type="submit" name="act" value="unban" class="icon-btn btn-sm"
                  style="width:30px;height:30px;border-radius:var(--r3);color:var(--green);border-color:#22c55e22" title="رفع الإيقاف">
                  <i class="fas fa-user-check"></i>
                </button>
                <?php else: ?>
                <button type="submit" name="act" value="ban" class="icon-btn btn-sm"
                  style="width:30px;height:30px;border-radius:var(--r3);color:var(--red);border-color:#ef444422"
                  onclick="return confirm('إيقاف هذا المستخدم؟')" title="إيقاف">
                  <i class="fas fa-user-slash"></i>
                </button>
                <?php endif; ?>
              </form>
              <button onclick="openBalanceModal(<?=$u['id']?>, '<?=e(addslashes($u['username']))?>')"
                class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3);color:var(--cyan);border-color:#06b6d422" title="تعديل الرصيد">
                <i class="fas fa-coins"></i>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- PAGINATION -->
  <?php if ($pages > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= min($pages, 10); $i++): ?>
    <a href="?f=<?=e($filter)?>&q=<?=urlencode($search)?>&p=<?=$i?>"
       class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DETAIL MODAL -->
<?php if ($detail): ?>
<div class="modal-overlay open" id="detailModal">
  <div class="modal" style="max-width:520px">
    <div class="modal-title">
      <span><i class="fas fa-user" style="color:var(--gold);margin-left:8px"></i> <?=e($detail['username'])?></span>
      <a href="users.php<?=isset($_GET['f'])?'?f='.$_GET['f']:''?>" class="modal-close"><i class="fas fa-times"></i></a>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      <div class="stat-box"><div class="stat-val"><?=money((float)$detail['balance'])?></div><div class="stat-lbl">الرصيد</div></div>
      <div class="stat-box"><div class="stat-val" style="color:var(--txt2)"><?=money((float)$detail['held_balance'])?></div><div class="stat-lbl">المحجوز</div></div>
      <div class="stat-box"><div class="stat-val" style="font-size:1rem"><?=$detail['listings_count']?></div><div class="stat-lbl">الإعلانات</div></div>
      <div class="stat-box"><div class="stat-val" style="font-size:1rem"><?=$detail['sales_count']?></div><div class="stat-lbl">المبيعات</div></div>
    </div>

    <div style="background:var(--bg2);border-radius:var(--r2);padding:14px;margin-bottom:16px">
      <div style="display:flex;flex-direction:column;gap:8px;font-size:.82rem">
        <div style="display:flex;justify-content:space-between"><span class="txt2">الإيميل:</span><span><?=e($detail['email'])?></span></div>
        <div style="display:flex;justify-content:space-between"><span class="txt2">الهاتف:</span><span><?=e($detail['phone_country_flag']??'') . ' ' . e($detail['phone']??'—')?></span></div>
        <div style="display:flex;justify-content:space-between"><span class="txt2">KYC:</span><?=kycBadge($detail['kyc_status'])?></div>
        <div style="display:flex;justify-content:space-between"><span class="txt2">تاريخ التسجيل:</span><span><?=e(date('Y-m-d', strtotime($detail['created_at'])))?></span></div>
        <div style="display:flex;justify-content:space-between"><span class="txt2">الحالة:</span>
          <?php if ($detail['is_banned']): ?><span class="badge badge-err">موقوف</span>
          <?php else: ?><span class="badge badge-ok">نشط</span><?php endif; ?>
        </div>
      </div>
    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <form method="POST" style="display:contents">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="uid" value="<?=$detail['id']?>">
        <?php if ($detail['is_banned']): ?>
        <button type="submit" name="act" value="unban" class="btn btn-green btn-sm">
          <i class="fas fa-user-check"></i> رفع الإيقاف
        </button>
        <?php else: ?>
        <button type="submit" name="act" value="ban" class="btn btn-red btn-sm"
          onclick="return confirm('إيقاف هذا المستخدم؟')">
          <i class="fas fa-user-slash"></i> إيقاف
        </button>
        <?php endif; ?>
        <button type="submit" name="act" value="delete" class="btn btn-outline btn-sm"
          style="color:var(--red);border-color:var(--red)"
          onclick="return confirm('حذف المستخدم نهائياً؟ لا يمكن التراجع!')">
          <i class="fas fa-trash"></i> حذف
        </button>
      </form>
      <button onclick="openBalanceModal(<?=$detail['id']?>, '<?=e(addslashes($detail['username']))?>')"
        class="btn btn-outline btn-sm" style="color:var(--cyan);border-color:var(--cyan)">
        <i class="fas fa-coins"></i> تعديل الرصيد
      </button>
      <button onclick="openEditModal(<?=$detail['id']?>, '<?=e(addslashes($detail['username']))?>', '<?=e(addslashes($detail['email']))?>', '<?=e(addslashes($detail['phone']??''))?>', <?=(float)$detail['balance']?>, '<?=$detail['kyc_status']?>')"
        class="btn btn-outline btn-sm" style="color:var(--gold);border-color:var(--gold)">
        <i class="fas fa-edit"></i> تعديل البيانات
      </button>
      <button onclick="openPwModal(<?=$detail['id']?>, '<?=e(addslashes($detail['username']))?>');" 
        class="btn btn-outline btn-sm" style="color:#a855f7;border-color:#a855f7">
        <i class="fas fa-key"></i> كلمة المرور
      </button>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- BALANCE MODAL -->
<div class="modal-overlay" id="balanceModal">
  <div class="modal">
    <div class="modal-title">
      <span><i class="fas fa-coins" style="color:var(--gold);margin-left:8px"></i> تعديل رصيد: <span id="balanceUsername"></span></span>
      <button class="modal-close" onclick="closeBalanceModal()"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="adjust_balance">
      <input type="hidden" name="uid" id="balanceUid">
      <div class="fg">
        <label>المبلغ (موجب = إضافة، سالب = خصم)</label>
        <input type="number" name="amount" class="fi" step="0.01" placeholder="مثال: 50 أو -20" required>
      </div>
      <div class="fg">
        <label>ملاحظة</label>
        <input type="text" name="note" class="fi" placeholder="سبب التعديل..." value="تعديل يدوي من الأدمن">
      </div>
      <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-check"></i> تأكيد التعديل</button>
    </form>
  </div>
</div>

<script>
function openBalanceModal(uid, name) {
  document.getElementById('balanceUid').value = uid;
  document.getElementById('balanceUsername').textContent = name;
  document.getElementById('balanceModal').classList.add('open');
}
function closeBalanceModal() {
  document.getElementById('balanceModal').classList.remove('open');
}
document.getElementById('balanceModal').addEventListener('click', function(e) {
  if (e.target === this) closeBalanceModal();
});
</script>

<!-- EDIT USER MODAL -->
<div class="modal-overlay" id="editUserModal">
  <div class="modal" style="max-width:480px">
    <div class="modal-title">
      <span><i class="fas fa-edit" style="color:var(--gold);margin-left:8px"></i> تعديل بيانات: <span id="editUsername"></span></span>
      <button class="modal-close" onclick="document.getElementById('editUserModal').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="edit_user">
      <input type="hidden" name="uid" id="editUid">
      <div class="fg">
        <label>اسم المستخدم</label>
        <input type="text" name="new_username" id="editUsernameInput" class="fi" placeholder="اتركه فارغاً للإبقاء">
      </div>
      <div class="fg">
        <label>الإيميل</label>
        <input type="email" name="new_email" id="editEmailInput" class="fi" placeholder="اتركه فارغاً للإبقاء">
      </div>
      <div class="fg">
        <label>رقم الجوال</label>
        <input type="text" name="new_phone" id="editPhoneInput" class="fi" placeholder="اتركه فارغاً للإبقاء">
      </div>
      <div class="fg">
        <label>الرصيد الجديد (اتركه فارغاً للإبقاء)</label>
        <input type="number" name="new_balance" id="editBalanceInput" class="fi" step="0.01" min="0" placeholder="">
      </div>
      <div class="fg">
        <label>حالة KYC</label>
        <select name="new_kyc" id="editKycInput" class="fsel">
          <option value="">-- لا تغيير --</option>
          <option value="not_submitted">لم يُقدَّم</option>
          <option value="pending">قيد المراجعة</option>
          <option value="approved">موثق ✅</option>
          <option value="rejected">مرفوض ❌</option>
        </select>
      </div>
      <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-save"></i> حفظ التعديلات</button>
    </form>
  </div>
</div>

<!-- RESET PASSWORD MODAL -->
<div class="modal-overlay" id="pwModal">
  <div class="modal" style="max-width:400px">
    <div class="modal-title">
      <span><i class="fas fa-key" style="color:#a855f7;margin-left:8px"></i> تغيير كلمة مرور: <span id="pwUsername"></span></span>
      <button class="modal-close" onclick="document.getElementById('pwModal').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="reset_password">
      <input type="hidden" name="uid" id="pwUid">
      <div class="fg">
        <label>كلمة المرور الجديدة</label>
        <input type="text" name="new_password" class="fi" minlength="6" required placeholder="6 أحرف على الأقل">
      </div>
      <button type="submit" class="btn btn-block" style="background:#a855f7;color:#fff;border:none"><i class="fas fa-key"></i> تغيير كلمة المرور</button>
    </form>
  </div>
</div>

<script>
function openEditModal(uid, username, email, phone, balance, kyc) {
  document.getElementById('editUid').value = uid;
  document.getElementById('editUsername').textContent = username;
  document.getElementById('editUsernameInput').value = username;
  document.getElementById('editEmailInput').value = email;
  document.getElementById('editPhoneInput').value = phone;
  document.getElementById('editBalanceInput').value = balance;
  document.getElementById('editKycInput').value = '';
  document.getElementById('editUserModal').classList.add('open');
}
function openPwModal(uid, username) {
  document.getElementById('pwUid').value = uid;
  document.getElementById('pwUsername').textContent = username;
  document.getElementById('pwModal').classList.add('open');
}
['editUserModal','pwModal'].forEach(id => {
  document.getElementById(id).addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});
</script>

<?php adminFoot(); ?>
