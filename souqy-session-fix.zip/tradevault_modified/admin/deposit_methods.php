<?php
require_once 'admin_check.php';
$msg=''; $err='';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act=$_POST['act']??'';
    if($act==='add'){
        $name=trim($_POST['name']??''); $name_ar=trim($_POST['name_ar']??'');
        $icon=trim($_POST['icon']??'fa-coins');
        $fee_pct=max(0,(float)($_POST['fee_pct']??0));
        $fee_fix=max(0,(float)($_POST['fee_fix']??0));
        $min=max(0,(float)($_POST['min']??1));
        $max_a=max(1,(float)($_POST['max_a']??50000));
        $info=trim($_POST['account_info']??'');
        $instr=trim($_POST['instructions']??'');
        if(!$name&&!$name_ar){ $err='اسم الطريقة مطلوب.'; }
        else {
            $pdo->prepare("INSERT INTO payment_methods(name,name_ar,icon,type,fee_percent,fee_fixed,min_amount,max_amount,account_info,instructions,is_active,sort_order)VALUES(?,?,?,'deposit',?,?,?,?,?,?,1,100)")
                ->execute([$name,$name_ar,$icon,$fee_pct,$fee_fix,$min,$max_a,$info,$instr]);
            $msg='✅ تم إضافة طريقة الإيداع.';
        }
    } elseif($act==='edit'){
        $id=(int)($_POST['id']??0);
        $name=trim($_POST['name']??''); $name_ar=trim($_POST['name_ar']??'');
        $icon=trim($_POST['icon']??'fa-coins');
        $fee_pct=max(0,(float)($_POST['fee_pct']??0));
        $fee_fix=max(0,(float)($_POST['fee_fix']??0));
        $min=max(0,(float)($_POST['min']??1));
        $max_a=max(1,(float)($_POST['max_a']??50000));
        $info=trim($_POST['account_info']??'');
        $instr=trim($_POST['instructions']??'');
        if($id){
            $pdo->prepare("UPDATE payment_methods SET name=?,name_ar=?,icon=?,fee_percent=?,fee_fixed=?,min_amount=?,max_amount=?,account_info=?,instructions=? WHERE id=? AND type='deposit'")
                ->execute([$name,$name_ar,$icon,$fee_pct,$fee_fix,$min,$max_a,$info,$instr,$id]);
            $msg='✅ تم تحديث الطريقة.';
        }
    } elseif($act==='delete'){
        $id=(int)($_POST['id']??0);
        if($id){ $pdo->prepare("DELETE FROM payment_methods WHERE id=? AND type='deposit'")->execute([$id]); $msg='✅ تم الحذف.'; }
    } elseif($act==='toggle'){
        $id=(int)($_POST['id']??0);
        if($id){ $pdo->prepare("UPDATE payment_methods SET is_active=1-is_active WHERE id=? AND type='deposit'")->execute([$id]); $msg='✅ تم تغيير الحالة.'; }
    }
    header('Location: deposit_methods.php'); exit;
}

$methods=$pdo->query("SELECT * FROM payment_methods WHERE type='deposit' ORDER BY sort_order,id")->fetchAll();
adminHead('طرق الإيداع','deposit_methods');
?>
<div class="adm-topbar">
  <div class="adm-title">طرق الإيداع <small>إدارة طرق دفع الإيداع</small></div>
</div>
<?php if($msg): echo '<div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>'.e($msg).'</span></div>'; endif; ?>
<?php if($err): echo '<div class="alert alert-err"><i class="fas fa-times-circle"></i><span>'.e($err).'</span></div>'; endif; ?>

<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-plus-circle"></i> إضافة طريقة إيداع جديدة</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="add">
    <div class="col-grid">
      <div class="fg"><label>الاسم بالعربية <span style="color:var(--red)">*</span></label><input type="text" name="name_ar" class="fi" placeholder="USDT - تيثر" required></div>
      <div class="fg"><label>الاسم بالإنجليزية</label><input type="text" name="name" class="fi" placeholder="USDT ERC20"></div>
      <div class="fg"><label>أيقونة (Font Awesome)</label><input type="text" name="icon" class="fi" value="fa-coins" placeholder="fa-coins"></div>
      <div class="fg"><label>عنوان المحفظة / حساب الاستلام</label><input type="text" name="account_info" class="fi" placeholder="0x..."></div>
      <div class="fg"><label>رسوم % </label><input type="number" name="fee_pct" class="fi" step="0.01" min="0" value="1"></div>
      <div class="fg"><label>رسوم ثابتة $</label><input type="number" name="fee_fix" class="fi" step="0.01" min="0" value="0"></div>
      <div class="fg"><label>الحد الأدنى $</label><input type="number" name="min" class="fi" step="0.01" min="0" value="5"></div>
      <div class="fg"><label>الحد الأقصى $</label><input type="number" name="max_a" class="fi" step="0.01" min="1" value="50000"></div>
    </div>
    <div class="fg"><label>تعليمات الإيداع</label><textarea name="instructions" class="fta" placeholder="أرسل USDT على شبكة ERC20 وأرفق هاش العملية..."></textarea></div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إضافة</button>
  </form>
</div>

<div class="tbl-wrap">
  <div class="tbl-head"><div class="tbl-title"><i class="fas fa-arrow-circle-down"></i> طرق الإيداع (<?=count($methods)?>)</div></div>
  <div style="overflow-x:auto"><table>
    <thead><tr><th>الاسم</th><th>المحفظة</th><th>الرسوم</th><th>الحدود</th><th>الحالة</th><th>إجراءات</th></tr></thead>
    <tbody>
    <?php foreach($methods as $m): ?>
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:32px;height:32px;border-radius:8px;background:rgba(232,164,0,.1);display:flex;align-items:center;justify-content:center;color:var(--gold)"><i class="fas <?=e($m['icon'])?>"></i></div>
          <div>
            <div style="font-weight:700;font-size:.84rem"><?=e($m['name_ar']??$m['name'])?></div>
            <div style="font-size:.68rem;color:var(--t3)"><?=e($m['name'])?></div>
          </div>
        </div>
      </td>
      <td>
        <?php if($m['account_info']): ?>
        <div style="display:flex;align-items:center;gap:6px">
          <span class="mono" style="font-size:.65rem;color:var(--cyan);max-width:120px;overflow:hidden;text-overflow:ellipsis;display:block"><?=e(substr($m['account_info'],0,18))?>...</span>
          <button onclick="cpTxt('<?=e($m['account_info'])?>')" class="btn btn-xs" style="background:rgba(34,211,238,.1);color:var(--cyan);border:1px solid rgba(34,211,238,.2)" title="نسخ"><i class="fas fa-copy"></i></button>
        </div>
        <?php else: ?><span style="color:var(--t3)">—</span><?php endif; ?>
      </td>
      <td class="mono" style="font-size:.78rem"><?=$m['fee_percent']?>% + $<?=$m['fee_fixed']?></td>
      <td class="mono" style="font-size:.78rem">$<?=$m['min_amount']?> — $<?=$m['max_amount']?></td>
      <td><?=$m['is_active']?'<span class="badge badge-green">فعّال</span>':'<span class="badge badge-gray">معطّل</span>'?></td>
      <td>
        <div style="display:flex;gap:6px">
          <button onclick="toggleEdit('dm_<?=$m['id']?>')" class="btn btn-ghost btn-xs"><i class="fas fa-edit"></i></button>
          <form method="POST" style="display:inline">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="toggle"><input type="hidden" name="id" value="<?=$m['id']?>">
            <button type="submit" class="btn btn-ghost btn-xs"><i class="fas fa-power-off"></i></button>
          </form>
          <form method="POST" style="display:inline" onsubmit="return confirm('حذف هذه الطريقة؟')">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?=$m['id']?>">
            <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-trash"></i></button>
          </form>
        </div>
        <div id="dm_<?=$m['id']?>" style="display:none;margin-top:10px">
          <form method="POST">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="edit"><input type="hidden" name="id" value="<?=$m['id']?>">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
              <div class="fg" style="margin:0"><label style="font-size:.68rem">الاسم AR</label><input type="text" name="name_ar" class="fi" value="<?=e($m['name_ar']??$m['name'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">الاسم EN</label><input type="text" name="name" class="fi" value="<?=e($m['name'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">أيقونة</label><input type="text" name="icon" class="fi" value="<?=e($m['icon'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">المحفظة</label><input type="text" name="account_info" class="fi" value="<?=e($m['account_info'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">رسوم %</label><input type="number" name="fee_pct" class="fi" step="0.01" value="<?=e($m['fee_percent'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">رسوم ثابتة</label><input type="number" name="fee_fix" class="fi" step="0.01" value="<?=e($m['fee_fixed'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">الحد الأدنى</label><input type="number" name="min" class="fi" step="0.01" value="<?=e($m['min_amount'])?>"></div>
              <div class="fg" style="margin:0"><label style="font-size:.68rem">الحد الأقصى</label><input type="number" name="max_a" class="fi" step="0.01" value="<?=e($m['max_amount'])?>"></div>
            </div>
            <div class="fg" style="margin-bottom:8px"><label style="font-size:.68rem">التعليمات</label><textarea name="instructions" class="fta" style="min-height:60px"><?=e($m['instructions']??'')?></textarea></div>
            <button type="submit" class="btn btn-gold btn-xs"><i class="fas fa-save"></i> حفظ</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<script>
function toggleEdit(id){var el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}
function cpTxt(t){
  if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){showToast('تم نسخ العنوان ✓','ok')});}
  else{var ta=document.createElement('textarea');ta.value=t;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);showToast('تم النسخ ✓','ok');}
}
function showToast(msg,type){
  var t=document.createElement('div');
  t.style.cssText='position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:'+(type==='ok'?'#10d97a':'#ff4757')+';color:#fff;padding:10px 20px;border-radius:25px;font-size:.82rem;font-weight:700;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,.4);transition:opacity .4s';
  t.textContent=msg;document.body.appendChild(t);
  setTimeout(function(){t.style.opacity='0';setTimeout(function(){t.remove();},400);},2200);
}
</script>
<?php adminFoot(); ?>
