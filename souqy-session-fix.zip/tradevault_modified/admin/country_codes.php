<?php
require_once 'admin_check.php';
$msg=''; $err='';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act=$_POST['act']??'';
    if($act==='add'){
        $name=trim($_POST['country_name']??''); $name_ar=trim($_POST['country_name_ar']??'');
        $code=trim($_POST['phone_code']??'');
        if(!$code||!$name_ar){ $err='اسم الدولة ورمز الهاتف مطلوبان.'; }
        else {
            if(substr($code,0,1)!=='+') $code='+'.$code;
            $sort=(int)$pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM country_codes")->fetchColumn();
            try{
                $pdo->prepare("INSERT INTO country_codes(country_name,country_name_ar,phone_code,is_active,sort_order)VALUES(?,?,?,1,?)")
                    ->execute([$name,$name_ar,$code,$sort]);
                $msg='✅ تم إضافة رمز البلد.';
            }catch(Exception $e){ $err='الرمز موجود مسبقاً.'; }
        }
    } elseif($act==='edit'){
        $id=(int)($_POST['id']??0);
        $name=trim($_POST['country_name']??''); $name_ar=trim($_POST['country_name_ar']??'');
        $code=trim($_POST['phone_code']??'');
        if($id&&$name_ar&&$code){
            if(substr($code,0,1)!=='+') $code='+'.$code;
            $pdo->prepare("UPDATE country_codes SET country_name=?,country_name_ar=?,phone_code=? WHERE id=?")
                ->execute([$name,$name_ar,$code,$id]);
            $msg='✅ تم تحديث البلد.';
        }
    } elseif($act==='delete'){
        $id=(int)($_POST['id']??0);
        if($id){ $pdo->prepare("DELETE FROM country_codes WHERE id=?")->execute([$id]); $msg='✅ تم حذف البلد.'; }
    } elseif($act==='toggle'){
        $id=(int)($_POST['id']??0);
        if($id){ $pdo->prepare("UPDATE country_codes SET is_active=1-is_active WHERE id=?")->execute([$id]); $msg='✅ تم تغيير الحالة.'; }
    }
    header('Location: country_codes.php'); exit;
}

$rows=$pdo->query("SELECT * FROM country_codes ORDER BY sort_order,id")->fetchAll();
adminHead('مفاتيح البلدان','country_codes');
?>
<div class="adm-topbar">
  <div class="adm-title">مفاتيح أرقام البلدان <small>إدارة رموز الهاتف للتسجيل</small></div>
</div>
<?php if($msg): echo '<div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>'.e($msg).'</span></div>'; endif; ?>
<?php if($err): echo '<div class="alert alert-err"><i class="fas fa-times-circle"></i><span>'.e($err).'</span></div>'; endif; ?>

<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-plus-circle"></i> إضافة بلد جديد</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="add">
    <div class="col-grid">
      <div class="fg"><label>اسم البلد بالعربية <span style="color:var(--red)">*</span></label><input type="text" name="country_name_ar" class="fi" placeholder="مصر" required></div>
      <div class="fg"><label>اسم البلد بالإنجليزية</label><input type="text" name="country_name" class="fi" placeholder="Egypt"></div>
      <div class="fg"><label>رمز الهاتف <span style="color:var(--red)">*</span></label><input type="text" name="phone_code" class="fi" placeholder="+20" required></div>
    </div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إضافة</button>
  </form>
</div>

<div class="tbl-wrap">
  <div class="tbl-head"><div class="tbl-title"><i class="fas fa-globe"></i> البلدان (<?=count($rows)?>)</div></div>
  <div style="overflow-x:auto"><table>
    <thead><tr><th>#</th><th>العربية</th><th>الإنجليزية</th><th>الرمز</th><th>الحالة</th><th>إجراءات</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
    <tr>
      <td class="mono" style="font-size:.7rem;color:var(--t3)"><?=$r['id']?></td>
      <td style="font-weight:700"><?=e($r['country_name_ar'])?></td>
      <td style="color:var(--t2)"><?=e($r['country_name'])?></td>
      <td><span class="mono" style="color:var(--gold);background:var(--goldf);padding:3px 10px;border-radius:20px;font-size:.8rem"><?=e($r['phone_code'])?></span></td>
      <td><?=$r['is_active']?'<span class="badge badge-green">مفعّل</span>':'<span class="badge badge-gray">معطّل</span>'?></td>
      <td>
        <div style="display:flex;gap:6px">
          <button onclick="toggleEdit('cc_<?=$r['id']?>')" class="btn btn-ghost btn-xs"><i class="fas fa-edit"></i></button>
          <form method="POST" style="display:inline">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="toggle"><input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="btn btn-ghost btn-xs" title="تفعيل/تعطيل"><i class="fas fa-power-off"></i></button>
          </form>
          <form method="POST" style="display:inline" onsubmit="return confirm('حذف هذا البلد نهائياً؟')">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-trash"></i></button>
          </form>
        </div>
        <div id="cc_<?=$r['id']?>" style="display:none;margin-top:8px">
          <form method="POST">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="edit"><input type="hidden" name="id" value="<?=$r['id']?>">
            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end">
              <input type="text" name="country_name_ar" class="fi" value="<?=e($r['country_name_ar'])?>" style="width:110px" placeholder="العربية" required>
              <input type="text" name="country_name" class="fi" value="<?=e($r['country_name'])?>" style="width:110px" placeholder="الإنجليزية">
              <input type="text" name="phone_code" class="fi" value="<?=e($r['phone_code'])?>" style="width:80px" placeholder="+20" required>
              <button type="submit" class="btn btn-gold btn-xs"><i class="fas fa-save"></i> حفظ</button>
            </div>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<script>function toggleEdit(id){var el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php adminFoot(); ?>
