<?php
/**
 * admin/media_library.php — مكتبة الوسائط
 */
require_once 'admin_check.php';

$filter = $_GET['type'] ?? 'all';
$search = trim($_GET['q'] ?? '');
$page   = max(1,(int)($_GET['page'] ?? 1));
$perPage= 40;
$offset = ($page-1)*$perPage;

// Collect all media from all tables
$allMedia = [];

// Listing images
try {
    $rows = $pdo->query("SELECT li.image_path AS url, 'listing' AS source,
        l.title AS context, l.id AS ref_id, li.created_at
        FROM listing_images li
        LEFT JOIN listings l ON li.listing_id=l.id
        ORDER BY li.created_at DESC LIMIT 200")->fetchAll();
    foreach ($rows as $r) {
        $r['media_type'] = 'image';
        $r['category']   = 'إعلان';
        $allMedia[] = $r;
    }
} catch(Exception $e){}

// KYC documents
try {
    $rows = $pdo->query("SELECT kd.id_card_image AS url, 'kyc' AS source,
        u.username AS context, kd.user_id AS ref_id, kd.submitted_at AS created_at
        FROM kyc_documents kd
        JOIN users u ON kd.user_id=u.id
        WHERE kd.id_card_image IS NOT NULL ORDER BY kd.submitted_at DESC LIMIT 100")->fetchAll();
    foreach ($rows as $r) {
        $r['media_type'] = 'document';
        $r['category']   = 'KYC';
        $allMedia[] = $r;
    }

    $rows2 = $pdo->query("SELECT kd.selfie_image AS url, 'kyc_selfie' AS source,
        u.username AS context, kd.user_id AS ref_id, kd.submitted_at AS created_at
        FROM kyc_documents kd
        JOIN users u ON kd.user_id=u.id
        WHERE kd.selfie_image IS NOT NULL ORDER BY kd.submitted_at DESC LIMIT 100")->fetchAll();
    foreach ($rows2 as $r) {
        $r['media_type'] = 'selfie';
        $r['category']   = 'KYC';
        $allMedia[] = $r;
    }
} catch(Exception $e){}

// Payment receipts
try {
    $rows = $pdo->query("SELECT pr.proof_image AS url, 'receipt' AS source,
        u.username AS context, pr.id AS ref_id, pr.created_at
        FROM payment_requests pr
        JOIN users u ON pr.user_id=u.id
        WHERE pr.proof_image IS NOT NULL ORDER BY pr.created_at DESC LIMIT 100")->fetchAll();
    foreach ($rows as $r) {
        $r['media_type'] = 'receipt';
        $r['category']   = 'إيصال';
        $allMedia[] = $r;
    }
} catch(Exception $e){}

// Profile pictures
try {
    $rows = $pdo->query("SELECT u.profile_pic AS url, 'profile' AS source,
        u.username AS context, u.id AS ref_id, u.created_at
        FROM users u WHERE u.profile_pic IS NOT NULL ORDER BY u.created_at DESC LIMIT 100")->fetchAll();
    foreach ($rows as $r) {
        $r['media_type'] = 'profile';
        $r['category']   = 'صورة شخصية';
        $allMedia[] = $r;
    }
} catch(Exception $e){}

// Filter and search
if ($filter !== 'all') {
    $allMedia = array_filter($allMedia, function($m) use($filter){ return $m['source']===$filter || $m['media_type']===$filter || $m['category']===$filter; });
}
if ($search) {
    $allMedia = array_filter($allMedia, function($m) use($search){
        return (strpos(isset($m['context'])?$m['context']:'',$search)!==false)||(strpos(isset($m['url'])?$m['url']:'',$search)!==false)||(strpos(isset($m['category'])?$m['category']:'',$search)!==false);
    });
}

// Sort by date
usort($allMedia, function($a,$b){ return strtotime($b['created_at']) - strtotime($a['created_at']); });
$allMedia = array_values($allMedia);

$total  = count($allMedia);
$pages  = max(1, ceil($total/$perPage));
$media  = array_slice($allMedia, $offset, $perPage);

// Stats per category
$cats = array_count_values(array_column($allMedia, 'category'));

adminHead('مكتبة الوسائط','media_library');
?>

<div class="adm-topbar">
  <div style="display:flex;align-items:center;gap:12px">
    <div class="adm-title">مكتبة الوسائط <small>جميع الصور والوثائق المرفوعة</small></div>
  </div>
</div>

<!-- STATS -->
<div class="stats-grid" style="margin-bottom:18px">
  <div class="stat-card">
    <div class="stat-card-icon blue"><i class="fas fa-images"></i></div>
    <div><div class="stat-card-val"><?=number_format($total)?></div><div class="stat-card-lbl">إجمالي الوسائط</div></div>
  </div>
  <?php foreach ($cats as $cat=>$count): ?>
  <div class="stat-card">
    <div class="stat-card-icon gold"><i class="fas fa-folder"></i></div>
    <div><div class="stat-card-val"><?=number_format($count)?></div><div class="stat-card-lbl"><?=e($cat)?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- FILTER + SEARCH -->
<div style="display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap;align-items:center">
  <div class="ftabs" style="margin-bottom:0;flex:1;min-width:0">
    <a href="?type=all&q=<?=urlencode($search)?>" class="ftab<?=$filter==='all'?' active':''?>">الكل <span class="cnt"><?=number_format($total)?></span></a>
    <?php foreach($cats as $cat=>$count): ?>
    <a href="?type=<?=urlencode($cat)?>&q=<?=urlencode($search)?>" class="ftab<?=$filter===$cat?' active':''?>"><?=e($cat)?> <span class="cnt"><?=$count?></span></a>
    <?php endforeach; ?>
  </div>
  <form method="GET" style="display:flex;gap:8px;flex-shrink:0">
    <input type="hidden" name="type" value="<?=e($filter)?>">
    <div class="search-bar">
      <i class="fas fa-search"></i>
      <input type="text" name="q" value="<?=e($search)?>" placeholder="بحث بالاسم أو المصدر...">
    </div>
    <button type="submit" class="btn btn-ghost btn-sm"><i class="fas fa-search"></i></button>
  </form>
</div>

<!-- MEDIA GRID -->
<?php if (empty($media)): ?>
  <div class="empty" style="background:var(--card);border-radius:var(--r);padding:60px">
    <i class="fas fa-images"></i><p>لا توجد وسائط مطابقة</p>
  </div>
<?php else: ?>
<div class="media-grid" id="mediaGrid">
  <?php foreach ($media as $m):
    $url  = e($m['url'] ?? '');
    $name = e(basename($m['url'] ?? '—'));
    $ctx  = e($m['context'] ?? '—');
    $cat  = e($m['category'] ?? '');
    $time = timeAgo($m['created_at'] ?? '');
    $isImg = in_array(strtolower(pathinfo($url, PATHINFO_EXTENSION)),['jpg','jpeg','png','gif','webp']);
  ?>
  <div class="media-item" onclick="previewMedia('<?=$url?>','<?=$ctx?>','<?=$cat?>')">
    <?php if ($isImg && $url): ?>
      <img src="../<?=$url?>" alt="<?=$name?>" loading="lazy" onerror="this.parentNode.querySelector('.mi-placeholder') && (this.style.display='none');this.nextSibling&&(this.nextSibling.style.display='flex')">
    <?php else: ?>
      <div class="mi-placeholder">
        <i class="fas <?= $m['media_type']==='receipt' ? 'fa-receipt' : ($m['media_type']==='document'?'fa-file-image':($m['media_type']==='selfie'?'fa-portrait':'fa-file')) ?>"></i>
      </div>
    <?php endif; ?>
    <div class="mi-info">
      <div class="mi-type"><?=$cat?></div>
      <div class="mi-name" title="<?=$ctx?>"><?=$ctx?></div>
    </div>
    <div class="mi-overlay">
      <?php if ($isImg && $url): ?>
      <a href="../<?=$url?>" target="_blank" class="btn btn-ghost btn-xs" onclick="event.stopPropagation()" title="فتح">
        <i class="fas fa-external-link-alt"></i>
      </a>
      <?php endif; ?>
      <button class="btn btn-ghost btn-xs" onclick="event.stopPropagation();copyUrl('<?=$url?>')" title="نسخ الرابط">
        <i class="fas fa-copy"></i>
      </button>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- PAGINATION -->
<?php if ($pages>1): ?>
<div class="pager" style="margin-top:20px;border-top:1px solid var(--b1);padding-top:16px">
  <?php if($page>1): ?><a href="?type=<?=e($filter)?>&q=<?=urlencode($search)?>&page=<?=$page-1?>">‹</a><?php endif; ?>
  <?php for($p=max(1,$page-3);$p<=min($pages,$page+3);$p++): ?>
  <a href="?type=<?=e($filter)?>&q=<?=urlencode($search)?>&page=<?=$p?>" class="<?=$p===$page?'active':''"><?=$p?></a>
  <?php endfor; ?>
  <?php if($page<$pages): ?><a href="?type=<?=e($filter)?>&q=<?=urlencode($search)?>&page=<?=$page+1?>">›</a><?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- IMAGE PREVIEW MODAL -->
<div class="modal-overlay" id="previewModal">
  <div class="modal" style="max-width:640px;padding:0;overflow:hidden">
    <div style="padding:16px 18px;border-bottom:1px solid var(--b1);display:flex;align-items:center;justify-content:space-between">
      <div style="font-size:.9rem;font-weight:800" id="previewTitle">معاينة</div>
      <button class="modal-close" onclick="document.getElementById('previewModal').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <div style="padding:16px;text-align:center">
      <img id="previewImg" src="" style="max-width:100%;max-height:60vh;border-radius:var(--r2);display:block;margin:0 auto" alt="">
    </div>
    <div style="padding:12px 18px;border-top:1px solid var(--b1);display:flex;gap:8px">
      <a id="previewLink" href="#" target="_blank" class="btn btn-ghost btn-sm"><i class="fas fa-external-link-alt"></i> فتح بتبويب جديد</a>
      <button class="btn btn-ghost btn-sm" onclick="document.getElementById('previewModal').classList.remove('open')">إغلاق</button>
    </div>
  </div>
</div>

<script>
function previewMedia(url, ctx, cat){
  if(!url) return;
  document.getElementById('previewTitle').textContent = cat + ' — ' + ctx;
  document.getElementById('previewImg').src = '../' + url;
  document.getElementById('previewLink').href = '../' + url;
  document.getElementById('previewModal').classList.add('open');
}
function copyUrl(url){
  navigator.clipboard.writeText(window.location.origin+'/'+url)
    .then(function(){ alert('تم نسخ الرابط!'); })
    .catch(function(){ alert(url); });
}
</script>

<?php adminFoot(); ?>
