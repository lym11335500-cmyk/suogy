<?php
// ✅ نفس منطق مشروع التعدين:
//    require_once 'config.php';   ← عندنا: includes/db.php
//    requireAdmin();              ← نفس الاستدعاء
require_once __DIR__ . '/../includes/db.php';
requireAdmin();
require_once __DIR__ . '/../includes/admin_layout.php';
