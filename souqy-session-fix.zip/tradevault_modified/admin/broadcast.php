<?php
/**
 * admin/broadcast.php — إرسال رسائل جماعية لجميع المستخدمين
 */
require_once 'admin_check.php';

$msg=''; $err='';

if ($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    if ($act === 'send_broadcast') {
        $title   = trim($_POST['bc_title'] ?? '');
        $body    = trim($_POST['bc_body']  ?? '');
        $target  = $_POST['bc_target'] ?? 'all';  // all | kyc_approved | kyc_pending
        $link    = trim($_POST['bc_link']  ?? '');

        if (!$title || !$body) {
            $err = 'العنوان والمحتوى مطلوبان.';
        } else {
            // Build WHERE
            $where = 'WHERE is_admin=0 AND is_banned=0';
            if ($target === 'kyc_approved') $where .= " AND kyc_status='approved'";
            elseif ($target === 'kyc_pending') $where .= " AND kyc_status='pending'";

            $users = $pdo->query("SELECT id FROM users $where")->fetchAll();
            $count = 0;
            $fullMsg = "📢 $title\n$body";
            foreach ($users as $u) {
                addNotif($pdo, (int)$u['id'], 'broadcast', $fullMsg, $link ?: '#');
                $count++;
            }

            // Log broadcast in site_settings (simple log)
            $log = json_encode(['time'=>date('Y-m-d H:i:s'),'title'=>$title,'count'=>$count,'admin'=>uid()]);
            $pdo->prepare("INSERT INTO site_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=?")
                ->execute(['last_broadcast',$log,$log]);

            $msg = "✅ تم إرسال الرسالة إلى $count مستخدم بنجاح.";
        }
    }
}

// Broadcast stats
$totalUsers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0 AND is_banned=0")->fetchColumn();
$kycApproved = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0 AND is_banned=0 AND kyc_status='approved'")->fetchColumn();
$kycPending  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0 AND is_banned=0 AND kyc_status='pending'")->fetchColumn();
$lastBc = json_decode(getSetting($pdo,'last_broadcast','{}'), true);

adminHead('الإذاعة الجماعية','broadcast');
?>

<div class="adm-topbar">
  <div style="display:flex;align-items:center;gap:12px">
    <div class="adm-title">الإذاعة الجماعية <small>إرسال رسائل لجميع المستخدمين دفعة واحدة</small></div>
  </div>
</div>

<?php if($msg): echo '<div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>'.e($msg).'</span></div>'; endif; ?>
<?php if($err): echo '<div class="alert alert-err"><i class="fas fa-times-circle"></i><span>'.e($err).'</span></div>'; endif; ?>

<!-- STATS -->
<div class="col-grid" style="margin-bottom:20px">
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:2rem;font-weight:900;color:var(--gold)"><?=$totalUsers?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">إجمالي المستخدمين النشطين</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:2rem;font-weight:900;color:var(--green)"><?=$kycApproved?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">مستخدمون موثقون (KYC)</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:2rem;font-weight:900;color:var(--blue)"><?=$kycPending?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">KYC قيد المراجعة</div>
  </div>
</div>

<!-- COMPOSE FORM -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-bullhorn"></i> إنشاء رسالة جماعية</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="send_broadcast">

    <div class="fg">
      <label>المستهدفون <span style="color:var(--red)">*</span></label>
      <select name="bc_target" class="fsel" id="bcTarget" onchange="updateCount()">
        <option value="all">🌍 جميع المستخدمين (<?=$totalUsers?>)</option>
        <option value="kyc_approved">✅ الموثقون فقط (<?=$kycApproved?>)</option>
        <option value="kyc_pending">⏳ قيد المراجعة (<?=$kycPending?>)</option>
      </select>
      <div class="form-hint" id="targetHint">سيتم الإرسال لـ <strong id="targetCount"><?=$totalUsers?></strong> مستخدم</div>
    </div>

    <div class="fg">
      <label>عنوان الرسالة <span style="color:var(--red)">*</span></label>
      <input type="text" name="bc_title" id="bcTitle" class="fi" placeholder="مثال: تحديث جديد على المنصة" required maxlength="100" oninput="updatePreview()">
    </div>

    <div class="fg">
      <label>محتوى الرسالة <span style="color:var(--red)">*</span></label>
      <textarea name="bc_body" id="bcBody" class="fta" rows="4" required maxlength="500" placeholder="اكتب الرسالة هنا... يمكنك الإعلان عن تحديثات، عروض، أو تنبيهات مهمة." oninput="updatePreview()"></textarea>
    </div>

    <div class="fg">
      <label>رابط (اختياري)</label>
      <input type="text" name="bc_link" class="fi" placeholder="مثال: wallet.php أو https://...">
      <div class="form-hint">رابط تُحوّل المستخدم إليه عند الضغط على الإشعار</div>
    </div>

    <!-- Preview -->
    <div style="background:var(--bg2);border:1px solid var(--b2);border-radius:var(--r2);padding:14px;margin-bottom:16px">
      <div style="font-size:.72rem;color:var(--t3);margin-bottom:8px;font-weight:700">معاينة الإشعار:</div>
      <div style="display:flex;align-items:flex-start;gap:10px">
        <div style="width:36px;height:36px;border-radius:50%;background:rgba(232,164,0,.15);display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas fa-bullhorn" style="color:var(--gold);font-size:.85rem"></i>
        </div>
        <div>
          <div style="font-weight:800;font-size:.85rem;margin-bottom:3px" id="prevTitle">📢 العنوان هنا</div>
          <div style="font-size:.78rem;color:var(--t2);line-height:1.5" id="prevBody">محتوى الرسالة سيظهر هنا...</div>
        </div>
      </div>
    </div>

    <button type="submit" class="btn btn-gold" onclick="return confirm('إرسال الرسالة الجماعية؟ لا يمكن التراجع!')">
      <i class="fas fa-paper-plane"></i> إرسال الآن
    </button>
  </form>
</div>

<!-- LAST BROADCAST -->
<?php if (!empty($lastBc)): ?>
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-history"></i> آخر إذاعة</div>
  <div style="display:flex;flex-direction:column;gap:10px;font-size:.84rem">
    <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">العنوان</span><strong><?=e($lastBc['title']??'—')?></strong></div>
    <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">المُرسَل إليهم</span><span class="mono" style="color:var(--green)"><?=e($lastBc['count']??0)?> مستخدم</span></div>
    <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">وقت الإرسال</span><span style="color:var(--t3)"><?=e($lastBc['time']??'—')?></span></div>
  </div>
</div>
<?php endif; ?>

<script>
var counts = {all: <?=$totalUsers?>, kyc_approved: <?=$kycApproved?>, kyc_pending: <?=$kycPending?>};
function updateCount(){
  var t = document.getElementById('bcTarget').value;
  document.getElementById('targetCount').textContent = counts[t] || 0;
}
function updatePreview(){
  var t = document.getElementById('bcTitle').value;
  var b = document.getElementById('bcBody').value;
  document.getElementById('prevTitle').textContent = '📢 ' + (t || 'العنوان هنا');
  document.getElementById('prevBody').textContent  = b || 'محتوى الرسالة سيظهر هنا...';
}
</script>
<?php adminFoot(); ?>
