<?php
require_once '../includes/db.php';

if(isLoggedIn() && isAdmin()){ header('Location: index.php'); exit; }

$err = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $login = trim($_POST['login'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if($login && $pass){
        $stmt = $pdo->prepare("SELECT id,username,password,is_admin,is_banned FROM users WHERE (username=? OR email=?) LIMIT 1");
        $stmt->execute([$login, $login]);
        $user = $stmt->fetch();
        if($user && verifyPassword($pass, $user['password'])){
            if((int)$user['is_banned']){ $err = 'الحساب موقوف.'; }
            elseif(!(int)$user['is_admin']){ $err = 'هذا الحساب لا يملك صلاحيات الأدمن.'; }
            else {
                session_regenerate_id(false);
                $_SESSION['uid']       = (int)$user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['is_admin']  = 1;
                $_SESSION['_db_check'] = time();
                session_write_close();
                header('Location: index.php', true, 302); exit;
            }
        } else { $err = 'اسم المستخدم أو كلمة المرور غير صحيحة.'; }
    } else { $err = 'يرجى ملء جميع الحقول.'; }
}
$siteName = getSetting($pdo, 'site_name', 'سوقي');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#060810">
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link rel="shortcut icon" href="../assets/img/favicon.svg">
<title>دخول الأدمن — <?=e($siteName)?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="../assets/css/admin.css">
<style>
body{display:flex;align-items:center;justify-content:center;min-height:100vh;background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(232,164,0,0.08) 0%,transparent 70%),var(--bg)}
.login-box{width:100%;max-width:400px;margin:auto;background:var(--card2);border:1.5px solid var(--b2);border-radius:var(--r);padding:40px 32px;box-shadow:0 24px 60px rgba(0,0,0,.5),0 0 0 1px rgba(232,164,0,.05)}
.login-logo{text-align:center;margin-bottom:32px}
.icon-wrap{width:72px;height:72px;border-radius:20px;background:linear-gradient(135deg,rgba(232,164,0,0.15),rgba(232,164,0,0.05));border:1.5px solid rgba(232,164,0,0.3);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:2rem;color:var(--gold);box-shadow:0 0 30px rgba(232,164,0,0.15)}
.login-name{font-size:1.6rem;font-weight:900;color:var(--gold);display:block}
.login-sub{font-size:.68rem;color:var(--t3);letter-spacing:3px;text-transform:uppercase;margin-top:4px;display:block}
</style>
</head>
<body>
<div class="login-box">
  <div class="login-logo">
    <div class="icon-wrap"><i class="fas fa-shield-alt"></i></div>
    <span class="login-name">⚡ <?=e($siteName)?></span>
    <span class="login-sub">ADMIN PANEL</span>
  </div>

  <?php if($err):?>
  <div class="alert alert-err" style="margin-bottom:20px"><i class="fas fa-times-circle"></i><span><?=e($err)?></span></div>
  <?php endif;?>

  <form method="POST">
    <div class="fg">
      <label>اسم المستخدم أو البريد</label>
      <div style="position:relative">
        <i class="fas fa-user" style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--t3);font-size:.82rem;pointer-events:none"></i>
        <input type="text" name="login" class="fi" style="padding-right:38px" placeholder="admin" value="<?=e($_POST['login']??'')?>" required autofocus>
      </div>
    </div>
    <div class="fg">
      <label>كلمة المرور</label>
      <div style="position:relative">
        <i class="fas fa-lock" style="position:absolute;right:14px;top:50%;transform:translateY(-50%);color:var(--t3);font-size:.82rem;pointer-events:none"></i>
        <input type="password" name="password" class="fi" style="padding-right:38px" placeholder="••••••••" required>
      </div>
    </div>
    <button type="submit" class="btn btn-gold btn-block" style="margin-top:12px">
      <i class="fas fa-sign-in-alt"></i> دخول لوحة الإدارة
    </button>
  </form>

  <div style="text-align:center;margin-top:20px">
    <a href="../pages/index.php" style="font-size:.76rem;color:var(--t3);text-decoration:none;transition:.2s" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='var(--t3)'">
      <i class="fas fa-arrow-left"></i> العودة للموقع
    </a>
  </div>
</div>
</body>
</html>
