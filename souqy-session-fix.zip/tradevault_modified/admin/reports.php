<?php
require_once 'admin_check.php';

$totalRevenue=(float)$pdo->query("SELECT COALESCE(SUM(commission),0) FROM purchases WHERE status='completed'")->fetchColumn();
$totalOrders=(int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='completed'")->fetchColumn();
$totalUsers=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0")->fetchColumn();
$avgOrder=(float)$pdo->query("SELECT COALESCE(AVG(amount),0) FROM purchases WHERE status='completed'")->fetchColumn();
$totalVolume=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM purchases WHERE status='completed'")->fetchColumn();
$activeListings=(int)$pdo->query("SELECT COUNT(*) FROM listings WHERE status='active'")->fetchColumn();
$newUsersWeek=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) AND is_admin=0")->fetchColumn();
$depositsTotal=(float)$pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='deposit' AND status='approved'")->fetchColumn();
$withdrawsTotal=(float)$pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='withdraw' AND status='approved'")->fetchColumn();

$monthly=$pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') mon,SUM(commission) rev,SUM(amount) vol,COUNT(*) orders FROM purchases WHERE status='completed' AND created_at>=DATE_SUB(NOW(),INTERVAL 12 MONTH) GROUP BY mon ORDER BY mon DESC")->fetchAll();
$maxRev=$monthly?max(array_column($monthly,'rev')):1;

$topSellers=$pdo->query("SELECT u.username,u.seller_rating,u.total_sales,COUNT(p.id) deals,SUM(p.seller_net) net FROM purchases p JOIN users u ON p.seller_id=u.id WHERE p.status='completed' GROUP BY p.seller_id ORDER BY deals DESC LIMIT 10")->fetchAll();
$cats=$pdo->query("SELECT c.name_ar,COUNT(p.id) deals,SUM(p.amount) vol FROM purchases p JOIN listings l ON p.listing_id=l.id JOIN categories c ON l.category_id=c.id WHERE p.status='completed' GROUP BY c.id ORDER BY vol DESC LIMIT 10")->fetchAll();
$maxVol=$cats?max(array_column($cats,'vol')):1;

adminHead('التقارير','reports');
adminTopbar('التقارير والإحصائيات 📊','تحليل شامل لأداء المنصة');
?>
<div class="stats-grid">
  <div class="stat-card"><div class="stat-card-icon gold"><i class="fas fa-dollar-sign"></i></div><div><div class="stat-card-val"><?=money($totalRevenue)?></div><div class="stat-card-lbl">إجمالي العمولات</div></div></div>
  <div class="stat-card"><div class="stat-card-icon green"><i class="fas fa-check-double"></i></div><div><div class="stat-card-val"><?=number_format($totalOrders)?></div><div class="stat-card-lbl">صفقات مكتملة</div></div></div>
  <div class="stat-card"><div class="stat-card-icon blue"><i class="fas fa-users"></i></div><div><div class="stat-card-val"><?=number_format($totalUsers)?></div><div class="stat-card-lbl">إجمالي المستخدمين</div></div></div>
  <div class="stat-card"><div class="stat-card-icon purple"><i class="fas fa-chart-line"></i></div><div><div class="stat-card-val"><?=money($avgOrder)?></div><div class="stat-card-lbl">متوسط قيمة الصفقة</div></div></div>
  <div class="stat-card"><div class="stat-card-icon cyan"><i class="fas fa-layer-group"></i></div><div><div class="stat-card-val"><?=money($totalVolume)?></div><div class="stat-card-lbl">حجم المعاملات</div></div></div>
  <div class="stat-card"><div class="stat-card-icon gold"><i class="fas fa-list"></i></div><div><div class="stat-card-val"><?=number_format($activeListings)?></div><div class="stat-card-lbl">إعلانات نشطة</div></div></div>
  <div class="stat-card"><div class="stat-card-icon green"><i class="fas fa-user-plus"></i></div><div><div class="stat-card-val"><?=$newUsersWeek?></div><div class="stat-card-lbl">مسجلون جدد (7 أيام)</div></div></div>
</div>

<div class="col-grid" style="margin-bottom:20px">
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-arrow-down" style="color:var(--green)"></i> إجمالي الإيداعات المقبولة</div>
    <div style="font-size:2rem;font-weight:900;color:var(--green);font-family:'JetBrains Mono',monospace"><?=money($depositsTotal)?></div>
  </div>
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-arrow-up" style="color:var(--red)"></i> إجمالي السحوبات المقبولة</div>
    <div style="font-size:2rem;font-weight:900;color:var(--red);font-family:'JetBrains Mono',monospace"><?=money($withdrawsTotal)?></div>
  </div>
</div>

<div class="col-grid">
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-chart-bar"></i> العمولات الشهرية</div>
    <?php if(empty($monthly)):?><div class="empty"><i class="fas fa-chart-bar"></i><p>لا توجد بيانات</p></div>
    <?php else: foreach($monthly as $m):?>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <div style="font-size:.75rem;color:var(--t2);width:70px;text-align:right;flex-shrink:0"><?=e($m['mon'])?></div>
      <div style="flex:1;height:8px;background:var(--bg3);border-radius:4px;overflow:hidden">
        <div style="height:100%;background:linear-gradient(90deg,var(--gold),var(--gold3));border-radius:4px;width:<?=$maxRev>0?round((float)$m['rev']/$maxRev*100):0?>%"></div>
      </div>
      <div style="font-size:.72rem;font-family:'JetBrains Mono',monospace;color:var(--t2);width:80px;text-align:left"><?=money((float)$m['rev'])?></div>
    </div>
    <?php endforeach; endif;?>
  </div>
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-tags"></i> أعلى الفئات مبيعاً</div>
    <?php if(empty($cats)):?><div class="empty"><i class="fas fa-tags"></i><p>لا توجد بيانات</p></div>
    <?php else: foreach($cats as $c):?>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <div style="font-size:.75rem;color:var(--t2);width:80px;text-align:right;flex-shrink:0"><?=e(mb_substr($c['name_ar'],0,9,'UTF-8'))?></div>
      <div style="flex:1;height:8px;background:var(--bg3);border-radius:4px;overflow:hidden">
        <div style="height:100%;background:linear-gradient(90deg,var(--blue),var(--purple));border-radius:4px;width:<?=$maxVol>0?round((float)$c['vol']/$maxVol*100):0?>%"></div>
      </div>
      <div style="font-size:.72rem;font-family:'JetBrains Mono',monospace;color:var(--t2);width:80px;text-align:left"><?=money((float)$c['vol'])?></div>
    </div>
    <?php endforeach; endif;?>
  </div>
</div>

<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-trophy" style="color:var(--gold)"></i> أفضل البائعين</div>
  <?php if(empty($topSellers)):?>
    <div class="empty"><i class="fas fa-trophy"></i><p>لا توجد بيانات بعد</p></div>
  <?php else:?>
  <div style="overflow-x:auto">
    <table>
      <thead><tr><th>#</th><th>البائع</th><th>الصفقات</th><th>صافي المبيعات</th><th>التقييم</th></tr></thead>
      <tbody>
      <?php foreach($topSellers as $i=>$s):?>
      <tr>
        <td class="mono gold"><?=$i+1?></td>
        <td><a href="users.php?q=<?=urlencode($s['username'])?>" style="font-weight:700;color:var(--t1)"><?=e($s['username'])?></a></td>
        <td class="mono"><?=number_format($s['deals'])?></td>
        <td class="mono gold"><?=money((float)$s['net'])?></td>
        <td style="color:var(--gold)"><?=renderStars((float)$s['seller_rating'])?> <?=number_format((float)$s['seller_rating'],1)?></td>
      </tr>
      <?php endforeach;?>
      </tbody>
    </table>
  </div>
  <?php endif;?>
</div>
<?php adminFoot();?>
