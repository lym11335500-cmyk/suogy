<?php
require_once '../includes/db.php';
require_once '../includes/admin_layout.php';
require_once '../includes/auction_helpers.php';
adminCheck();

// تسوية تلقائية
try { settleExpiredAuctions($pdo); } catch(Exception $e){}

$msg=''; $err='';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $act=(string)($_POST['act']??'');

    if($act==='settle_now'){
        $id=(int)($_POST['aid']??0);
        settleAuction($pdo,$id);
        $msg='تم إنهاء المزاد وتوزيع الأموال!';
    }
    if($act==='cancel'){
        $id=(int)($_POST['aid']??0);
        try {
            $topBidders=$pdo->query("SELECT user_id,MAX(bid_amount) top FROM bids WHERE auction_id=$id GROUP BY user_id")->fetchAll();
            foreach($topBidders as $b){
                $u=$pdo->query("SELECT balance,held_balance FROM users WHERE id=".(int)$b['user_id'])->fetch();
                $amt=(float)$b['top'];
                $pdo->prepare("UPDATE users SET balance=balance+?,held_balance=GREATEST(0,held_balance-?) WHERE id=?")->execute([$amt,$amt,$b['user_id']]);
                addNotif($pdo,(int)$b['user_id'],'auction','❌ تم إلغاء المزاد وإرجاع رصيدك','');
            }
            $pdo->prepare("UPDATE auctions SET status='cancelled' WHERE id=?")->execute([$id]);
            $msg='تم إلغاء المزاد وإرجاع جميع الحجوزات.';
        } catch(Exception $e){ $err='خطأ: '.$e->getMessage(); }
    }
    if($act==='update_commission'){
        $rate=(float)($_POST['rate']??5);
        try {
            $pdo->prepare("UPDATE site_settings SET setting_value=? WHERE setting_key='auction_commission_rate'")->execute([$rate]);
            $pdo->prepare("INSERT IGNORE INTO site_settings (setting_key,setting_value) VALUES ('auction_commission_rate',?)")->execute([$rate]);
            $msg='تم تحديث نسبة العمولة إلى '.$rate.'%';
        } catch(Exception $e){ $err='خطأ في الحفظ'; }
    }
    if($act==='update_increment'){
        $inc=(float)($_POST['increment']??1);
        try {
            $pdo->prepare("UPDATE site_settings SET setting_value=? WHERE setting_key='auction_min_increment'")->execute([$inc]);
            $pdo->prepare("INSERT IGNORE INTO site_settings (setting_key,setting_value) VALUES ('auction_min_increment',?)")->execute([$inc]);
            $msg='تم تحديث الحد الأدنى للزيادة';
        } catch(Exception $e){ $err='خطأ في الحفظ'; }
    }
}

$tab = $_GET['tab'] ?? 'active';

try { $active    = $pdo->query("SELECT a.*,u.username seller_name FROM auctions a JOIN users u ON u.id=a.seller_id WHERE a.status='active' ORDER BY a.end_date ASC")->fetchAll(); } catch(Exception $e){ $active=[]; }
try { $completed = $pdo->query("SELECT a.*,u.username seller_name,w.username winner_name FROM auctions a JOIN users u ON u.id=a.seller_id LEFT JOIN users w ON w.id=a.winner_id WHERE a.status='completed' ORDER BY a.end_date DESC LIMIT 50")->fetchAll(); } catch(Exception $e){ $completed=[]; }
try { $cancelled = $pdo->query("SELECT a.*,u.username seller_name FROM auctions a JOIN users u ON u.id=a.seller_id WHERE a.status='cancelled' ORDER BY a.created_at DESC LIMIT 30")->fetchAll(); } catch(Exception $e){ $cancelled=[]; }

$totalActive    = count($active);
$totalCompleted = count($completed);
try { $totalBids = (int)$pdo->query("SELECT COUNT(*) FROM bids")->fetchColumn(); } catch(Exception $e){ $totalBids=0; }
try { $commRate  = getSetting($pdo,'auction_commission_rate','5'); } catch(Exception $e){ $commRate='5'; }
try { $minInc    = getSetting($pdo,'auction_min_increment','1');   } catch(Exception $e){ $minInc='1'; }

adminHead('إدارة المزادات');
?>
<div style="padding:24px;max-width:1200px">

<?php adminTopbar('إدارة المزادات', ''); ?>

<?php if($msg): ?><div class="alert alert-ok" style="margin-bottom:16px"><i class="fas fa-check-circle"></i> <?=e($msg)?></div><?php endif; ?>

<!-- Stats -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px">
  <div class="stat-card"><div class="stat-card-icon gold"><i class="fas fa-fire"></i></div><div><div class="stat-card-val"><?=$totalActive?></div><div class="stat-card-lbl">مزادات نشطة</div></div></div>
  <div class="stat-card"><div class="stat-card-icon green"><i class="fas fa-check-circle"></i></div><div><div class="stat-card-val"><?=$totalCompleted?></div><div class="stat-card-lbl">مكتملة</div></div></div>
  <div class="stat-card"><div class="stat-card-icon blue"><i class="fas fa-gavel"></i></div><div><div class="stat-card-val"><?=$totalBids?></div><div class="stat-card-lbl">إجمالي المزايدات</div></div></div>
  <div class="stat-card"><div class="stat-card-icon gold"><i class="fas fa-percent"></i></div><div><div class="stat-card-val"><?=$commRate?>%</div><div class="stat-card-lbl">نسبة العمولة</div></div></div>
</div>

<!-- Settings Row -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
  <div class="tbl-wrap">
    <div class="tbl-head"><div class="tbl-title"><i class="fas fa-percent"></i> نسبة عمولة المزادات</div></div>
    <div style="padding:14px">
      <form method="POST" style="display:flex;gap:8px;align-items:center">
        <?=csrfField()?><input type="hidden" name="act" value="update_commission">
        <input type="number" name="rate" class="fi" value="<?=e($commRate)?>" min="0" max="50" step="0.5" style="width:80px;text-align:center">
        <span style="color:var(--t2);font-size:.8rem">%</span>
        <button class="btn btn-gold btn-sm"><i class="fas fa-save"></i> حفظ</button>
      </form>
    </div>
  </div>
  <div class="tbl-wrap">
    <div class="tbl-head"><div class="tbl-title"><i class="fas fa-step-up"></i> الحد الأدنى للزيادة</div></div>
    <div style="padding:14px">
      <form method="POST" style="display:flex;gap:8px;align-items:center">
        <?=csrfField()?><input type="hidden" name="act" value="update_increment">
        <input type="number" name="increment" class="fi" value="<?=e($minInc)?>" min="0.01" step="0.01" style="width:100px;text-align:center">
        <span style="color:var(--t2);font-size:.8rem">USDT</span>
        <button class="btn btn-gold btn-sm"><i class="fas fa-save"></i> حفظ</button>
      </form>
    </div>
  </div>
</div>

<!-- Tabs -->
<div style="display:flex;gap:6px;margin-bottom:16px">
  <a href="?tab=active"    class="btn <?=$tab==='active'?'btn-gold':'btn-ghost'?> btn-sm"><i class="fas fa-fire"></i> نشطة (<?=$totalActive?>)</a>
  <a href="?tab=completed" class="btn <?=$tab==='completed'?'btn-gold':'btn-ghost'?> btn-sm"><i class="fas fa-check"></i> مكتملة</a>
  <a href="?tab=cancelled" class="btn <?=$tab==='cancelled'?'btn-gold':'btn-ghost'?> btn-sm"><i class="fas fa-times"></i> ملغاة</a>
</div>

<?php
$rows = $tab==='active' ? $active : ($tab==='completed' ? $completed : $cancelled);
?>
<div class="tbl-wrap">
  <table style="width:100%;border-collapse:collapse">
    <thead><tr style="background:rgba(255,255,255,.02);border-bottom:1px solid rgba(255,255,255,.08)">
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">المزاد</th>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">البائع</th>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">السعر الحالي</th>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">المزايدات</th>
      <?php if($tab==='active'): ?>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">ينتهي</th>
      <?php elseif($tab==='completed'): ?>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">الفائز</th>
      <?php endif; ?>
      <th style="padding:10px 14px;text-align:right;font-size:.7rem;color:#8b95b5">إجراء</th>
    </tr></thead>
    <tbody>
    <?php if(empty($rows)): ?>
      <tr><td colspan="6" style="padding:30px;text-align:center;color:#8b95b5">لا توجد مزادات</td></tr>
    <?php else: foreach($rows as $r): ?>
    <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
      <td style="padding:10px 14px">
        <a href="../pages/auction.php?id=<?=$r['id']?>" target="_blank" style="color:var(--t1);font-weight:700;font-size:.82rem"><?=e(mb_substr($r['title'],0,35,'UTF-8'))?><?=mb_strlen($r['title'],'UTF-8')>35?'…':''?></a>
      </td>
      <td style="padding:10px 14px;font-size:.78rem;color:#8b95b5">@<?=e($r['seller_name'])?></td>
      <td style="padding:10px 14px;color:#e8a400;font-weight:900;font-family:'JetBrains Mono',monospace"><?=money((float)$r['current_price'])?></td>
      <td style="padding:10px 14px;text-align:center"><?=$r['bid_count']??0?></td>
      <?php if($tab==='active'): ?>
      <td style="padding:10px 14px;font-size:.72rem;color:<?=(strtotime($r['end_date'])-time()<86400)?'#ff4757':'#8b95b5'?>">
        <?=auctionTimeLeft($r['end_date'])?>
      </td>
      <?php elseif($tab==='completed'): ?>
      <td style="padding:10px 14px;font-size:.78rem;color:#10d97a">@<?=e($r['winner_name']??'—')?></td>
      <?php if($tab==='completed'):
        $roomRow=null;
        try{$rq=$pdo->prepare("SELECT id FROM chats WHERE auction_id=? LIMIT 1");$rq->execute([$r['id']]);$roomRow=$rq->fetchColumn();}catch(Exception $e){}
      ?>
      <td style="padding:10px 14px">
        <?php if($roomRow): ?>
        <a href="../pages/auction_deal.php?rid=<?=$roomRow?>" class="btn btn-ghost btn-xs" target="_blank">
          <i class="fas fa-comments"></i> الغرفة
        </a>
        <?php else: ?><span style="color:var(--t3);font-size:.7rem">—</span><?php endif; ?>
      </td>
      <?php endif; ?>
      <?php endif; ?>
      <td style="padding:10px 14px">
        <div style="display:flex;gap:5px;flex-wrap:wrap">
          <?php if($tab==='active'): ?>
          <form method="POST" style="display:inline">
            <?=csrfField()?><input type="hidden" name="act" value="settle_now"><input type="hidden" name="aid" value="<?=$r['id']?>">
            <button class="btn btn-gold btn-xs" onclick="return confirm('إنهاء المزاد وتوزيع الأموال الآن؟')"><i class="fas fa-flag-checkered"></i> إنهاء</button>
          </form>
          <form method="POST" style="display:inline">
            <?=csrfField()?><input type="hidden" name="act" value="cancel"><input type="hidden" name="aid" value="<?=$r['id']?>">
            <button class="btn btn-outline btn-xs" style="color:#ff4757;border-color:rgba(255,71,87,.3)" onclick="return confirm('إلغاء المزاد وإرجاع الحجوزات؟')"><i class="fas fa-times"></i> إلغاء</button>
          </form>
          <?php endif; ?>
          <a href="../pages/auction.php?id=<?=$r['id']?>" target="_blank" class="btn btn-ghost btn-xs">عرض</a>
        </div>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

</div>
<?php adminFoot(); ?>
