<?php
require_once 'admin_check.php';

$msg = '';

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';
    $lid = (int)($_POST['lid'] ?? 0);

    if ($act === 'approve' && $lid) {
        $pdo->prepare("UPDATE listings SET status='active' WHERE id=?")->execute([$lid]);
        $msg = 'تم تفعيل الإعلان.';
    } elseif ($act === 'disable' && $lid) {
        $pdo->prepare("UPDATE listings SET status='disabled' WHERE id=?")->execute([$lid]);
        $msg = 'تم تعطيل الإعلان.';
    } elseif ($act === 'delete' && $lid) {
        $pdo->prepare("DELETE FROM listings WHERE id=?")->execute([$lid]);
        $msg = 'تم حذف الإعلان.';
    } elseif ($act === 'mark_sold' && $lid) {
        $pdo->prepare("UPDATE listings SET status='sold' WHERE id=?")->execute([$lid]);
        $msg = 'تم تحديد الإعلان كمُباع.';
    }
}

// Filters
$search  = trim($_GET['q'] ?? '');
$filter  = $_GET['f'] ?? 'all';
$cat     = (int)($_GET['cat'] ?? 0);
$page    = max(1, (int)($_GET['p'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where  = "WHERE 1=1";
$params = [];

if ($search) {
    $where .= " AND (l.title LIKE ? OR u.username LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like;
}
if ($filter !== 'all') {
    $where .= " AND l.status=?"; $params[] = $filter;
}
if ($cat) {
    $where .= " AND l.category_id=?"; $params[] = $cat;
}

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM listings l JOIN users u ON l.user_id=u.id $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, ceil($total / $perPage));

$stmt = $pdo->prepare("SELECT l.*,c.name_ar cat_name,c.icon cat_icon,u.username seller
    FROM listings l
    JOIN categories c ON l.category_id=c.id
    JOIN users u ON l.user_id=u.id
    $where ORDER BY l.created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$listings = $stmt->fetchAll();

$categories = $pdo->query("SELECT id,name_ar FROM categories WHERE is_active=1 ORDER BY sort_order")->fetchAll();

adminHead('الإعلانات', 'ads.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      الإعلانات
      <small>إجمالي: <?= number_format($total) ?></small>
    </div>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?=e($msg)?></span></div><?php endif; ?>

<!-- FILTERS -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;align-items:center">
  <?php foreach (['all'=>'الكل','active'=>'نشطة','disabled'=>'معطلة','sold'=>'مُباعة','expired'=>'منتهية'] as $k=>$v): ?>
  <a href="?f=<?=$k?>&q=<?=urlencode($search)?>&cat=<?=$cat?>"
     class="btn btn-sm <?=$filter===$k?'btn-gold':'btn-ghost'?>" style="font-size:.75rem"><?=$v?></a>
  <?php endforeach; ?>
  <form method="GET" style="margin-right:auto;display:flex;gap:6px;flex-wrap:wrap">
    <input type="hidden" name="f" value="<?=e($filter)?>">
    <select name="cat" class="fsel" style="width:150px;padding:7px 10px;font-size:.78rem">
      <option value="0">كل الفئات</option>
      <?php foreach ($categories as $c): ?>
      <option value="<?=$c['id']?>" <?=$cat===$c['id']?'selected':''?>><?=e($c['name_ar']??$c['name'])?></option>
      <?php endforeach; ?>
    </select>
    <div class="search-bar" style="min-width:200px">
      <i class="fas fa-search"></i>
      <input type="text" name="q" value="<?=e($search)?>" placeholder="بحث في الإعلانات...">
    </div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-search"></i></button>
  </form>
</div>

<!-- TABLE -->
<div class="data-table-wrap">
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>الإعلان</th>
          <th>الفئة</th>
          <th>البائع</th>
          <th>السعر</th>
          <th>المشاهدات</th>
          <th>تاريخ النشر</th>
          <th>الحالة</th>
          <th>إجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($listings)): ?>
        <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--txt3)">لا توجد إعلانات</td></tr>
        <?php else: foreach ($listings as $l):
          $thumb = getListingThumb($pdo, (int)$l['id']);
        ?>
        <tr>
          <td class="mono txt2" style="font-size:.72rem"><?=$l['id']?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:40px;height:40px;border-radius:var(--r3);background:var(--bg3);overflow:hidden;flex-shrink:0;display:flex;align-items:center;justify-content:center;color:var(--txt3);font-size:.8rem">
                <?php if($thumb): ?><img src="../<?=e($thumb)?>" style="width:100%;height:100%;object-fit:cover" alt="">
                <?php else: ?><i class="fas <?=e($l['cat_icon'])?>"></i><?php endif; ?>
              </div>
              <div class="truncate" style="font-size:.82rem;font-weight:700"><?=e($l['title'])?></div>
            </div>
          </td>
          <td style="font-size:.72rem;color:var(--txt2)"><?=e($l['cat_name']??'—')?></td>
          <td>
            <a href="users.php?detail=<?=$l['user_id']?>" style="color:var(--gold);text-decoration:none;font-size:.8rem">
              <?=e($l['seller'])?>
            </a>
          </td>
          <td class="mono gold"><?=money((float)$l['price'])?></td>
          <td class="mono txt2" style="text-align:center"><?=number_format($l['views'])?></td>
          <td class="txt2" style="font-size:.72rem"><?=timeAgo($l['created_at'])?></td>
          <td><span class="tag tag-<?=$l['status']?>"><?=statusLabel($l['status'])?></span></td>
          <td>
            <div class="table-actions">
              <a href="../pages/listing.php?id=<?=$l['id']?>" target="_blank"
                 class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3)" title="عرض">
                <i class="fas fa-external-link-alt" style="font-size:.7rem"></i>
              </a>
              <form method="POST" style="display:contents">
                <input type="hidden" name="_csrf" value="<?=csrf()?>">
                <input type="hidden" name="lid" value="<?=$l['id']?>">
                <?php if ($l['status'] === 'disabled'): ?>
                <button type="submit" name="act" value="approve"
                  class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3);color:var(--green);border-color:#22c55e22" title="تفعيل">
                  <i class="fas fa-check"></i>
                </button>
                <?php else: ?>
                <button type="submit" name="act" value="disable"
                  class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3);color:var(--red);border-color:#ef444422" title="تعطيل">
                  <i class="fas fa-ban"></i>
                </button>
                <?php endif; ?>
                <button type="submit" name="act" value="delete"
                  class="icon-btn" style="width:30px;height:30px;border-radius:var(--r3);color:var(--red);border-color:#ef444422"
                  onclick="return confirm('حذف الإعلان نهائياً؟')" title="حذف">
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="pagination">
    <?php for ($i=1; $i<=min($pages,10); $i++): ?>
    <a href="?f=<?=e($filter)?>&q=<?=urlencode($search)?>&cat=<?=$cat?>&p=<?=$i?>"
       class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php adminFoot(); ?>
