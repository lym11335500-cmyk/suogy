<?php
require_once 'admin_check.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act  = $_POST['act'] ?? '';
    $pid  = (int)($_POST['pid'] ?? 0);
    $side = $_POST['side'] ?? 'buyer';

    if ($act === 'resolve' && $pid) {
        $chat = $pdo->query("SELECT id FROM chats WHERE purchase_id=$pid LIMIT 1")->fetch();
        if ($side === 'seller') {
            completePurchase($pdo, $pid);
            addNotif($pdo,(int)$pdo->query("SELECT buyer_id FROM purchases WHERE id=$pid")->fetchColumn(),
                'dispute','⚖️ تم حل النزاع لصالح البائع.',"/deal.php?pid=$pid");
            $msg = 'تم حل النزاع لصالح البائع.';
        } else {
            if ($chat) refundPurchase($pdo,$pid,$chat['id'],'completed');
            addNotif($pdo,(int)$pdo->query("SELECT seller_id FROM purchases WHERE id=$pid")->fetchColumn(),
                'dispute','⚖️ تم حل النزاع لصالح المشتري.',"/deal.php?pid=$pid");
            $msg = 'تم حل النزاع لصالح المشتري.';
        }
    }
}

$disputes = $pdo->query("SELECT p.*,l.title listing_title,b.username buyer,s.username seller,
    (SELECT COUNT(*) FROM messages m JOIN chats c ON m.chat_id=c.id WHERE c.purchase_id=p.id) msg_count
    FROM purchases p JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id JOIN users s ON p.seller_id=s.id
    WHERE p.status='disputed' ORDER BY p.created_at DESC")->fetchAll();

adminHead('النزاعات', 'disputes.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      النزاعات
      <small><?=count($disputes)?> نزاع مفتوح</small>
    </div>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?=e($msg)?></span></div><?php endif; ?>

<?php if (empty($disputes)): ?>
<div class="sec-card" style="text-align:center;padding:50px">
  <i class="fas fa-balance-scale" style="font-size:2.5rem;color:var(--green);display:block;margin-bottom:12px"></i>
  <div style="font-size:.95rem;font-weight:700;color:var(--txt2)">لا توجد نزاعات مفتوحة</div>
  <div style="font-size:.78rem;color:var(--txt3);margin-top:6px">كل الصفقات تسير بسلاسة</div>
</div>
<?php else: ?>
<?php foreach ($disputes as $d): ?>
<div class="sec-card">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:.95rem;margin-bottom:8px;color:var(--red)">
        <i class="fas fa-exclamation-triangle" style="margin-left:6px"></i>
        <?=e(mb_substr($d['listing_title'],0,50,'UTF-8'))?>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
        <div style="background:var(--bg2);border:1px solid #3b82f622;border-radius:var(--r2);padding:12px;text-align:center">
          <i class="fas fa-user-tie" style="color:var(--blue);margin-bottom:6px;display:block"></i>
          <div style="font-weight:700;color:var(--blue)"><?=e($d['buyer'])?></div>
          <div style="font-size:.65rem;color:var(--txt3)">المشتري · <?=money((float)$d['amount'])?></div>
        </div>
        <div style="background:var(--bg2);border:1px solid #f0b42922;border-radius:var(--r2);padding:12px;text-align:center">
          <i class="fas fa-store" style="color:var(--gold);margin-bottom:6px;display:block"></i>
          <div style="font-weight:700;color:var(--gold)"><?=e($d['seller'])?></div>
          <div style="font-size:.65rem;color:var(--txt3)">البائع · صافي <?=money((float)$d['seller_net'])?></div>
        </div>
      </div>
      <div style="display:flex;gap:12px;font-size:.75rem;color:var(--txt2)">
        <span><i class="fas fa-calendar" style="margin-left:4px"></i><?=timeAgo($d['created_at'])?></span>
        <span><i class="fas fa-comment" style="margin-left:4px"></i><?=$d['msg_count']?> رسالة</span>
        <span class="mono gold"><?=money((float)$d['amount'])?></span>
      </div>
    </div>

    <form method="POST" style="flex-shrink:0">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="resolve">
      <input type="hidden" name="pid" value="<?=$d['id']?>">
      <div style="background:var(--bg2);border-radius:var(--r2);padding:14px;min-width:180px">
        <div style="font-size:.72rem;color:var(--txt3);margin-bottom:8px;font-weight:700;letter-spacing:.5px">حل النزاع لصالح:</div>
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px;cursor:pointer;font-size:.82rem">
          <input type="radio" name="side" value="buyer" checked> <span style="color:var(--blue)"><?=e($d['buyer'])?> (المشتري)</span>
        </label>
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:12px;cursor:pointer;font-size:.82rem">
          <input type="radio" name="side" value="seller"> <span style="color:var(--gold)"><?=e($d['seller'])?> (البائع)</span>
        </label>
        <button type="submit" class="btn btn-gold btn-block btn-sm"
          onclick="return confirm('تأكيد القرار النهائي؟ لا يمكن التراجع!')">
          <i class="fas fa-gavel"></i> إصدار الحكم
        </button>
      </div>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?php adminFoot(); ?>
