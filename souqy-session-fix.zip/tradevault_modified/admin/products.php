<?php
/**
 * admin/products.php — إدارة المنتجات الرقمية (ad_types)
 * يشمل: إضافة / تعديل / حذف / تعطيل أنواع الإعلانات والمنتجات الرقمية
 * وإدارة الإعلانات المدفوعة (ads table) مع مدة العرض والسعر
 */
require_once 'admin_check.php';

$msg=''; $err='';
$subtab = $_GET['sub'] ?? 'types';

if ($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    // ── Ad Types (أنواع المنتجات) ─────────────────────────
    if ($act === 'add_type') {
        $name = trim($_POST['type_name'] ?? '');
        $icon = trim($_POST['type_icon'] ?? 'fa-tag');
        $price= max(0, (float)($_POST['type_price'] ?? 0));
        $dur  = max(1, (int)($_POST['type_duration'] ?? 30));
        if ($name) {
            // Ensure columns exist
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN price DECIMAL(10,2) DEFAULT 0.00"); } catch(Exception $e){}
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN duration INT DEFAULT 30"); } catch(Exception $e){}
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN icon VARCHAR(100)"); } catch(Exception $e){}
            $pdo->prepare("INSERT INTO ad_types(name,icon,price,duration,status) VALUES(?,?,?,?,'active')")
                ->execute([$name,$icon,$price,$dur]);
            $msg = '✅ تم إضافة نوع المنتج.';
        } else { $err = 'اسم المنتج مطلوب.'; }
    }
    elseif ($act === 'edit_type') {
        $tid  = (int)($_POST['tid'] ?? 0);
        $name = trim($_POST['type_name'] ?? '');
        $icon = trim($_POST['type_icon'] ?? 'fa-tag');
        $price= max(0, (float)($_POST['type_price'] ?? 0));
        $dur  = max(1, (int)($_POST['type_duration'] ?? 30));
        $stat = in_array($_POST['type_status']??'',['active','inactive']) ? $_POST['type_status'] : 'active';
        if ($tid && $name) {
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN price DECIMAL(10,2) DEFAULT 0.00"); } catch(Exception $e){}
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN duration INT DEFAULT 30"); } catch(Exception $e){}
            try { $pdo->query("ALTER TABLE ad_types ADD COLUMN icon VARCHAR(100)"); } catch(Exception $e){}
            $pdo->prepare("UPDATE ad_types SET name=?,icon=?,price=?,duration=?,status=? WHERE id=?")
                ->execute([$name,$icon,$price,$dur,$stat,$tid]);
            $msg = '✅ تم تحديث المنتج.';
        }
    }
    elseif ($act === 'delete_type') {
        $tid = (int)($_POST['tid'] ?? 0);
        if ($tid) {
            $pdo->prepare("UPDATE ad_types SET status='inactive' WHERE id=?")->execute([$tid]);
            $msg = '✅ تم تعطيل المنتج.';
        }
    }
    // ── Ads management ────────────────────────────────────
    elseif ($act === 'approve_ad') {
        $aid = (int)($_POST['aid'] ?? 0);
        if ($aid) {
            $ad = $pdo->query("SELECT * FROM ads WHERE id=$aid")->fetch();
            if ($ad) {
                $dur = (int)($ad['duration'] ?? 30);
                $pdo->prepare("UPDATE ads SET status='active', start_date=CURDATE(), end_date=DATE_ADD(CURDATE(), INTERVAL ? DAY) WHERE id=?")->execute([$dur,$aid]);
                $msg = '✅ تم تفعيل الإعلان.';
            }
        }
    }
    elseif ($act === 'reject_ad') {
        $aid = (int)($_POST['aid'] ?? 0); $note = trim($_POST['note'] ?? '');
        if ($aid) {
            $pdo->prepare("UPDATE ads SET status='rejected' WHERE id=?")->execute([$aid]);
            $ad = $pdo->query("SELECT user_id FROM ads WHERE id=$aid")->fetch();
            if ($ad) addNotif($pdo,(int)$ad['user_id'],'ad_rejected','❌ تم رفض إعلانك'.($note?': '.$note:''),'../pages/dashboard.php');
            $msg = '✅ تم رفض الإعلان.';
        }
    }
    elseif ($act === 'delete_ad') {
        $aid = (int)($_POST['aid'] ?? 0);
        if ($aid) { $pdo->prepare("DELETE FROM ads WHERE id=?")->execute([$aid]); $msg = '✅ تم حذف الإعلان.'; }
    }
    elseif ($act === 'edit_ad') {
        $aid  = (int)($_POST['aid'] ?? 0);
        $title= trim($_POST['ad_title'] ?? '');
        $price= max(0, (float)($_POST['ad_price'] ?? 0));
        $dur  = max(1, (int)($_POST['ad_duration'] ?? 30));
        if ($aid) {
            $pdo->prepare("UPDATE ads SET title=?,price=?,duration=?,end_date=DATE_ADD(start_date, INTERVAL ? DAY) WHERE id=?")->execute([$title,$price,$dur,$dur,$aid]);
            $msg = '✅ تم تعديل الإعلان.';
        }
    }

    header("Location: products.php?sub=$subtab&saved=1"); exit;
}

// Ensure columns
try { $pdo->query("ALTER TABLE ad_types ADD COLUMN price DECIMAL(10,2) DEFAULT 0.00"); } catch(Exception $e){}
try { $pdo->query("ALTER TABLE ad_types ADD COLUMN duration INT DEFAULT 30"); } catch(Exception $e){}

$adTypes = $pdo->query("SELECT * FROM ad_types ORDER BY id")->fetchAll();
$pendingAds = (int)$pdo->query("SELECT COUNT(*) FROM ads WHERE status='pending'")->fetchColumn();
$totalAds   = (int)$pdo->query("SELECT COUNT(*) FROM ads")->fetchColumn();

// Ads with filters
$adsFilter = $_GET['af'] ?? 'pending';
$safeAf = in_array($adsFilter,['pending','active','expired','rejected']) ? $adsFilter : 'pending';
$adsList = $pdo->query("SELECT a.*,u.username,t.name type_name FROM ads a JOIN users u ON a.user_id=u.id JOIN ad_types t ON a.ad_type_id=t.id WHERE a.status='$safeAf' ORDER BY a.created_at DESC LIMIT 50")->fetchAll();

adminHead('المنتجات والإعلانات','products');
?>

<div class="adm-topbar">
  <div style="display:flex;align-items:center;gap:12px">
    <div class="adm-title">المنتجات الرقمية والإعلانات
      <small>إدارة الأنواع والإعلانات المدفوعة</small>
    </div>
  </div>
  <?php if($pendingAds>0): ?>
  <span class="badge badge-red" style="font-size:.8rem"><?=$pendingAds?> إعلان ينتظر المراجعة</span>
  <?php endif; ?>
</div>

<?php if(isset($_GET['saved'])): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>تم الحفظ بنجاح.</span></div><?php endif; ?>
<?php if($msg): echo '<div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>'.e($msg).'</span></div>'; endif; ?>
<?php if($err): echo '<div class="alert alert-err"><i class="fas fa-times-circle"></i><span>'.e($err).'</span></div>'; endif; ?>

<!-- SUB TABS -->
<div style="display:flex;gap:4px;background:var(--bg2);border-radius:var(--r2);padding:4px;margin-bottom:20px;max-width:400px">
  <a href="?sub=types" style="flex:1;text-align:center;padding:8px;border-radius:var(--r3);font-size:.78rem;font-weight:700;text-decoration:none;background:<?=$subtab==='types'?'var(--card)':'transparent'?>;color:<?=$subtab==='types'?'var(--gold)':'var(--t2)'?>;border:<?=$subtab==='types'?'1px solid rgba(232,164,0,.25)':'1px solid transparent'?>">
    <i class="fas fa-tags" style="display:block;margin-bottom:2px"></i>أنواع المنتجات
  </a>
  <a href="?sub=ads" style="flex:1;text-align:center;padding:8px;border-radius:var(--r3);font-size:.78rem;font-weight:700;text-decoration:none;background:<?=$subtab==='ads'?'var(--card)':'transparent'?>;color:<?=$subtab==='ads'?'var(--gold)':'var(--t2)'?>;border:<?=$subtab==='ads'?'1px solid rgba(232,164,0,.25)':'1px solid transparent'?>">
    <i class="fas fa-bullhorn" style="display:block;margin-bottom:2px"></i>الإعلانات <?=$pendingAds>0?'<span class="sb-badge">'.$pendingAds.'</span>':''?>
  </a>
</div>

<?php if($subtab==='types'): ?>
<!-- ══ AD TYPES ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-plus-circle"></i> إضافة نوع منتج جديد</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="add_type">
    <div class="col-grid">
      <div class="fg"><label>اسم المنتج <span style="color:var(--red)">*</span></label><input type="text" name="type_name" class="fi" placeholder="حساب تليجرام" required></div>
      <div class="fg"><label>أيقونة Font Awesome</label><input type="text" name="type_icon" class="fi" placeholder="fa-telegram" value="fa-tag"></div>
      <div class="fg">
        <label>سعر نشر الإعلان ($)</label>
        <input type="number" name="type_price" class="fi" step="0.01" min="0" value="0" placeholder="0 = مجاني">
        <div class="form-hint">ما يدفعه البائع لنشر الإعلان بهذا النوع</div>
      </div>
      <div class="fg">
        <label>مدة ظهور الإعلان (يوم)</label>
        <input type="number" name="type_duration" class="fi" min="1" max="365" value="30" placeholder="30">
        <div class="form-hint">عدد الأيام التي يظهر فيها الإعلان</div>
      </div>
    </div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إضافة</button>
  </form>
</div>

<div class="data-table-wrap">
  <div class="data-table-head" style="padding:12px 16px;display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:700"><i class="fas fa-tags" style="color:var(--gold);margin-left:6px"></i> أنواع المنتجات (<?=count($adTypes)?>)</div>
  </div>
  <div style="overflow-x:auto"><table>
    <thead><tr><th>#</th><th>النوع</th><th>السعر</th><th>المدة (يوم)</th><th>الإعلانات</th><th>الحالة</th><th>إجراءات</th></tr></thead>
    <tbody>
    <?php foreach($adTypes as $t):
      $cnt=(int)$pdo->query("SELECT COUNT(*) FROM ads WHERE ad_type_id={$t['id']}")->fetchColumn();
    ?>
    <tr>
      <td class="mono txt2" style="font-size:.7rem"><?=$t['id']?></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <i class="fas <?=e($t['icon']??'fa-tag')?>" style="color:var(--gold);width:16px;text-align:center"></i>
          <span style="font-weight:700;font-size:.84rem"><?=e($t['name'])?></span>
        </div>
      </td>
      <td class="mono gold"><?=money((float)($t['price']??0))?></td>
      <td class="mono" style="text-align:center"><?=e($t['duration']??30)?> يوم</td>
      <td class="mono" style="text-align:center"><?=$cnt?></td>
      <td><?=$t['status']==='active'?'<span class="badge badge-green">نشط</span>':'<span class="badge badge-gray">معطل</span>'?></td>
      <td>
        <div style="display:flex;gap:6px">
          <button onclick="toggleTypeEdit(<?=$t['id']?>)" class="btn btn-ghost btn-xs"><i class="fas fa-edit"></i></button>
          <form method="POST" style="display:inline" onsubmit="return confirm('تعطيل هذا النوع؟')">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete_type"><input type="hidden" name="tid" value="<?=$t['id']?>">
            <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-eye-slash"></i></button>
          </form>
        </div>
        <div id="typeEdit_<?=$t['id']?>" style="display:none;margin-top:8px">
          <form method="POST">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="edit_type"><input type="hidden" name="tid" value="<?=$t['id']?>">
            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end">
              <input type="text" name="type_name" class="fi" value="<?=e($t['name'])?>" style="width:130px" placeholder="الاسم" required>
              <input type="text" name="type_icon" class="fi" value="<?=e($t['icon']??'fa-tag')?>" style="width:100px" placeholder="أيقونة">
              <input type="number" name="type_price" class="fi" step="0.01" min="0" value="<?=e($t['price']??0)?>" style="width:80px" placeholder="السعر">
              <input type="number" name="type_duration" class="fi" min="1" value="<?=e($t['duration']??30)?>" style="width:70px" placeholder="مدة">
              <select name="type_status" class="fsel" style="width:90px">
                <option value="active" <?=$t['status']==='active'?'selected':''?>>نشط</option>
                <option value="inactive" <?=$t['status']!=='active'?'selected':''?>>معطل</option>
              </select>
              <button type="submit" class="btn btn-gold btn-xs"><i class="fas fa-save"></i></button>
            </div>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<?php else: ?>
<!-- ══ ADS ══ -->
<div class="ftabs" style="margin-bottom:16px">
  <?php foreach(['pending'=>'⏳ معلق','active'=>'✅ نشط','expired'=>'⌛ منتهي','rejected'=>'❌ مرفوض'] as $k=>$v): ?>
  <a href="?sub=ads&af=<?=$k?>" class="ftab <?=$safeAf===$k?'active':''?>"><?=$v?></a>
  <?php endforeach; ?>
</div>

<div class="data-table-wrap">
  <?php if(empty($adsList)): ?>
  <div style="text-align:center;padding:40px;color:var(--t3)"><i class="fas fa-inbox" style="font-size:2rem;margin-bottom:10px;display:block"></i>لا توجد إعلانات <?=$safeAf?></div>
  <?php else: ?>
  <div style="overflow-x:auto"><table>
    <thead><tr><th>#</th><th>العنوان</th><th>النوع</th><th>المستخدم</th><th>السعر</th><th>المدة</th><th>تاريخ الانتهاء</th><th>إجراءات</th></tr></thead>
    <tbody>
    <?php foreach($adsList as $ad): ?>
    <tr>
      <td class="mono txt2" style="font-size:.7rem"><?=$ad['id']?></td>
      <td style="font-size:.83rem;font-weight:700;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($ad['title']??'—')?></td>
      <td style="font-size:.78rem;color:var(--t2)"><?=e($ad['type_name'])?></td>
      <td><a href="users.php?detail=<?=$ad['user_id']?>" style="color:var(--gold);text-decoration:none;font-size:.8rem"><?=e($ad['username'])?></a></td>
      <td class="mono gold"><?=money((float)($ad['price']??0))?></td>
      <td class="mono" style="font-size:.78rem"><?=e($ad['duration']??30)?> يوم</td>
      <td style="font-size:.72rem;color:var(--t3)"><?=$ad['end_date']?e($ad['end_date']):'—'?></td>
      <td>
        <div style="display:flex;gap:5px;flex-wrap:wrap">
          <?php if($ad['status']==='pending'): ?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="approve_ad"><input type="hidden" name="aid" value="<?=$ad['id']?>">
            <button type="submit" class="btn btn-xs" style="background:rgba(16,217,122,.12);color:var(--green);border:1px solid rgba(16,217,122,.25)"><i class="fas fa-check"></i></button>
          </form>
          <form method="POST" style="display:inline" onsubmit="var n=prompt('سبب الرفض:');if(n===null)return false;this.querySelector('[name=note]').value=n;return true;">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="reject_ad"><input type="hidden" name="aid" value="<?=$ad['id']?>"><input type="hidden" name="note" value="">
            <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.12);color:var(--red);border:1px solid rgba(255,71,87,.25)"><i class="fas fa-times"></i></button>
          </form>
          <?php endif; ?>
          <button onclick="toggleAdEdit(<?=$ad['id']?>)" class="btn btn-ghost btn-xs"><i class="fas fa-edit"></i></button>
          <form method="POST" style="display:inline" onsubmit="return confirm('حذف الإعلان نهائياً؟')">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete_ad"><input type="hidden" name="aid" value="<?=$ad['id']?>">
            <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-trash"></i></button>
          </form>
        </div>
        <div id="adEdit_<?=$ad['id']?>" style="display:none;margin-top:8px">
          <form method="POST">
            <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="edit_ad"><input type="hidden" name="aid" value="<?=$ad['id']?>">
            <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end">
              <input type="text" name="ad_title" class="fi" value="<?=e($ad['title']??'')?>" style="width:140px" placeholder="العنوان">
              <input type="number" name="ad_price" class="fi" step="0.01" min="0" value="<?=e($ad['price']??0)?>" style="width:80px" placeholder="السعر">
              <input type="number" name="ad_duration" class="fi" min="1" value="<?=e($ad['duration']??30)?>" style="width:70px" placeholder="المدة">
              <button type="submit" class="btn btn-gold btn-xs"><i class="fas fa-save"></i> حفظ</button>
            </div>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php endif; ?>

<script>
function toggleTypeEdit(id){ var el=document.getElementById('typeEdit_'+id); el.style.display=el.style.display==='none'?'block':'none'; }
function toggleAdEdit(id){ var el=document.getElementById('adEdit_'+id); el.style.display=el.style.display==='none'?'block':'none'; }
</script>
<?php adminFoot(); ?>
