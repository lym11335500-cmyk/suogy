<?php
/**
 * admin/settings.php — لوحة الإعدادات الشاملة
 * التبويبات: general | financial | payments | phones | account
 */
require_once 'admin_check.php';

$msg = ''; $err = '';
$tab = $_GET['tab'] ?? 'general';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    if ($act === 'save_settings') {
        $allowed = ['site_name','site_description','commission_rate','min_price','max_price',
                    'warranty_hours','kyc_required','maintenance_mode',
                    'deposit_fee_pct','withdrawal_fee_pct',
                    'min_deposit','max_deposit','min_withdrawal','max_withdrawal'];
        foreach ($allowed as $f) {
            if (isset($_POST[$f])) saveSetting($pdo, $f, trim($_POST[$f]));
        }
        $msg = '✅ تم حفظ الإعدادات بنجاح.';
    }
    elseif ($act === 'change_password') {
        $cur = $_POST['current_password'] ?? ''; $new = $_POST['new_password'] ?? ''; $conf = $_POST['confirm_password'] ?? '';
        $row = $pdo->query("SELECT password FROM users WHERE id=".uid())->fetch();
        if (!verifyPassword($cur, $row['password'])) $err = 'كلمة المرور الحالية غير صحيحة.';
        elseif (strlen($new) < 6) $err = 'كلمة المرور الجديدة قصيرة جداً (6 أحرف على الأقل).';
        elseif ($new !== $conf) $err = 'كلمتا المرور غير متطابقتان.';
        else { $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$new, uid()]); $msg = '✅ تم تغيير كلمة المرور.'; }
    }
    elseif ($act === 'add_payment_method') {
        $n = trim($_POST['m_name'] ?? ''); $d = trim($_POST['m_desc'] ?? ''); $i = trim($_POST['m_icon'] ?? 'fa-coins');
        $t = in_array($_POST['m_type']??'',['deposit','withdraw','both']) ? $_POST['m_type'] : 'both';
        $f = max(0,(float)($_POST['m_fee']??0)); $p = max(0,(float)($_POST['m_fee_pct']??0));
        $mn= max(0,(float)($_POST['m_min']??1)); $mx= max(0.01,(float)($_POST['m_max']??50000));
        $a = trim($_POST['m_address'] ?? ''); $ins = trim($_POST['m_instructions'] ?? '');
        if ($n) {
            $pdo->prepare("INSERT INTO payment_methods(name,description,icon,type,fee_fixed,min_amount,max_amount,wallet_address,is_active) VALUES(?,?,?,?,?,?,?,?,1)")
                ->execute([$n,$d,$i,$t,$f,$mn,$mx,$a]);
            $mid = $pdo->lastInsertId();
            try { $pdo->prepare("UPDATE payment_methods SET fee_percent=?,instructions=? WHERE id=?")->execute([$p,$ins,$mid]); } catch(Exception $e){}
            $msg = '✅ تم إضافة وسيلة الدفع.';
        } else { $err = 'اسم الوسيلة مطلوب.'; }
    }
    elseif ($act === 'edit_payment_method') {
        $mid=(int)($_POST['mid']??0); $n=trim($_POST['m_name']??''); $d=trim($_POST['m_desc']??''); $i=trim($_POST['m_icon']??'fa-coins');
        $f=max(0,(float)($_POST['m_fee']??0)); $p=max(0,(float)($_POST['m_fee_pct']??0));
        $mn=max(0,(float)($_POST['m_min']??0)); $mx=max(0.01,(float)($_POST['m_max']??50000));
        $a=trim($_POST['m_address']??''); $ins=trim($_POST['m_instructions']??''); $ac=(int)($_POST['m_active']??1);
        if ($mid && $n) {
            $pdo->prepare("UPDATE payment_methods SET name=?,description=?,icon=?,fee_fixed=?,min_amount=?,max_amount=?,wallet_address=?,is_active=? WHERE id=?")
                ->execute([$n,$d,$i,$f,$mn,$mx,$a,$ac,$mid]);
            try { $pdo->prepare("UPDATE payment_methods SET fee_percent=?,instructions=? WHERE id=?")->execute([$p,$ins,$mid]); } catch(Exception $e){}
            $msg = '✅ تم تحديث وسيلة الدفع.';
        }
    }
    elseif ($act === 'delete_payment_method') {
        $mid=(int)($_POST['mid']??0);
        if ($mid) { $pdo->prepare("DELETE FROM payment_methods WHERE id=?")->execute([$mid]); $msg = '✅ تم حذف وسيلة الدفع.'; }
    }
    elseif ($act === 'add_phone') {
        $phone = preg_replace('/[^\d+]/', '', trim($_POST['phone'] ?? '')); $note = trim($_POST['phone_note'] ?? '');
        if (strlen($phone) >= 7) {
            try {
                $pdo->prepare("INSERT INTO phone_whitelist(phone,note) VALUES(?,?) ON DUPLICATE KEY UPDATE note=?")->execute([$phone,$note,$note]);
                $msg = '✅ تم إضافة الرقم.';
            } catch(Exception $e) { $err = 'الرقم مكرر أو خطأ.'; }
        } else { $err = 'رقم الهاتف يجب أن يحتوي 7 أرقام على الأقل.'; }
    }
    elseif ($act === 'delete_phone') {
        $pid=(int)($_POST['pid']??0);
        if ($pid) { $pdo->prepare("DELETE FROM phone_whitelist WHERE id=?")->execute([$pid]); $msg = '✅ تم حذف الرقم.'; }
    }
    elseif ($act === 'toggle_phone_whitelist') {
        $cur = getSetting($pdo,'phone_whitelist_enabled','0');
        saveSetting($pdo,'phone_whitelist_enabled',$cur==='1'?'0':'1');
        $msg = '✅ تم تحديث إعداد القائمة البيضاء.';
    }

    if (!$err) { 
        // Redirect to correct tab after save
        $redir = $tab;
        if ($act === 'save_settings') {
            if (isset($_POST['deposit_fee_pct']) && !isset($_POST['withdrawal_fee_pct']) && !isset($_POST['commission_rate'])) $redir = 'deposit_cfg';
            elseif (isset($_POST['withdrawal_fee_pct']) && !isset($_POST['deposit_fee_pct']) && !isset($_POST['commission_rate'])) $redir = 'withdrawal_cfg';
        }
        header("Location: settings.php?tab=$redir&saved=1"); exit; 
    }
}

// Ensure phone_whitelist table
try { $pdo->query("CREATE TABLE IF NOT EXISTS phone_whitelist(id INT AUTO_INCREMENT PRIMARY KEY,phone VARCHAR(30) NOT NULL UNIQUE,note VARCHAR(100),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB CHARSET=utf8mb4"); } catch(Exception $e){}
// Ensure payment_methods extra columns
try { $pdo->query("ALTER TABLE payment_methods ADD COLUMN fee_percent DECIMAL(5,2) DEFAULT 0.00"); } catch(Exception $e){}
try { $pdo->query("ALTER TABLE payment_methods ADD COLUMN instructions TEXT"); } catch(Exception $e){}

function gs(string $k, string $def=''): string { global $pdo; return getSetting($pdo,$k,$def); }

$payMethods = $pdo->query("SELECT * FROM payment_methods ORDER BY sort_order,id")->fetchAll();
$phoneList  = $pdo->query("SELECT * FROM phone_whitelist ORDER BY created_at DESC")->fetchAll();
$adminUser  = $pdo->query("SELECT * FROM users WHERE id=".uid())->fetch();

adminHead('الإعدادات','settings');
?>

<div class="adm-topbar">
  <div style="display:flex;align-items:center;gap:12px">
    <div class="adm-title">الإعدادات <small>إدارة الموقع والأنظمة المالية</small></div>
  </div>
</div>

<?php if(isset($_GET['saved'])): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>تم الحفظ بنجاح.</span></div><?php endif; ?>
<?php if($msg): echo '<div class="alert alert-ok"><i class="fas fa-check-circle"></i><span>'.e($msg).'</span></div>'; endif; ?>
<?php if($err): echo '<div class="alert alert-err"><i class="fas fa-times-circle"></i><span>'.e($err).'</span></div>'; endif; ?>

<!-- TABS -->
<div style="display:flex;gap:4px;background:var(--bg2);border-radius:var(--r2);padding:4px;margin-bottom:24px;flex-wrap:wrap">
<?php
$tabs=['general'=>['fa-globe','عام'],'financial'=>['fa-percentage','مالي'],'deposit_cfg'=>['fa-arrow-circle-down','الإيداع'],'withdrawal_cfg'=>['fa-money-bill-wave','السحب'],'payments'=>['fa-credit-card','الدفع'],'phones'=>['fa-phone','الهواتف'],'account'=>['fa-user-shield','الحساب']];
foreach($tabs as $tk=>[$tic,$tlbl]):
  $isA=($tab===$tk);
?>
<a href="?tab=<?=$tk?>" style="flex:1;min-width:72px;text-align:center;padding:9px 4px;border-radius:var(--r3);font-size:.73rem;font-weight:700;text-decoration:none;background:<?=$isA?'var(--card)':'transparent'?>;color:<?=$isA?'var(--gold)':'var(--t2)'?>;border:<?=$isA?'1px solid rgba(232,164,0,.25)':'1px solid transparent'?>;transition:all .2s">
  <i class="fas <?=$tic?>" style="display:block;margin-bottom:3px;font-size:.88rem"></i><?=$tlbl?>
</a>
<?php endforeach; ?>
</div>

<?php if($tab==='general'): ?>
<!-- ══ GENERAL ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-globe"></i> إعدادات الموقع الأساسية</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="save_settings">
    <div class="col-grid">
      <div class="fg">
        <label>اسم الموقع <span style="color:var(--red)">*</span></label>
        <input type="text" name="site_name" class="fi" value="<?=e(gs('site_name','سوقي'))?>" required>
        <div class="form-hint">يظهر في رأسية الصفحات وعلامة التبويب</div>
      </div>
      <div class="fg">
        <label>وصف الموقع</label>
        <input type="text" name="site_description" class="fi" value="<?=e(gs('site_description','سوق رقمي موثوق لبيع وشراء الحسابات والمنتجات الرقمية'))?>">
      </div>
      <div class="fg">
        <label>وضع الصيانة</label>
        <select name="maintenance_mode" class="fsel">
          <option value="0" <?=gs('maintenance_mode','0')==='0'?'selected':''?>>🟢 معطل — الموقع يعمل</option>
          <option value="1" <?=gs('maintenance_mode','0')==='1'?'selected':''?>>🔴 مفعّل — الموقع تحت الصيانة</option>
        </select>
      </div>
      <div class="fg">
        <label>KYC مطلوب للبيع والشراء</label>
        <select name="kyc_required" class="fsel">
          <option value="1" <?=gs('kyc_required','1')==='1'?'selected':''?>>✅ نعم (مطلوب)</option>
          <option value="0" <?=gs('kyc_required','1')==='0'?'selected':''?>>❌ لا (اختياري)</option>
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> حفظ الإعدادات العامة</button>
  </form>
</div>
<div class="col-grid">
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:1.8rem;font-weight:900;color:var(--gold)"><?=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0")->fetchColumn()?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">المستخدمون</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:1.8rem;font-weight:900;color:var(--green)"><?=(int)$pdo->query("SELECT COUNT(*) FROM listings WHERE status='active'")->fetchColumn()?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">الإعلانات النشطة</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:1.8rem;font-weight:900;color:var(--blue)"><?=(int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='completed'")->fetchColumn()?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">الصفقات المكتملة</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:16px">
    <div style="font-size:1.8rem;font-weight:900;color:var(--gold)"><?=money((float)$pdo->query("SELECT COALESCE(SUM(commission),0) FROM purchases WHERE status='completed'")->fetchColumn())?></div>
    <div style="font-size:.72rem;color:var(--t3);margin-top:3px">إجمالي العمولات</div>
  </div>
</div>

<?php elseif($tab==='financial'): ?>
<!-- ══ FINANCIAL ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-percentage"></i> عمولة البيع وحدود الأسعار</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="save_settings">
    <div class="col-grid">
      <div class="fg">
        <label>نسبة عمولة البيع (%) <span style="color:var(--red)">*</span></label>
        <input type="number" name="commission_rate" class="fi" min="0" max="50" step="0.1" value="<?=e(gs('commission_rate','5'))?>">
        <div class="form-hint">تُخصم من البائع عند إتمام كل صفقة ناجحة</div>
      </div>
      <div class="fg">
        <label>مدة ضمان الصفقة (ساعات)</label>
        <input type="number" name="warranty_hours" class="fi" min="1" max="720" value="<?=e(gs('warranty_hours','24'))?>">
        <div class="form-hint">الوقت قبل الإغلاق التلقائي للصفقة</div>
      </div>
      <div class="fg">
        <label>أدنى سعر للإعلان ($)</label>
        <input type="number" name="min_price" class="fi" min="0" step="0.01" value="<?=e(gs('min_price','1'))?>">
      </div>
      <div class="fg">
        <label>أقصى سعر للإعلان ($)</label>
        <input type="number" name="max_price" class="fi" min="0" step="0.01" value="<?=e(gs('max_price','10000'))?>">
      </div>
    </div>
    <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> حفظ إعدادات البيع</button>
  </form>
</div>
<div class="alert alert-info">
  <i class="fas fa-info-circle"></i>
  <span>لإعدادات الإيداع والسحب، انتقل إلى تبويبَي <a href="?tab=deposit_cfg" style="color:var(--blue);font-weight:700">الإيداع</a> و<a href="?tab=withdrawal_cfg" style="color:var(--blue);font-weight:700">السحب</a> أعلاه.</span>
</div>

<?php elseif($tab==='deposit_cfg'): ?>
<!-- ══ DEPOSIT SETTINGS ══ -->
<div class="sec-card" style="border-color:rgba(16,217,122,.2)">
  <div class="sec-card-title" style="color:var(--green)"><i class="fas fa-arrow-circle-down"></i> إعدادات الإيداع</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="save_settings">
    <div class="col-grid">
      <div class="fg">
        <label>عمولة الإيداع (%)</label>
        <input type="number" name="deposit_fee_pct" class="fi" min="0" max="50" step="0.1" value="<?=e(gs('deposit_fee_pct','0'))?>">
        <div class="form-hint">0 = بدون عمولة. مثال: 2 = تُخصم 2% من كل إيداع</div>
      </div>
      <div class="fg">
        <label>أدنى مبلغ إيداع ($)</label>
        <input type="number" name="min_deposit" class="fi" min="0" step="0.01" value="<?=e(gs('min_deposit','5'))?>">
        <div class="form-hint">لا يُقبل أي إيداع أقل من هذا المبلغ</div>
      </div>
      <div class="fg">
        <label>أقصى مبلغ إيداع ($)</label>
        <input type="number" name="max_deposit" class="fi" min="0" step="0.01" value="<?=e(gs('max_deposit','50000'))?>">
        <div class="form-hint">سقف الإيداع الواحد لكل طلب</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button type="submit" class="btn btn-green"><i class="fas fa-save"></i> حفظ إعدادات الإيداع</button>
      <a href="deposit_methods.php" class="btn btn-ghost btn-sm"><i class="fas fa-cog"></i> إدارة طرق الإيداع</a>
      <a href="deposits.php" class="btn btn-ghost btn-sm"><i class="fas fa-list"></i> عرض الطلبات</a>
    </div>
  </form>
</div>
<div class="sec-card" style="border-color:rgba(16,217,122,.1)">
  <div class="sec-card-title"><i class="fas fa-info-circle"></i> ملخص الإيداعات</div>
  <div class="col-grid">
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--green)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='approved'")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">إيداع مقبول</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--gold)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='pending'")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">في الانتظار</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--blue)"><?=money((float)$pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='deposit' AND status='approved'")->fetchColumn())?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">إجمالي المودع</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--t2)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_methods WHERE type='deposit' AND is_active=1")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">طرق إيداع فعّالة</div>
    </div>
  </div>
</div>

<?php elseif($tab==='withdrawal_cfg'): ?>
<!-- ══ WITHDRAWAL SETTINGS ══ -->
<div class="sec-card" style="border-color:rgba(74,143,245,.2)">
  <div class="sec-card-title" style="color:var(--blue)"><i class="fas fa-money-bill-wave"></i> إعدادات السحب</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="save_settings">
    <div class="col-grid">
      <div class="fg">
        <label>عمولة السحب (%)</label>
        <input type="number" name="withdrawal_fee_pct" class="fi" min="0" max="50" step="0.1" value="<?=e(gs('withdrawal_fee_pct','0'))?>">
        <div class="form-hint">0 = بدون عمولة. مثال: 1.5 = تُخصم 1.5%</div>
      </div>
      <div class="fg">
        <label>أدنى مبلغ سحب ($)</label>
        <input type="number" name="min_withdrawal" class="fi" min="0" step="0.01" value="<?=e(gs('min_withdrawal','10'))?>">
        <div class="form-hint">لا يُقبل أي سحب أقل من هذا المبلغ</div>
      </div>
      <div class="fg">
        <label>أقصى مبلغ سحب ($)</label>
        <input type="number" name="max_withdrawal" class="fi" min="0" step="0.01" value="<?=e(gs('max_withdrawal','10000'))?>">
        <div class="form-hint">سقف السحب الواحد لكل طلب</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button type="submit" class="btn btn-blue"><i class="fas fa-save"></i> حفظ إعدادات السحب</button>
      <a href="withdraw_methods.php" class="btn btn-ghost btn-sm"><i class="fas fa-cog"></i> إدارة طرق السحب</a>
      <a href="withdrawals.php" class="btn btn-ghost btn-sm"><i class="fas fa-list"></i> عرض الطلبات</a>
    </div>
  </form>
</div>
<div class="sec-card" style="border-color:rgba(74,143,245,.1)">
  <div class="sec-card-title"><i class="fas fa-info-circle"></i> ملخص السحوبات</div>
  <div class="col-grid">
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--blue)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='withdraw' AND status='approved'")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">سحب مقبول</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--gold)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='withdraw' AND status='pending'")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">في الانتظار</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--blue)"><?=money((float)$pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='withdraw' AND status='approved'")->fetchColumn())?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">إجمالي المسحوب</div>
    </div>
    <div style="text-align:center;padding:14px;background:var(--bg2);border-radius:var(--r2)">
      <div style="font-size:1.6rem;font-weight:900;color:var(--t2)"><?=(int)$pdo->query("SELECT COUNT(*) FROM payment_methods WHERE type='withdraw' AND is_active=1")->fetchColumn()?></div>
      <div style="font-size:.72rem;color:var(--t3);margin-top:3px">طرق سحب فعّالة</div>
    </div>
  </div>
</div>

<?php elseif($tab==='payments'): ?>
<!-- ══ PAYMENT METHODS ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-plus-circle"></i> إضافة وسيلة دفع جديدة</div>
  <form method="POST">
    <input type="hidden" name="_csrf" value="<?=csrf()?>">
    <input type="hidden" name="act" value="add_payment_method">
    <div class="col-grid">
      <div class="fg"><label>الاسم <span style="color:var(--red)">*</span></label><input type="text" name="m_name" class="fi" placeholder="USDT TRC20" required></div>
      <div class="fg"><label>الوصف المختصر</label><input type="text" name="m_desc" class="fi" placeholder="أرسل على شبكة TRC20..."></div>
      <div class="fg"><label>عنوان المحفظة</label><input type="text" name="m_address" class="fi" placeholder="TYour...Address"></div>
      <div class="fg"><label>أيقونة (Font Awesome)</label><input type="text" name="m_icon" class="fi" placeholder="fa-coins" value="fa-coins"></div>
      <div class="fg"><label>النوع</label>
        <select name="m_type" class="fsel">
          <option value="both">إيداع وسحب</option>
          <option value="deposit">إيداع فقط</option>
          <option value="withdraw">سحب فقط</option>
        </select>
      </div>
      <div class="fg"><label>رسوم ثابتة ($)</label><input type="number" name="m_fee" class="fi" step="0.01" min="0" value="1"></div>
      <div class="fg"><label>رسوم نسبية (%)</label><input type="number" name="m_fee_pct" class="fi" step="0.1" min="0" value="0"><div class="form-hint">يُضاف فوق الرسوم الثابتة</div></div>
      <div class="fg"><label>أدنى مبلغ ($)</label><input type="number" name="m_min" class="fi" step="0.01" min="0" value="5"></div>
      <div class="fg"><label>أقصى مبلغ ($)</label><input type="number" name="m_max" class="fi" step="0.01" min="0" value="50000"></div>
    </div>
    <div class="fg"><label>تعليمات للمستخدم</label><textarea name="m_instructions" class="fta" rows="2" placeholder="أرسل المبلغ ثم ارفع صورة الإيصال..."></textarea></div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إضافة وسيلة</button>
  </form>
</div>

<div style="font-weight:700;font-size:.88rem;margin-bottom:12px;color:var(--t1)"><i class="fas fa-list" style="color:var(--gold);margin-left:6px"></i> وسائل الدفع الحالية (<?=count($payMethods)?>)</div>

<?php if(empty($payMethods)): ?>
<div style="text-align:center;padding:40px;color:var(--t3)"><i class="fas fa-inbox" style="font-size:2rem;margin-bottom:10px;display:block"></i>لا توجد وسائل دفع</div>
<?php else: foreach($payMethods as $m): ?>
<div class="sec-card" style="border-color:<?=$m['is_active']?'rgba(232,164,0,.2)':'var(--b1)'?>;margin-bottom:10px">
  <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <div style="width:36px;height:36px;border-radius:var(--r3);background:<?=$m['is_active']?'rgba(232,164,0,.1)':'var(--bg3)'?>;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas <?=e($m['icon']??'fa-coins')?>" style="color:<?=$m['is_active']?'var(--gold)':'var(--t3)'?>"></i>
    </div>
    <div style="flex:1;min-width:120px">
      <div style="font-weight:800"><?=e($m['name'])?></div>
      <div style="font-size:.7rem;color:var(--t3)"><?=e($m['type']??'both')?> · $<?=e($m['fee_fixed']??0)?> + <?=e($m['fee_percent']??$m['fee_pct']??0)?>% · حد: $<?=e($m['min_amount']??0)?>–$<?=e($m['max_amount']??0)?></div>
    </div>
    <?=$m['is_active']?'<span class="badge badge-green">نشط</span>':'<span class="badge badge-gray">معطل</span>'?>
    <button type="button" onclick="togglePayEdit(<?=$m['id']?>)" class="btn btn-ghost btn-sm"><i class="fas fa-edit"></i></button>
    <form method="POST" style="display:inline" onsubmit="return confirm('حذف الوسيلة نهائياً؟')">
      <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete_payment_method"><input type="hidden" name="mid" value="<?=$m['id']?>">
      <button type="submit" class="btn btn-sm" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-trash"></i></button>
    </form>
  </div>
  <div id="payEdit_<?=$m['id']?>" style="display:none;margin-top:14px;border-top:1px solid var(--b1);padding-top:14px">
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="edit_payment_method"><input type="hidden" name="mid" value="<?=$m['id']?>">
      <div class="col-grid">
        <div class="fg"><label>الاسم</label><input type="text" name="m_name" class="fi" value="<?=e($m['name'])?>"></div>
        <div class="fg"><label>الوصف</label><input type="text" name="m_desc" class="fi" value="<?=e($m['description']??'')?>"></div>
        <div class="fg"><label>العنوان/المحفظة</label><input type="text" name="m_address" class="fi" value="<?=e($m['wallet_address']??'')?>"></div>
        <div class="fg"><label>الأيقونة</label><input type="text" name="m_icon" class="fi" value="<?=e($m['icon']??'fa-coins')?>"></div>
        <div class="fg"><label>رسوم ثابتة ($)</label><input type="number" name="m_fee" class="fi" step="0.01" min="0" value="<?=e($m['fee_fixed']??0)?>"></div>
        <div class="fg"><label>رسوم نسبية (%)</label><input type="number" name="m_fee_pct" class="fi" step="0.1" min="0" value="<?=e($m['fee_percent']??0)?>"></div>
        <div class="fg"><label>أدنى ($)</label><input type="number" name="m_min" class="fi" step="0.01" value="<?=e($m['min_amount']??0)?>"></div>
        <div class="fg"><label>أقصى ($)</label><input type="number" name="m_max" class="fi" step="0.01" value="<?=e($m['max_amount']??50000)?>"></div>
        <div class="fg"><label>الحالة</label>
          <select name="m_active" class="fsel">
            <option value="1" <?=$m['is_active']?'selected':''?>>نشط</option>
            <option value="0" <?=!$m['is_active']?'selected':''?>>معطل</option>
          </select>
        </div>
      </div>
      <div class="fg"><label>تعليمات للمستخدم</label><textarea name="m_instructions" class="fta" rows="2"><?=e($m['instructions']??'')?></textarea></div>
      <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-save"></i> حفظ</button>
    </form>
  </div>
</div>
<?php endforeach; endif; ?>

<?php elseif($tab==='phones'): ?>
<!-- ══ PHONE WHITELIST ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-shield-alt"></i> القائمة البيضاء للهواتف</div>
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
    <div>
      <div style="font-weight:700;margin-bottom:4px">
        الحالة: <?=gs('phone_whitelist_enabled','0')==='1'?'<span class="badge badge-green">مفعّلة ✅</span>':'<span class="badge badge-gray">معطلة</span>'?>
      </div>
      <div style="font-size:.78rem;color:var(--t3)">عند التفعيل: يُسمح بالتسجيل فقط للأرقام المُدرجة في القائمة</div>
    </div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="toggle_phone_whitelist">
      <button type="submit" class="btn <?=gs('phone_whitelist_enabled','0')==='1'?'btn-red':'btn-green'?> btn-sm">
        <i class="fas fa-toggle-<?=gs('phone_whitelist_enabled','0')==='1'?'off':'on'?>"></i>
        <?=gs('phone_whitelist_enabled','0')==='1'?'تعطيل القائمة':'تفعيل القائمة'?>
      </button>
    </form>
  </div>
</div>

<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-plus"></i> إضافة رقم هاتف</div>
  <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="add_phone">
    <div class="fg" style="flex:1;min-width:150px;margin-bottom:0"><label>رقم الهاتف</label><input type="text" name="phone" class="fi" placeholder="+966XXXXXXXXX" required></div>
    <div class="fg" style="flex:2;min-width:200px;margin-bottom:0"><label>ملاحظة (اختياري)</label><input type="text" name="phone_note" class="fi" placeholder="اسم صاحب الرقم..."></div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-plus"></i> إضافة</button>
  </form>
</div>

<div class="data-table-wrap">
  <div class="data-table-head" style="padding:12px 16px;display:flex;align-items:center;justify-content:space-between">
    <div style="font-weight:700;font-size:.85rem"><i class="fas fa-list" style="color:var(--gold);margin-left:6px"></i> الأرقام المُدرجة (<?=count($phoneList)?>)</div>
  </div>
  <?php if(empty($phoneList)): ?>
  <div style="text-align:center;padding:30px;color:var(--t3)"><i class="fas fa-phone-slash" style="font-size:1.5rem;margin-bottom:8px;display:block"></i>القائمة فارغة</div>
  <?php else: ?>
  <div style="overflow-x:auto"><table>
    <thead><tr><th>#</th><th>الرقم</th><th>الملاحظة</th><th>التاريخ</th><th>حذف</th></tr></thead>
    <tbody>
    <?php foreach($phoneList as $ph): ?>
    <tr>
      <td class="mono txt2" style="font-size:.7rem"><?=$ph['id']?></td>
      <td class="mono" style="font-weight:700;direction:ltr"><?=e($ph['phone'])?></td>
      <td style="font-size:.8rem;color:var(--t2)"><?=e($ph['note']??'—')?></td>
      <td style="font-size:.72rem;color:var(--t3)"><?=timeAgo($ph['created_at'])?></td>
      <td>
        <form method="POST" style="display:inline" onsubmit="return confirm('حذف الرقم؟')">
          <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="delete_phone"><input type="hidden" name="pid" value="<?=$ph['id']?>">
          <button type="submit" class="btn btn-xs" style="background:rgba(255,71,87,.1);color:var(--red);border:1px solid rgba(255,71,87,.2)"><i class="fas fa-trash"></i></button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>

<?php elseif($tab==='account'): ?>
<!-- ══ ACCOUNT ══ -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-user-shield"></i> معلومات حساب الأدمن</div>
  <div style="background:var(--bg2);border-radius:var(--r2);padding:16px;max-width:420px">
    <div style="display:flex;flex-direction:column;gap:12px;font-size:.85rem">
      <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">اسم المستخدم</span><strong><?=e($adminUser['username']??'—')?></strong></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">الإيميل</span><span><?=e($adminUser['email']??'—')?></span></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">رصيد الأدمن</span><span class="mono" style="color:var(--gold)"><?=money((float)($adminUser['balance']??0))?></span></div>
      <div style="display:flex;justify-content:space-between"><span style="color:var(--t2)">انضم في</span><span><?=e(date('Y-m-d',strtotime($adminUser['created_at']??'now')))?></span></div>
    </div>
  </div>
</div>

<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-lock"></i> تغيير كلمة المرور</div>
  <form method="POST" style="max-width:420px">
    <input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="act" value="change_password">
    <div class="fg"><label>كلمة المرور الحالية</label><input type="password" name="current_password" class="fi" required></div>
    <div class="fg"><label>كلمة المرور الجديدة</label><input type="password" name="new_password" class="fi" minlength="6" required></div>
    <div class="fg"><label>تأكيد كلمة المرور</label><input type="password" name="confirm_password" class="fi" required></div>
    <button type="submit" class="btn btn-gold"><i class="fas fa-key"></i> تغيير كلمة المرور</button>
  </form>
</div>
<?php endif; ?>

<script>
function togglePayEdit(id){
  var el=document.getElementById('payEdit_'+id);
  el.style.display=el.style.display==='none'?'block':'none';
}
</script>
<?php adminFoot(); ?>
