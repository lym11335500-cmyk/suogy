<?php
require_once 'admin_check.php';

$msg=''; $msgType='ok';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    $rid=(int)($_POST['rid']??0); $act=$_POST['act']??'';
    if($rid && in_array($act,['approve','reject'])){
        $req=$pdo->prepare("SELECT * FROM payment_requests WHERE id=? AND type='deposit' LIMIT 1");
        $req->execute([$rid]); $req=$req->fetch();
        if($req && $req['status']==='pending'){
            if($act==='approve'){
                $pdo->prepare("UPDATE payment_requests SET status='approved',processed_at=NOW() WHERE id=?")->execute([$rid]);
                $user=$pdo->query("SELECT balance FROM users WHERE id={$req['user_id']}")->fetch();
                $newBal = $user['balance'] + (float)$req['net_amount'];
                $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$newBal,$req['user_id']]);
                addTx($pdo,(int)$req['user_id'],'deposit',(float)$req['net_amount'],$user['balance'],$newBal,$rid,'إيداع مقبول');
                addNotif($pdo,(int)$req['user_id'],'deposit_ok','✅ تمت الموافقة على طلب إيداعك: '.money((float)$req['net_amount']),'wallet.php');
                $msg='تمت الموافقة على الإيداع وإضافة المبلغ لرصيد المستخدم.';
            } else {
                $note = trim($_POST['note']??'');
                $pdo->prepare("UPDATE payment_requests SET status='rejected',admin_note=?,processed_at=NOW() WHERE id=?")->execute([$note,$rid]);
                addNotif($pdo,(int)$req['user_id'],'deposit_rejected','❌ تم رفض طلب إيداعك'.($note?': '.$note:''),'wallet.php');
                $msg='تم رفض الطلب وإشعار المستخدم.'; $msgType='err';
            }
        }
    }
}

$filter=$_GET['f']??'pending';
$safeFilter = in_array($filter,['pending','approved','rejected'])?$filter:'pending';
$reqs=$pdo->query("SELECT r.*,u.username,u.email,m.name method_name FROM payment_requests r
    JOIN users u ON r.user_id=u.id
    LEFT JOIN payment_methods m ON r.method_id=m.id
    WHERE r.type='deposit' AND r.status='$safeFilter'
    ORDER BY r.created_at DESC LIMIT 100")->fetchAll();

$pending=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='pending'")->fetchColumn();
$approved=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='approved'")->fetchColumn();
$totalDeposited=(float)$pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM payment_requests WHERE type='deposit' AND status='approved'")->fetchColumn();
$rejected=(int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='rejected'")->fetchColumn();

adminHead('طلبات الإيداع','deposits');
adminTopbar('طلبات الإيداع 💰', $pending>0?"$pending طلب ينتظر الموافقة":'');
?>

<?php if($msg):?><div class="alert alert-<?=$msgType?>"><i class="fas fa-<?=$msgType==='ok'?'check-circle':'times-circle'?>"></i><span><?=e($msg)?></span></div><?php endif;?>

<!-- Stats Row -->
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card"><div class="stat-card-icon gold"><i class="fas fa-clock"></i></div><div><div class="stat-card-val"><?=$pending?></div><div class="stat-card-lbl">في الانتظار</div></div></div>
  <div class="stat-card"><div class="stat-card-icon green"><i class="fas fa-check-double"></i></div><div><div class="stat-card-val"><?=$approved?></div><div class="stat-card-lbl">مقبول</div></div></div>
  <div class="stat-card"><div class="stat-card-icon blue"><i class="fas fa-dollar-sign"></i></div><div><div class="stat-card-val"><?=money($totalDeposited)?></div><div class="stat-card-lbl">إجمالي المودع</div></div></div>
  <div class="stat-card"><div class="stat-card-icon red"><i class="fas fa-times"></i></div><div><div class="stat-card-val"><?=$rejected?></div><div class="stat-card-lbl">مرفوض</div></div></div>
</div>

<!-- Filter Tabs -->
<div class="ftabs" style="margin-bottom:20px">
  <a href="?f=pending" class="ftab <?=$safeFilter==='pending'?'active':''?>">انتظار <span class="cnt"><?=$pending?></span></a>
  <a href="?f=approved" class="ftab <?=$safeFilter==='approved'?'active':''?>">مقبول <span class="cnt"><?=$approved?></span></a>
  <a href="?f=rejected" class="ftab <?=$safeFilter==='rejected'?'active':''?>">مرفوض <span class="cnt"><?=$rejected?></span></a>
</div>

<div class="data-table-wrap">
  <?php if(empty($reqs)): ?>
  <div style="text-align:center;padding:40px;color:var(--txt3)">
    <i class="fas fa-inbox" style="font-size:2rem;margin-bottom:10px;display:block"></i>
    لا توجد طلبات <?=$safeFilter==='pending'?'معلقة':($safeFilter==='approved'?'مقبولة':'مرفوضة')?>
  </div>
  <?php else: ?>
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr><th>#</th><th>المستخدم</th><th>الوسيلة</th><th>المبلغ</th><th>الرسوم</th><th>الصافي</th><th>التاريخ</th><?php if($safeFilter==='pending'):?><th>إجراء</th><?php endif;?></tr>
      </thead>
      <tbody>
      <?php foreach($reqs as $r): ?>
        <tr>
          <td class="mono txt2" style="font-size:.72rem"><?=$r['id']?></td>
          <td>
            <div style="font-weight:700;font-size:.83rem"><?=e($r['username'])?></div>
            <div style="font-size:.7rem;color:var(--txt3)"><?=e($r['email'])?></div>
          </td>
          <td><span style="font-size:.8rem"><?=e($r['method_name']??'—')?></span></td>
          <td class="mono gold"><?=money((float)$r['amount'])?></td>
          <td class="mono" style="color:var(--red);font-size:.8rem"><?=money((float)$r['fee'])?></td>
          <td class="mono green"><?=money((float)$r['net_amount'])?></td>
          <td style="font-size:.75rem;color:var(--txt2)"><?=timeAgo($r['created_at'])?></td>
          <?php if($safeFilter==='pending'): ?>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <?php if($r['proof_image']): ?>
              <a href="<?=e($r['proof_image'])?>" target="_blank" class="btn btn-ghost btn-sm" title="إثبات الدفع"><i class="fas fa-image"></i></a>
              <?php endif; ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="_csrf" value="<?=csrf()?>">
                <input type="hidden" name="rid" value="<?=$r['id']?>">
                <input type="hidden" name="act" value="approve">
                <button type="submit" class="btn btn-green btn-sm" onclick="return confirm('موافقة على الإيداع؟')">
                  <i class="fas fa-check"></i> قبول
                </button>
              </form>
              <form method="POST" style="display:inline" onsubmit="var n=prompt('سبب الرفض (اختياري):');if(n===null)return false;this.querySelector('[name=note]').value=n;return true;">
                <input type="hidden" name="_csrf" value="<?=csrf()?>">
                <input type="hidden" name="rid" value="<?=$r['id']?>">
                <input type="hidden" name="act" value="reject">
                <input type="hidden" name="note" value="">
                <button type="submit" class="btn btn-red btn-sm">
                  <i class="fas fa-times"></i> رفض
                </button>
              </form>
            </div>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php adminFoot(); ?>
