<?php
require_once 'admin_check.php';

// ═══════════════════════════════════════════════════════════════
//  دالة أرشفة المستخدم بعد الموافقة على التوثيق
// ═══════════════════════════════════════════════════════════════
function archiveApprovedUser(PDO $pdo, array $k): void {
    $uid       = (int)$k['user_id'];
    $archBase  = dirname(__DIR__) . '/private_secure_archive';
    $userDir   = $archBase . '/user_' . $uid;

    if (!is_dir($archBase)) mkdir($archBase, 0700, true);
    if (!is_dir($userDir))  mkdir($userDir,  0700, true);

    // نقل صور التوثيق
    $siteRoot = dirname(__DIR__);
    foreach (['id_card_image' => 'id_card.jpg', 'selfie_image' => 'selfie.jpg'] as $col => $dest) {
        if (!empty($k[$col])) {
            $src = $siteRoot . '/' . ltrim($k[$col], '/');
            if (file_exists($src)) {
                copy($src, $userDir . '/' . $dest);
            }
        }
    }

    // نسخ صورة الملف الشخصي
    if (!empty($k['profile_pic'])) {
        $src = $siteRoot . '/' . ltrim($k['profile_pic'], '/');
        if (file_exists($src)) copy($src, $userDir . '/profile_photo.jpg');
    }

    // جلب سجل الإيداعات
    $deposits = [];
    try {
        $depStmt = $pdo->prepare("
            SELECT pr.created_at as date, pr.amount, pm.name as method,
                   pr.user_account as transaction_id, pr.status
            FROM payment_requests pr
            LEFT JOIN payment_methods pm ON pr.method_id = pm.id
            WHERE pr.user_id = ? AND pr.type = 'deposit' AND pr.status = 'approved'
            ORDER BY pr.created_at DESC
        ");
        $depStmt->execute([$uid]);
        $rows = $depStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $deposits[] = [
                'date'           => date('Y-m-d', strtotime($r['date'])),
                'amount'         => (float)$r['amount'],
                'method'         => $r['method'] ?? '—',
                'transaction_id' => $r['transaction_id'] ?? '—',
            ];
        }
    } catch (Exception $e) {}

    // إنشاء ملف user_data.json
    $userData = [
        'user_id'           => $uid,
        'username'          => $k['username'] ?? '',
        'full_name'         => $k['full_name'] ?? '',
        'phone'             => ($k['phone_country_code'] ?? '') . ($k['phone'] ?? ''),
        'email'             => $k['email'] ?? '',
        'national_id'       => $k['id_number'] ?? '',
        'date_of_birth'     => $k['date_of_birth'] ?? '',
        'address'           => $k['address'] ?? '',
        'verification_date' => date('Y-m-d'),
        'verification_status' => 'موثق ✅',
        'deposits'          => $deposits,
        'notes'             => $k['admin_notes'] ?? '',
    ];
    file_put_contents(
        $userDir . '/user_data.json',
        json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
}

// ═══════════════════════════════════════════════════════════════

$msg = '';

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act  = $_POST['act'] ?? '';
    $kid  = (int)($_POST['kid'] ?? 0);
    $note = trim($_POST['admin_notes'] ?? '');

    if ($act === 'approve' && $kid) {
        $k = $pdo->query("SELECT k.*, u.username, u.email, u.phone, u.phone_country_code, u.profile_pic
                          FROM kyc_documents k JOIN users u ON k.user_id=u.id
                          WHERE k.id=$kid")->fetch();
        if ($k) {
            $pdo->prepare("UPDATE kyc_documents SET status='approved',admin_notes=?,reviewed_at=NOW() WHERE id=?")->execute([$note,$kid]);
            $pdo->prepare("UPDATE users SET kyc_status='approved' WHERE id=?")->execute([$k['user_id']]);
            addActivityLog($pdo,'kyc','موافقة على توثيق KYC للمستخدم ID: '.$k['user_id'],uid(),'admin');
            addNotif($pdo,$k['user_id'],'kyc','✅ تم قبول توثيق هويتك! يمكنك الآن البيع والشراء.','profile.php');
            archiveApprovedUser($pdo, $k);
            $msg = '✅ تم قبول التوثيق وحفظ ملف المستخدم في الأرشيف السري.';
        }
    } elseif ($act === 'reject' && $kid) {
        $k = $pdo->query("SELECT user_id FROM kyc_documents WHERE id=$kid")->fetch();
        if ($k) {
            $pdo->prepare("UPDATE kyc_documents SET status='rejected',admin_notes=?,reviewed_at=NOW() WHERE id=?")->execute([$note,$kid]);
            $pdo->prepare("UPDATE users SET kyc_status='rejected' WHERE id=?")->execute([$k['user_id']]);
            addNotif($pdo,$k['user_id'],'kyc','❌ تم رفض توثيق هويتك. السبب: '.$note,'kyc.php');
            $msg = 'تم رفض التوثيق.';
        }
    }
}
$filter = $_GET['f'] ?? 'pending';
$page   = max(1,(int)($_GET['p']??1));
$perPage = 15;
$offset  = ($page-1)*$perPage;

$where = "WHERE 1=1";
$params = [];
if ($filter !== 'all') { $where .= " AND k.status=?"; $params[] = $filter; }

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM kyc_documents k JOIN users u ON k.user_id=u.id $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1,ceil($total/$perPage));

$stmt = $pdo->prepare("SELECT k.*,u.username,u.email FROM kyc_documents k
    JOIN users u ON k.user_id=u.id $where ORDER BY k.submitted_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$docs = $stmt->fetchAll();

// Counts
$pendingCount = (int)$pdo->query("SELECT COUNT(*) FROM kyc_documents WHERE status='pending'")->fetchColumn();

adminHead('التحقق KYC', 'kyc.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      التحقق KYC
      <?php if ($pendingCount > 0): ?>
      <span class="badge badge-err" style="vertical-align:middle;margin-right:8px"><?=$pendingCount?> معلق</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?=e($msg)?></span></div><?php endif; ?>

<div style="display:flex;gap:8px;margin-bottom:16px">
  <?php foreach (['pending'=>'معلق','approved'=>'مقبول','rejected'=>'مرفوض','all'=>'الكل'] as $k=>$v): ?>
  <a href="?f=<?=$k?>" class="btn btn-sm <?=$filter===$k?'btn-gold':'btn-ghost'?>" style="font-size:.75rem"><?=$v?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($docs)): ?>
<div class="sec-card" style="text-align:center;padding:40px">
  <i class="fas fa-check-circle" style="font-size:2.5rem;color:var(--green);display:block;margin-bottom:12px"></i>
  <div style="font-size:.9rem;font-weight:700;color:var(--txt2)">لا توجد طلبات <?=$filter==='pending'?'معلقة':''?></div>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:12px">
  <?php foreach ($docs as $k): ?>
  <div class="sec-card" style="margin-bottom:0">
    <div style="display:flex;align-items:flex-start;gap:16px;flex-wrap:wrap">
      <!-- User Info -->
      <div style="flex:1;min-width:200px">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <div class="user-av" style="width:42px;height:42px;font-size:1rem">
            <?=strtoupper(mb_substr($k['username'],0,1,'UTF-8'))?>
          </div>
          <div>
            <div style="font-weight:700"><?=e($k['username'])?></div>
            <div style="font-size:.72rem;color:var(--txt2)"><?=e($k['email'])?></div>
          </div>
          <span class="tag tag-<?=$k['status']?>" style="margin-right:auto"><?=statusLabel($k['status'])?></span>
        </div>
        <div style="background:var(--bg2);border-radius:var(--r2);padding:12px;font-size:.8rem">
          <div style="display:flex;flex-direction:column;gap:7px">
            <div style="display:flex;justify-content:space-between"><span class="txt2">الاسم الكامل:</span><strong><?=e($k['full_name']??'—')?></strong></div>
            <div style="display:flex;justify-content:space-between"><span class="txt2">رقم الهوية:</span><span class="mono"><?=e($k['id_number']??'—')?></span></div>
            <div style="display:flex;justify-content:space-between"><span class="txt2">تاريخ الميلاد:</span><span><?=e($k['date_of_birth']??'—')?></span></div>
            <div style="display:flex;justify-content:space-between"><span class="txt2">العنوان:</span><span><?=e($k['address']??'—')?></span></div>
            <div style="display:flex;justify-content:space-between"><span class="txt2">تاريخ التقديم:</span><span><?=e(date('Y-m-d H:i',strtotime($k['submitted_at'])))?></span></div>
            <?php if ($k['admin_notes']): ?>
            <div style="margin-top:4px;padding-top:8px;border-top:1px solid var(--border)">
              <span class="txt2">ملاحظة الأدمن:</span><br>
              <span style="color:var(--txt)"><?=e($k['admin_notes'])?></span>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Documents -->
      <div style="display:flex;gap:10px;flex-shrink:0">
        <?php if ($k['id_card_image']): ?>
        <div>
          <div style="font-size:.68rem;color:var(--txt3);margin-bottom:4px;text-align:center">بطاقة الهوية</div>
          <a href="../<?=e($k['id_card_image'])?>" target="_blank">
            <img src="../<?=e($k['id_card_image'])?>" alt="ID Card"
              style="width:120px;height:80px;object-fit:cover;border-radius:var(--r3);border:1px solid var(--border2);transition:all .2s"
              onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
          </a>
        </div>
        <?php endif; ?>
        <?php if ($k['selfie_image']): ?>
        <div>
          <div style="font-size:.68px;color:var(--txt3);margin-bottom:4px;text-align:center;font-size:.68rem">سيلفي</div>
          <a href="../<?=e($k['selfie_image'])?>" target="_blank">
            <img src="../<?=e($k['selfie_image'])?>" alt="Selfie"
              style="width:120px;height:80px;object-fit:cover;border-radius:var(--r3);border:1px solid var(--border2);transition:all .2s"
              onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
          </a>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Action Buttons -->
    <?php if ($k['status'] === 'pending'): ?>
    <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border)">
      <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="kid" value="<?=$k['id']?>">
        <div style="flex:1;min-width:200px">
          <label style="font-size:.72rem;color:var(--txt2);display:block;margin-bottom:4px">ملاحظة (اختياري)</label>
          <input type="text" name="admin_notes" class="fi" placeholder="سبب القبول أو الرفض..." style="padding:9px 12px">
        </div>
        <button type="submit" name="act" value="approve" class="btn btn-green"
          onclick="return confirm('قبول هذا التوثيق؟')">
          <i class="fas fa-check-circle"></i> قبول
        </button>
        <button type="submit" name="act" value="reject" class="btn btn-red"
          onclick="return confirm('رفض هذا التوثيق؟')">
          <i class="fas fa-times-circle"></i> رفض
        </button>
      </form>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($pages > 1): ?>
<div class="pagination" style="margin-top:16px">
  <?php for ($i=1; $i<=min($pages,10); $i++): ?>
  <a href="?f=<?=e($filter)?>&p=<?=$i?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<?php adminFoot(); ?>
