<?php
require_once 'admin_check.php';

// ═══════════════════════════════════════════════════════════════
//  الأرشيف السري للموثقين — وصول الأدمن فقط
// ═══════════════════════════════════════════════════════════════

$archiveBase = dirname(__DIR__) . '/private_secure_archive';

// ── تحديد مجلد الأرشيف النسبي لاستخدامه في التحميل
define('ARCHIVE_BASE', $archiveBase);

// ── معالجة طلب التحميل
$dl = $_GET['dl'] ?? '';
$dlAll = isset($_GET['dl_all']);

if ($dlAll) {
    // تحميل الأرشيف الكامل
    if (!is_dir(ARCHIVE_BASE)) { header('Location: archive.php'); exit; }
    $dirs = glob(ARCHIVE_BASE . '/user_*', GLOB_ONLYDIR);
    if (empty($dirs)) { header('Location: archive.php'); exit; }

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="full_archive_' . date('Y-m-d') . '.zip"');
    header('Cache-Control: no-cache');

    $zip = new ZipArchive();
    $tmpZip = sys_get_temp_dir() . '/archive_full_' . time() . '.zip';
    $zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    foreach ($dirs as $dir) {
        $uname = basename($dir);
        $files = scandir($dir);
        foreach ($files as $f) {
            if ($f === '.' || $f === '..') continue;
            $zip->addFile($dir . '/' . $f, $uname . '/' . $f);
        }
    }
    $zip->close();
    readfile($tmpZip);
    unlink($tmpZip);
    exit;
}

if ($dl && preg_match('/^user_\d+$/', $dl)) {
    // تحميل مجلد مستخدم واحد
    $userDir = ARCHIVE_BASE . '/' . $dl;
    if (!is_dir($userDir)) { header('Location: archive.php'); exit; }

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $dl . '_' . date('Y-m-d') . '.zip"');
    header('Cache-Control: no-cache');

    $zip = new ZipArchive();
    $tmpZip = sys_get_temp_dir() . '/' . $dl . '_' . time() . '.zip';
    $zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    $files = scandir($userDir);
    foreach ($files as $f) {
        if ($f === '.' || $f === '..') continue;
        $zip->addFile($userDir . '/' . $f, $f);
    }
    $zip->close();
    readfile($tmpZip);
    unlink($tmpZip);
    exit;
}

// ── عرض صورة آمنة (بدون كشف المسار)
$viewImg = $_GET['img'] ?? '';
if ($viewImg && preg_match('/^user_\d+\/[a-zA-Z0-9_\-\.]+\.(jpg|jpeg|png|gif|webp)$/i', $viewImg)) {
    $imgPath = ARCHIVE_BASE . '/' . $viewImg;
    if (file_exists($imgPath)) {
        $ext = strtolower(pathinfo($imgPath, PATHINFO_EXTENSION));
        $mime = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp'][$ext] ?? 'image/jpeg';
        header('Content-Type: ' . $mime);
        header('Cache-Control: no-store');
        readfile($imgPath);
        exit;
    }
}

// ── قراءة محتويات الأرشيف
$users = [];
if (is_dir(ARCHIVE_BASE)) {
    $dirs = glob(ARCHIVE_BASE . '/user_*', GLOB_ONLYDIR);
    if ($dirs) {
        foreach ($dirs as $dir) {
            $uid = str_replace('user_', '', basename($dir));
            $jsonFile = $dir . '/user_data.json';
            $data = [];
            if (file_exists($jsonFile)) {
                $data = json_decode(file_get_contents($jsonFile), true) ?? [];
            }
            // جلب اسم المستخدم من الداتابيز
            try {
                $uRow = $pdo->query("SELECT username, email FROM users WHERE id=" . (int)$uid)->fetch();
            } catch (Exception $e) { $uRow = null; }

            $files = array_filter(scandir($dir), fn($f) => $f !== '.' && $f !== '..' && $f !== 'user_data.json');
            $imgFiles = array_values(array_filter($files, fn($f) => preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f)));
            $archiveTime = filemtime($dir);

            $users[] = [
                'uid'      => $uid,
                'folder'   => basename($dir),
                'username' => $uRow['username'] ?? '—',
                'email'    => $uRow['email'] ?? '—',
                'data'     => $data,
                'images'   => $imgFiles,
                'archived_at' => date('Y-m-d H:i', $archiveTime),
                'files_count' => count($files),
            ];
        }
        // ترتيب الأحدث أولاً
        usort($users, fn($a,$b) => strcmp($b['archived_at'], $a['archived_at']));
    }
}

$totalUsers = count($users);
$archiveExists = is_dir(ARCHIVE_BASE);

adminHead('الأرشيف السري', 'archive.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      🔒 الأرشيف السري للموثقين
      <small>وصول الأدمن فقط — <?= $totalUsers ?> مستخدم موثق مؤرشف</small>
    </div>
  </div>
  <?php if ($totalUsers > 0): ?>
  <a href="?dl_all=1" class="btn btn-gold btn-sm" onclick="return confirm('تحميل الأرشيف الكامل (<?= $totalUsers ?> مستخدم)؟')">
    <i class="fas fa-download"></i> تحميل الكل ZIP
  </a>
  <?php endif; ?>
</div>

<!-- ستاتس -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:22px">
  <div class="sec-card" style="text-align:center;padding:20px;margin:0">
    <div style="font-size:2rem;font-weight:900;color:var(--gold)"><?= $totalUsers ?></div>
    <div style="font-size:.75rem;color:var(--t2);margin-top:4px">مستخدم مؤرشف</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:20px;margin:0">
    <?php
    $totalFiles = array_sum(array_column($users, 'files_count'));
    ?>
    <div style="font-size:2rem;font-weight:900;color:var(--blue)"><?= $totalFiles ?></div>
    <div style="font-size:.75rem;color:var(--t2);margin-top:4px">إجمالي الملفات</div>
  </div>
  <div class="sec-card" style="text-align:center;padding:20px;margin:0">
    <?php
    $size = 0;
    if (is_dir(ARCHIVE_BASE)) {
        $iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(ARCHIVE_BASE, FilesystemIterator::SKIP_DOTS));
        foreach ($iter as $f) $size += $f->getSize();
    }
    $sizeStr = $size > 1048576 ? round($size/1048576,1).' MB' : round($size/1024,1).' KB';
    ?>
    <div style="font-size:2rem;font-weight:900;color:var(--green)"><?= $sizeStr ?></div>
    <div style="font-size:.75rem;color:var(--t2);margin-top:4px">حجم الأرشيف</div>
  </div>
</div>

<?php if (empty($users)): ?>
<div class="sec-card" style="text-align:center;padding:60px 20px">
  <i class="fas fa-lock" style="font-size:3rem;color:var(--t3);display:block;margin-bottom:16px;opacity:.4"></i>
  <div style="font-size:.95rem;font-weight:700;color:var(--t2)">الأرشيف فارغ حتى الآن</div>
  <div style="font-size:.78rem;color:var(--t3);margin-top:6px">سيظهر المستخدمون هنا تلقائياً بعد الموافقة على توثيقهم</div>
</div>
<?php else: ?>

<!-- قائمة المستخدمين -->
<div style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($users as $u): ?>
  <div class="sec-card" style="margin:0;overflow:hidden">

    <!-- هيدر المستخدم -->
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--b1)">
      <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold3));display:flex;align-items:center;justify-content:center;font-weight:900;font-size:1.1rem;color:#060810;flex-shrink:0">
        <?= strtoupper(mb_substr($u['username'], 0, 1, 'UTF-8')) ?>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:900;font-size:.95rem"><?= e($u['username']) ?></div>
        <div style="font-size:.72rem;color:var(--t2)"><?= e($u['email']) ?></div>
        <div style="font-size:.68rem;color:var(--t3);margin-top:2px">
          <i class="fas fa-archive" style="color:var(--gold)"></i> مؤرشف <?= $u['archived_at'] ?>
          &nbsp;·&nbsp; <?= $u['files_count'] ?> ملف
        </div>
      </div>
      <a href="?dl=<?= e($u['folder']) ?>" class="btn btn-sm btn-outline" style="flex-shrink:0;color:var(--gold);border-color:var(--gold3)">
        <i class="fas fa-download"></i> تحميل ZIP
      </a>
    </div>

    <!-- معلومات المستخدم من JSON -->
    <?php if (!empty($u['data'])): $d = $u['data']; ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      <?php $fields = [
        'full_name'          => ['fas fa-user','الاسم الكامل'],
        'phone'              => ['fas fa-phone','رقم الهاتف'],
        'national_id'        => ['fas fa-id-card','رقم الهوية'],
        'date_of_birth'      => ['fas fa-calendar','تاريخ الميلاد'],
        'address'            => ['fas fa-map-marker-alt','العنوان'],
        'verification_date'  => ['fas fa-check-circle','تاريخ التوثيق'],
      ];
      foreach ($fields as $key => [$icon, $label]):
        if (empty($d[$key])) continue; ?>
      <div style="background:var(--bg3);border-radius:var(--r3);padding:10px 12px">
        <div style="font-size:.65rem;color:var(--t3);margin-bottom:3px"><i class="<?= $icon ?>" style="margin-left:4px"></i><?= $label ?></div>
        <div style="font-size:.82rem;font-weight:700"><?= e($d[$key]) ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- سجل الإيداعات -->
    <?php if (!empty($d['deposits'])): ?>
    <div style="margin-bottom:16px">
      <div style="font-size:.75rem;font-weight:700;color:var(--t2);margin-bottom:8px;display:flex;align-items:center;gap:6px">
        <i class="fas fa-money-bill-wave" style="color:var(--green)"></i> سجل الإيداعات
        <span style="background:rgba(16,217,122,.1);color:var(--green);padding:2px 8px;border-radius:10px;font-size:.65rem"><?= count($d['deposits']) ?></span>
      </div>
      <div style="background:var(--bg2);border-radius:var(--r2);overflow:hidden;border:1px solid var(--b1)">
        <table style="width:100%;border-collapse:collapse;font-size:.78rem">
          <thead>
            <tr style="background:var(--bg3)">
              <th style="padding:8px 12px;text-align:right;font-weight:700;color:var(--t2);font-size:.68rem">التاريخ</th>
              <th style="padding:8px 12px;text-align:right;font-weight:700;color:var(--t2);font-size:.68rem">المبلغ</th>
              <th style="padding:8px 12px;text-align:right;font-weight:700;color:var(--t2);font-size:.68rem">الوسيلة</th>
              <th style="padding:8px 12px;text-align:right;font-weight:700;color:var(--t2);font-size:.68rem">رقم العملية</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($d['deposits'] as $dep): ?>
            <tr style="border-top:1px solid var(--b1)">
              <td style="padding:8px 12px;color:var(--t2)"><?= e($dep['date'] ?? '—') ?></td>
              <td style="padding:8px 12px;color:var(--green);font-weight:700;font-family:'JetBrains Mono',monospace">$<?= number_format($dep['amount'] ?? 0, 2) ?></td>
              <td style="padding:8px 12px"><?= e($dep['method'] ?? '—') ?></td>
              <td style="padding:8px 12px;font-family:'JetBrains Mono',monospace;font-size:.7rem;color:var(--t3)"><?= e($dep['transaction_id'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <!-- الصور -->
    <?php if (!empty($u['images'])): ?>
    <div>
      <div style="font-size:.75rem;font-weight:700;color:var(--t2);margin-bottom:8px"><i class="fas fa-images" style="color:var(--blue);margin-left:5px"></i>صور التوثيق</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <?php foreach ($u['images'] as $img):
          $imgLabel = match(true) {
            str_contains($img,'id_card') || str_contains($img,'id-card') => 'بطاقة الهوية',
            str_contains($img,'selfie') => 'سيلفي',
            str_contains($img,'profile') => 'صورة الملف',
            default => $img
          };
        ?>
        <div style="text-align:center">
          <div style="font-size:.62rem;color:var(--t3);margin-bottom:4px"><?= e($imgLabel) ?></div>
          <a href="?img=<?= e($u['folder']) ?>/<?= e($img) ?>" target="_blank">
            <img src="?img=<?= e($u['folder']) ?>/<?= e($img) ?>" alt="<?= e($imgLabel) ?>"
              style="width:110px;height:75px;object-fit:cover;border-radius:var(--r3);border:1.5px solid var(--b2);transition:all .2s;cursor:zoom-in"
              onmouseover="this.style.transform='scale(1.05)';this.style.borderColor='var(--gold)'"
              onmouseout="this.style.transform='scale(1)';this.style.borderColor='var(--b2)'">
          </a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
  <?php endforeach; ?>
</div>

<?php endif; ?>

<?php adminFoot(); ?>
