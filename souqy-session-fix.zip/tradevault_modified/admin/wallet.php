<?php
require_once 'admin_check.php';

$msg = '';

// Manual transfer to user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    if ($act === 'transfer') {
        $toUser = trim($_POST['to_user'] ?? '');
        $amount = (float)($_POST['amount'] ?? 0);
        $note   = trim($_POST['note'] ?? 'تحويل من الأدمن');

        $user = $pdo->prepare("SELECT id,balance,username FROM users WHERE username=? OR email=? LIMIT 1");
        $user->execute([$toUser, $toUser]);
        $user = $user->fetch();

        if (!$user) {
            $err = 'المستخدم غير موجود.';
        } elseif ($amount <= 0) {
            $err = 'المبلغ يجب أن يكون أكبر من صفر.';
        } else {
            $admin = $pdo->query("SELECT id,balance FROM users WHERE is_admin=1 LIMIT 1")->fetch();
            $newAdminBal = max(0, $admin['balance'] - $amount);
            $newUserBal  = $user['balance'] + $amount;
            $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$newAdminBal, $admin['id']]);
            $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$newUserBal, $user['id']]);
            addTx($pdo,$admin['id'],'admin_debit',$amount,$admin['balance'],$newAdminBal,$user['id'],'تحويل لـ '.$user['username']);
            addTx($pdo,$user['id'],'admin_credit',$amount,$user['balance'],$newUserBal,0,$note);
            addNotif($pdo,$user['id'],'wallet','💰 تم إضافة '.money($amount).' لرصيدك من الأدمن.','wallet.php');
            $msg = 'تم تحويل ' . money($amount) . ' لـ ' . $user['username'];
        }
    }
}

$adminUser = $pdo->query("SELECT id,balance,held_balance FROM users WHERE is_admin=1 LIMIT 1")->fetch();
$adminBalance = (float)($adminUser['balance'] ?? 0);

$totalUserBalances = (float)$pdo->query("SELECT COALESCE(SUM(balance),0) FROM users WHERE is_admin=0")->fetchColumn();
$totalHeld         = (float)$pdo->query("SELECT COALESCE(SUM(held_balance),0) FROM users WHERE is_admin=0")->fetchColumn();
$totalRevenue      = (float)$pdo->query("SELECT COALESCE(SUM(commission),0) FROM purchases WHERE status='completed'")->fetchColumn();
$todayRevenue      = (float)$pdo->query("SELECT COALESCE(SUM(commission),0) FROM purchases WHERE status='completed' AND DATE(completed_at)=CURDATE()")->fetchColumn();

// Recent transactions for admin
$txs = $pdo->query("SELECT t.*,u.username FROM transactions t JOIN users u ON t.user_id=u.id
    WHERE t.user_id=(SELECT id FROM users WHERE is_admin=1 LIMIT 1)
    ORDER BY t.created_at DESC LIMIT 20")->fetchAll();

// All transactions filter
$txFilter = $_GET['txf'] ?? 'all';
$txPage   = max(1,(int)($_GET['p']??1));
$txPerPage = 25;
$txOffset  = ($txPage-1)*$txPerPage;

$txWhere = "WHERE 1=1";
$txParams = [];
if ($txFilter !== 'all') { $txWhere .= " AND t.type=?"; $txParams[] = $txFilter; }

$allTxCount = $pdo->prepare("SELECT COUNT(*) FROM transactions t JOIN users u ON t.user_id=u.id $txWhere");
$allTxCount->execute($txParams);
$allTxTotal = (int)$allTxCount->fetchColumn();
$allTxPages = max(1, ceil($allTxTotal/$txPerPage));

$allTxStmt = $pdo->prepare("SELECT t.*,u.username FROM transactions t JOIN users u ON t.user_id=u.id
    $txWhere ORDER BY t.created_at DESC LIMIT $txPerPage OFFSET $txOffset");
$allTxStmt->execute($txParams);
$allTxs = $allTxStmt->fetchAll();

adminHead('المحفظة والمالية', 'wallet.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      المحفظة والمالية
    </div>
  </div>
</div>

<?php if (!empty($msg)): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?=e($msg)?></span></div><?php endif; ?>
<?php if (!empty($err)): ?><div class="alert alert-err"><i class="fas fa-times-circle"></i><span><?=e($err)?></span></div><?php endif; ?>

<!-- STATS -->
<div class="stats-grid" style="margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-card-icon purple"><i class="fas fa-wallet"></i></div>
    <div>
      <div class="stat-card-val"><?=money($adminBalance)?></div>
      <div class="stat-card-lbl">رصيد المنصة</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon cyan"><i class="fas fa-dollar-sign"></i></div>
    <div>
      <div class="stat-card-val"><?=money($totalRevenue)?></div>
      <div class="stat-card-lbl">إجمالي العمولات</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green"><i class="fas fa-chart-line"></i></div>
    <div>
      <div class="stat-card-val"><?=money($todayRevenue)?></div>
      <div class="stat-card-lbl">عمولات اليوم</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon gold"><i class="fas fa-users"></i></div>
    <div>
      <div class="stat-card-val"><?=money($totalUserBalances)?></div>
      <div class="stat-card-lbl">أرصدة المستخدمين</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon blue"><i class="fas fa-lock"></i></div>
    <div>
      <div class="stat-card-val"><?=money($totalHeld)?></div>
      <div class="stat-card-lbl">مبالغ محجوزة</div>
    </div>
  </div>
</div>

<div class="col-grid">
  <!-- TRANSFER FORM -->
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-paper-plane"></i> تحويل للمستخدم</div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="transfer">
      <div class="fg">
        <label>اسم المستخدم أو الإيميل</label>
        <input type="text" name="to_user" class="fi" placeholder="username أو email" required>
      </div>
      <div class="fg">
        <label>المبلغ ($)</label>
        <input type="number" name="amount" class="fi" min="0.01" step="0.01" placeholder="0.00" required>
      </div>
      <div class="fg">
        <label>ملاحظة</label>
        <input type="text" name="note" class="fi" value="هدية من المنصة" placeholder="سبب التحويل">
      </div>
      <button type="submit" class="btn btn-gold btn-block"
        onclick="return confirm('تأكيد التحويل؟')">
        <i class="fas fa-paper-plane"></i> إرسال
      </button>
    </form>
  </div>

  <!-- ADMIN RECENT TX -->
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-receipt"></i> معاملات المنصة الأخيرة</div>
    <?php if (empty($txs)): ?>
      <div class="empty"><i class="fas fa-receipt"></i><p>لا توجد معاملات</p></div>
    <?php else: foreach ($txs as $t): ?>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-size:.78rem;font-weight:600"><?=e($t['note']??$t['type'])?></div>
          <div style="font-size:.65rem;color:var(--txt3)"><?=timeAgo($t['created_at'])?></div>
        </div>
        <div class="mono <?=$t['amount']>=0?'green':'red'?>" style="font-size:.82rem">
          <?=$t['amount']>=0?'+':''?><?=money((float)$t['amount'])?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<!-- ALL TRANSACTIONS -->
<div class="sec-card" style="margin-top:20px">
  <div class="sec-card-title"><i class="fas fa-list-alt"></i> سجل المعاملات الكاملة</div>
  <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <?php foreach (['all'=>'الكل','commission'=>'عمولات','admin_credit'=>'إيداع أدمن','admin_debit'=>'خصم أدمن','refund'=>'استرداد','release'=>'إفراج'] as $k=>$v): ?>
    <a href="?txf=<?=$k?>" class="btn btn-sm <?=$txFilter===$k?'btn-gold':'btn-ghost'?>" style="font-size:.72rem"><?=$v?></a>
    <?php endforeach; ?>
  </div>
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr><th>#</th><th>المستخدم</th><th>النوع</th><th>المبلغ</th><th>قبل</th><th>بعد</th><th>الملاحظة</th><th>التاريخ</th></tr>
      </thead>
      <tbody>
        <?php if (empty($allTxs)): ?>
        <tr><td colspan="8" style="text-align:center;padding:20px;color:var(--txt3)">لا توجد معاملات</td></tr>
        <?php else: foreach ($allTxs as $t): ?>
        <tr>
          <td class="mono txt2" style="font-size:.7rem"><?=$t['id']?></td>
          <td style="font-size:.8rem"><?=e($t['username'])?></td>
          <td><span class="badge <?=$t['amount']>=0?'badge-ok':'badge-err'?>" style="font-size:.65rem"><?=e($t['type'])?></span></td>
          <td class="mono <?=$t['amount']>=0?'green':'red'?>"><?=$t['amount']>=0?'+':''?><?=money((float)$t['amount'])?></td>
          <td class="mono txt2" style="font-size:.75rem"><?=money((float)$t['balance_before'])?></td>
          <td class="mono" style="font-size:.75rem"><?=money((float)$t['balance_after'])?></td>
          <td class="txt2" style="font-size:.72rem;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($t['note']??'—')?></td>
          <td class="txt2" style="font-size:.7rem"><?=timeAgo($t['created_at'])?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($allTxPages > 1): ?>
  <div class="pagination">
    <?php for ($i=1;$i<=min($allTxPages,10);$i++): ?>
    <a href="?txf=<?=e($txFilter)?>&p=<?=$i?>" class="page-btn <?=$i===$txPage?'active':''?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php adminFoot(); ?>
