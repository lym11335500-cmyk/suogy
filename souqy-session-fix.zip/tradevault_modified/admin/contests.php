<?php
require_once '../includes/db.php';
require_once '../includes/admin_layout.php';
require_once '../includes/referral_helpers.php';
adminCheck();

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';

    if ($act === 'new_contest') {
        $start = $_POST['start_date'] ?? '';
        $end   = $_POST['end_date']   ?? '';
        $title = trim($_POST['title'] ?? 'مسابقة إحالة');
        if ($start && $end && $start <= $end) {
            $pdo->prepare("INSERT INTO contests (title,start_date,end_date,status) VALUES (?,?,?,'active')")
                ->execute([$title, $start, $end]);
            $msg = 'تم إنشاء المسابقة بنجاح!';
        } else $err = 'يُرجى إدخال تواريخ صحيحة';
    }

    if ($act === 'end_contest') {
        $cid = (int)($_POST['contest_id'] ?? 0);
        if ($cid) { calcContestWinners($pdo, $cid); $msg = 'تم إنهاء المسابقة وحساب الفائزين!'; }
    }

    if ($act === 'add_reward') {
        $rid    = (int)($_POST['result_id'] ?? 0);
        $reward = (float)($_POST['reward'] ?? 0);
        $note   = trim($_POST['reward_note'] ?? '');
        if ($rid && $reward > 0) {
            $res = $pdo->prepare("SELECT * FROM contest_results WHERE id=?");
            $res->execute([$rid]);
            $res = $res->fetch();
            if ($res) {
                $pdo->prepare("UPDATE contest_results SET reward=?,reward_note=?,rewarded_at=NOW() WHERE id=?")->execute([$reward,$note,$rid]);
                $pdo->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$reward,$res['user_id']]);
                addNotif($pdo,(int)$res['user_id'],'reward','🎁 تم إضافة مكافأة '.$reward.' لرصيدك من مسابقة الإحالة!');
                $msg = 'تمت إضافة المكافأة!';
            }
        } else $err = 'يُرجى إدخال مبلغ صحيح';
    }

    if ($act === 'cancel_contest') {
        $cid = (int)($_POST['contest_id'] ?? 0);
        $pdo->prepare("UPDATE contests SET status='cancelled' WHERE id=? AND status='active'")->execute([$cid]);
        $msg = 'تم إلغاء المسابقة.';
    }
}

try { $active = getActiveContest($pdo); } catch(Exception $e){ $active = null; }
try { $contests = $pdo->query("SELECT * FROM contests ORDER BY start_date DESC LIMIT 30")->fetchAll(); } catch(Exception $e){ $contests = []; }
$tab = $_GET['tab'] ?? 'active';

try { $totalRefs      = (int)$pdo->query("SELECT COUNT(*) FROM referrals")->fetchColumn(); } catch(Exception $e){ $totalRefs=0; }
try { $totalRefd      = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE referred_by IS NOT NULL")->fetchColumn(); } catch(Exception $e){ $totalRefd=0; }
try { $pendingRewards = (int)$pdo->query("SELECT COUNT(*) FROM contest_results WHERE (reward IS NULL OR reward=0)")->fetchColumn(); } catch(Exception $e){ $pendingRewards=0; }

adminHead('مسابقة الإحالة');
?>
<div style="padding:24px;max-width:1100px">

<?php adminTopbar('مسابقة الإحالة & الإحالات'); ?>

<?php if($msg): ?><div class="alert alert-ok" style="margin-bottom:16px"><i class="fas fa-check-circle"></i> <?=e($msg)?></div><?php endif; ?>
<?php if($err): ?><div class="alert alert-err" style="margin-bottom:16px"><i class="fas fa-times-circle"></i> <?=e($err)?></div><?php endif; ?>

<!-- Stats -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-card-icon gold"><i class="fas fa-users"></i></div>
    <div><div class="stat-card-val"><?=$totalRefs?></div><div class="stat-card-lbl">إجمالي الإحالات</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green"><i class="fas fa-user-check"></i></div>
    <div><div class="stat-card-val"><?=$totalRefd?></div><div class="stat-card-lbl">مستخدمون بإحالة</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon <?=$active?'gold':'red'?>"><i class="fas fa-trophy"></i></div>
    <div><div class="stat-card-val" style="font-size:1.1rem"><?=$active?'نشطة':'لا توجد'?></div><div class="stat-card-lbl">المسابقة الحالية</div></div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon <?=$pendingRewards>0?'red':'green'?>"><i class="fas fa-coins"></i></div>
    <div><div class="stat-card-val"><?=$pendingRewards?></div><div class="stat-card-lbl">مكافآت معلّقة</div></div>
  </div>
</div>

<!-- Tabs -->
<div style="display:flex;gap:6px;margin-bottom:20px;flex-wrap:wrap">
  <?php foreach([
    ['active','المسابقة الحالية','fa-fire'],
    ['new','إنشاء مسابقة','fa-plus'],
    ['history','السجل التاريخي','fa-history'],
    ['leaders','أفضل المحيلين','fa-chart-bar'],
  ] as [$k,$lbl,$ic]): ?>
  <a href="?tab=<?=$k?>" class="btn <?=$tab===$k?'btn-gold':'btn-ghost'?> btn-sm">
    <i class="fas <?=$ic?>"></i> <?=$lbl?>
  </a>
  <?php endforeach; ?>
</div>

<?php if($tab==='active'): ?>
<?php if($active):
  $endTs  = strtotime($active['end_date'].' 23:59:59') * 1000;
  $startTs= strtotime($active['start_date']) * 1000;
  $tot    = $endTs - $startTs;
  $leaders= getContestLeaderboard($pdo,(int)$active['id'],5);
?>
<div class="tbl-wrap">
  <div class="tbl-head">
    <div class="tbl-title"><i class="fas fa-trophy" style="color:#e8a400"></i><?=e($active['title'])?></div>
    <span class="badge badge-green">نشطة</span>
  </div>
  <div style="padding:18px">

    <!-- Countdown -->
    <div style="background:rgba(232,164,0,.06);border:1px solid rgba(232,164,0,.2);border-radius:12px;padding:16px;text-align:center;margin-bottom:18px">
      <div style="font-size:.62rem;color:#e8a400;letter-spacing:2px;font-weight:800;margin-bottom:10px">⏳ الوقت المتبقي لانتهاء المسابقة</div>
      <div style="display:flex;justify-content:center;align-items:center;gap:6px">
        <?php foreach([['acd-d','يوم'],['acd-h','ساعة'],['acd-m','دقيقة'],['acd-s','ثانية']] as $idx=>[$id,$lbl]): ?>
        <?php if($idx>0): ?><div style="font-size:1.4rem;font-weight:900;color:rgba(232,164,0,.3);margin-bottom:14px">:</div><?php endif; ?>
        <div style="background:rgba(0,0,0,.4);border:1px solid rgba(232,164,0,.15);border-radius:10px;padding:9px 12px;min-width:58px;text-align:center">
          <div id="<?=$id?>" style="font-size:1.7rem;font-weight:900;color:#ffcc44;font-family:'JetBrains Mono',monospace;line-height:1">00</div>
          <div style="font-size:.55rem;color:#8b95b5;margin-top:3px"><?=$lbl?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="height:3px;background:rgba(255,255,255,.06);border-radius:4px;margin-top:12px;overflow:hidden">
        <div id="acd-fill" style="height:100%;background:linear-gradient(90deg,#e8a400,#ffcc44);border-radius:4px;transition:width .6s;width:0%"></div>
      </div>
      <div style="font-size:.6rem;color:#8b95b5;margin-top:6px"><?=date('Y/m/d',strtotime($active['start_date']))?> ← <?=date('Y/m/d',strtotime($active['end_date']))?></div>
    </div>
    <script>
    !function(){
      var e=<?=(int)($endTs/1000)?>*1000,s=<?=(int)($startTs/1000)?>*1000,t=e-s;
      function p(n){return String(n).padStart(2,'0')}
      function tick(){
        var d=Math.max(0,e-Date.now());
        document.getElementById('acd-d').textContent=p(Math.floor(d/86400000));
        document.getElementById('acd-h').textContent=p(Math.floor(d%86400000/3600000));
        document.getElementById('acd-m').textContent=p(Math.floor(d%3600000/60000));
        document.getElementById('acd-s').textContent=p(Math.floor(d%60000/1000));
        document.getElementById('acd-fill').style.width=Math.min(100,(Date.now()-s)/t*100).toFixed(1)+'%';
      }
      tick();setInterval(tick,7000);
    }();
    </script>

    <!-- Leaderboard -->
    <div style="font-weight:800;font-size:.82rem;margin-bottom:10px">🏆 المتصدرون حالياً</div>
    <table style="width:100%;border-collapse:collapse">
      <thead><tr style="border-bottom:1px solid rgba(255,255,255,.08)">
        <th style="padding:8px 12px;text-align:right;font-size:.7rem;color:#8b95b5">#</th>
        <th style="padding:8px 12px;text-align:right;font-size:.7rem;color:#8b95b5">المستخدم</th>
        <th style="padding:8px 12px;text-align:right;font-size:.7rem;color:#8b95b5">الإحالات</th>
        <th style="padding:8px 12px;text-align:right;font-size:.7rem;color:#8b95b5">إجراء</th>
      </tr></thead>
      <tbody>
      <?php if(empty($leaders)): ?>
        <tr><td colspan="4" style="padding:20px;text-align:center;color:#8b95b5">لا توجد إحالات بعد</td></tr>
      <?php else: foreach($leaders as $i=>$l): ?>
        <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
          <td style="padding:10px 12px"><span class="badge <?=$i===0?'badge-gold':'badge-gray'?>"><?=$i+1?></span></td>
          <td style="padding:10px 12px;font-weight:700">@<?=e($l['username'])?></td>
          <td style="padding:10px 12px;color:#e8a400;font-weight:900;font-family:'JetBrains Mono',monospace"><?=$l['cnt']?></td>
          <td style="padding:10px 12px"><a href="users.php?id=<?=$l['id']?>" class="btn btn-ghost btn-xs">عرض</a></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>

    <div style="display:flex;gap:8px;margin-top:16px;padding-top:14px;border-top:1px solid rgba(255,255,255,.06)">
      <form method="POST" style="display:inline">
        <?=csrfField()?><input type="hidden" name="act" value="end_contest"><input type="hidden" name="contest_id" value="<?=$active['id']?>">
        <button class="btn btn-gold btn-sm" onclick="return confirm('إنهاء المسابقة الآن وحساب الفائزين؟')"><i class="fas fa-flag-checkered"></i> إنهاء وحساب الفائزين</button>
      </form>
      <form method="POST" style="display:inline">
        <?=csrfField()?><input type="hidden" name="act" value="cancel_contest"><input type="hidden" name="contest_id" value="<?=$active['id']?>">
        <button class="btn btn-outline btn-sm" style="color:#ff4757;border-color:rgba(255,71,87,.3)" onclick="return confirm('إلغاء المسابقة نهائياً؟')"><i class="fas fa-times"></i> إلغاء</button>
      </form>
    </div>
  </div>
</div>

<?php else: ?>
<div class="tbl-wrap"><div style="padding:50px;text-align:center">
  <i class="fas fa-trophy" style="font-size:3rem;color:rgba(255,255,255,.08);display:block;margin-bottom:14px"></i>
  <p style="color:#8b95b5;margin-bottom:18px">لا توجد مسابقة نشطة حالياً</p>
  <a href="?tab=new" class="btn btn-gold"><i class="fas fa-plus"></i> إنشاء مسابقة جديدة</a>
</div></div>
<?php endif; ?>

<?php elseif($tab==='new'): ?>
<div class="tbl-wrap">
  <div class="tbl-head"><div class="tbl-title"><i class="fas fa-plus"></i> إنشاء مسابقة جديدة</div></div>
  <div style="padding:22px;max-width:480px">
    <form method="POST">
      <?=csrfField()?><input type="hidden" name="act" value="new_contest">
      <div class="fg"><label>اسم المسابقة</label><input type="text" name="title" class="fi" value="مسابقة إحالة — <?=date('m/Y')?>" required></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <div class="fg"><label>تاريخ البدء</label><input type="date" name="start_date" class="fi" value="<?=date('Y-m-01')?>" required></div>
        <div class="fg"><label>تاريخ الانتهاء</label><input type="date" name="end_date" class="fi" value="<?=date('Y-m-t')?>" required></div>
      </div>
      <button type="submit" class="btn btn-gold btn-block"><i class="fas fa-plus"></i> إنشاء المسابقة</button>
    </form>
  </div>
</div>

<?php elseif($tab==='history'): ?>
<?php
$statusCls = ['active'=>'badge-green','ended'=>'badge-gray','cancelled'=>'badge-red'];
$statusLbl = ['active'=>'نشطة','ended'=>'منتهية','cancelled'=>'ملغاة'];
foreach($contests as $c):
  $results = $pdo->prepare("SELECT cr.*,u.username,u.id uid FROM contest_results cr JOIN users u ON u.id=cr.user_id WHERE cr.contest_id=? ORDER BY cr.rank_pos");
  $results->execute([$c['id']]);
  $results=$results->fetchAll();
?>
<div class="tbl-wrap" style="margin-bottom:14px">
  <div class="tbl-head">
    <div class="tbl-title"><i class="fas fa-trophy"></i><?=e($c['title'])?></div>
    <div style="display:flex;align-items:center;gap:8px">
      <span style="font-size:.7rem;color:#8b95b5"><?=$c['start_date']?> → <?=$c['end_date']?></span>
      <span class="badge <?=$statusCls[$c['status']]??'badge-gray'?>"><?=$statusLbl[$c['status']]??$c['status']?></span>
    </div>
  </div>
  <div style="padding:0">
    <?php if(!empty($results)): ?>
    <table style="width:100%;border-collapse:collapse">
      <thead><tr style="background:rgba(255,255,255,.02);border-bottom:1px solid rgba(255,255,255,.08)">
        <th style="padding:9px 14px;text-align:right;font-size:.68rem;color:#8b95b5">#</th>
        <th style="padding:9px 14px;text-align:right;font-size:.68rem;color:#8b95b5">المستخدم</th>
        <th style="padding:9px 14px;text-align:right;font-size:.68rem;color:#8b95b5">الإحالات</th>
        <th style="padding:9px 14px;text-align:right;font-size:.68rem;color:#8b95b5">المكافأة</th>
        <th style="padding:9px 14px;text-align:right;font-size:.68rem;color:#8b95b5">منح المكافأة</th>
      </tr></thead>
      <tbody>
      <?php foreach($results as $r): ?>
      <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
        <td style="padding:10px 14px"><span class="badge <?=$r['rank_pos']===1?'badge-gold':'badge-gray'?>"><?=$r['rank_pos']?></span></td>
        <td style="padding:10px 14px"><a href="users.php?id=<?=$r['uid']?>" style="color:#e8a400;font-weight:700">@<?=e($r['username'])?></a></td>
        <td style="padding:10px 14px;font-family:'JetBrains Mono',monospace;font-weight:700"><?=$r['referral_count']?></td>
        <td style="padding:10px 14px">
          <?php if($r['reward']): ?>
            <span style="color:#10d97a;font-weight:800"><?=number_format($r['reward'],2)?></span>
            <?php if($r['reward_note']): ?><br><small style="color:#8b95b5"><?=e($r['reward_note'])?></small><?php endif; ?>
          <?php else: ?><span style="color:#8b95b5;font-size:.72rem">لم تُحدد</span><?php endif; ?>
        </td>
        <td style="padding:10px 14px">
          <?php if(!$r['reward']): ?>
          <form method="POST" style="display:flex;gap:4px;align-items:center">
            <?=csrfField()?><input type="hidden" name="act" value="add_reward"><input type="hidden" name="result_id" value="<?=$r['id']?>">
            <input type="number" name="reward" placeholder="المبلغ" step="0.01" min="0.01" class="fi" style="width:85px;padding:5px 8px;font-size:.72rem" required>
            <input type="text" name="reward_note" placeholder="ملاحظة" class="fi" style="width:100px;padding:5px 8px;font-size:.72rem">
            <button class="btn btn-gold btn-xs"><i class="fas fa-coins"></i> منح</button>
          </form>
          <?php else: ?><span style="font-size:.65rem;color:#8b95b5"><i class="fas fa-check" style="color:#10d97a"></i> <?=date('Y/m/d',strtotime($r['rewarded_at']))?></span><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="padding:14px 18px;color:#8b95b5;font-size:.78rem">
      <?php if($c['status']==='active'): ?>
        المسابقة نشطة —
        <form method="POST" style="display:inline">
          <?=csrfField()?><input type="hidden" name="act" value="end_contest"><input type="hidden" name="contest_id" value="<?=$c['id']?>">
          <button class="btn btn-gold btn-xs" onclick="return confirm('حساب الفائزين الآن؟')"><i class="fas fa-calculator"></i> حساب الفائزين</button>
        </form>
      <?php else: ?>لم تكن هناك إحالات<?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
<?php if(empty($contests)): ?><div class="tbl-wrap"><div style="padding:40px;text-align:center;color:#8b95b5">لا توجد مسابقات بعد</div></div><?php endif; ?>

<?php elseif($tab==='leaders'): ?>
<div class="tbl-wrap">
  <div class="tbl-head"><div class="tbl-title"><i class="fas fa-chart-bar"></i> أفضل المحيلين على الإطلاق</div></div>
  <?php $allLeaders=$pdo->query("SELECT u.id,u.username,COUNT(r.id) cnt FROM referrals r JOIN users u ON u.id=r.referrer_id GROUP BY r.referrer_id ORDER BY cnt DESC LIMIT 20")->fetchAll(); ?>
  <table style="width:100%;border-collapse:collapse">
    <thead><tr style="background:rgba(255,255,255,.02);border-bottom:1px solid rgba(255,255,255,.08)">
      <th style="padding:10px 16px;text-align:right;font-size:.7rem;color:#8b95b5">#</th>
      <th style="padding:10px 16px;text-align:right;font-size:.7rem;color:#8b95b5">المستخدم</th>
      <th style="padding:10px 16px;text-align:right;font-size:.7rem;color:#8b95b5">إجمالي الإحالات</th>
      <th style="padding:10px 16px;text-align:right;font-size:.7rem;color:#8b95b5">إجراء</th>
    </tr></thead>
    <tbody>
    <?php if(empty($allLeaders)): ?>
      <tr><td colspan="4" style="padding:30px;text-align:center;color:#8b95b5">لا توجد إحالات بعد</td></tr>
    <?php else: foreach($allLeaders as $i=>$l): ?>
      <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
        <td style="padding:11px 16px"><?=['🥇','🥈','🥉'][$i]??'<span style="color:#8b95b5;font-weight:700">'.($i+1).'</span>'?></td>
        <td style="padding:11px 16px;font-weight:700">@<?=e($l['username'])?></td>
        <td style="padding:11px 16px;color:#e8a400;font-weight:900;font-family:'JetBrains Mono',monospace"><?=$l['cnt']?> <small style="font-size:.7rem;font-weight:400;color:#8b95b5">إحالة</small></td>
        <td style="padding:11px 16px"><a href="users.php?id=<?=$l['id']?>" class="btn btn-ghost btn-xs">عرض الملف</a></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>
<?php adminFoot(); ?>
