<?php
require_once 'admin_check.php';

// ─── STATS ────────────────────────────────────────────
$totalUsers     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0")->fetchColumn();
$newUsersToday  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0 AND DATE(created_at)=CURDATE()")->fetchColumn();
$totalListings  = (int)$pdo->query("SELECT COUNT(*) FROM listings")->fetchColumn();
$activeListings = (int)$pdo->query("SELECT COUNT(*) FROM listings WHERE status='active'")->fetchColumn();
$totalOrders    = (int)$pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();
$completedOrders= (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='completed'")->fetchColumn();
$heldOrders     = (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='held'")->fetchColumn();
$disputedOrders = (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='disputed'")->fetchColumn();
$pendingKyc     = (int)$pdo->query("SELECT COUNT(*) FROM kyc_documents WHERE status='pending'")->fetchColumn();
$totalRevenue   = (float)$pdo->query("SELECT COALESCE(SUM(commission),0) FROM purchases WHERE status='completed'")->fetchColumn();
$adminBalance   = (float)$pdo->query("SELECT COALESCE(balance,0) FROM users WHERE is_admin=1 LIMIT 1")->fetchColumn();
$bannedUsers    = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_banned=1")->fetchColumn();

// Recent activity
$recentOrders = $pdo->query("SELECT p.*,l.title listing_title,b.username buyer,s.username seller
    FROM purchases p JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id JOIN users s ON p.seller_id=s.id
    ORDER BY p.created_at DESC LIMIT 8")->fetchAll();

$recentUsers = $pdo->query("SELECT id,username,email,kyc_status,balance,created_at
    FROM users WHERE is_admin=0 ORDER BY created_at DESC LIMIT 8")->fetchAll();

// Monthly revenue (last 6 months)
$monthlyRev = $pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') mon,
    SUM(commission) rev, COUNT(*) orders
    FROM purchases WHERE status='completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY mon ORDER BY mon")->fetchAll();

adminHead('لوحة التحكم', 'index.php');
?>

<!-- TOPBAR -->
<div class="admin-topbar">
  <div>
    <div class="admin-topbar-title">
      لوحة التحكم
      <small>مرحباً بك! — <?= date('l، j F Y') ?></small>
    </div>
  </div>
</div>

<!-- STATS GRID -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-card-icon gold"><i class="fas fa-users"></i></div>
    <div>
      <div class="stat-card-val"><?= number_format($totalUsers) ?></div>
      <div class="stat-card-lbl">المستخدمون · <span class="green">+<?= $newUsersToday ?> اليوم</span></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green"><i class="fas fa-bullhorn"></i></div>
    <div>
      <div class="stat-card-val"><?= number_format($totalListings) ?></div>
      <div class="stat-card-lbl">الإعلانات · <?= $activeListings ?> نشطة</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon blue"><i class="fas fa-handshake"></i></div>
    <div>
      <div class="stat-card-val"><?= number_format($totalOrders) ?></div>
      <div class="stat-card-lbl">الطلبات · <?= $heldOrders ?> محجوزة</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon cyan"><i class="fas fa-dollar-sign"></i></div>
    <div>
      <div class="stat-card-val"><?= money($totalRevenue) ?></div>
      <div class="stat-card-lbl">إجمالي العمولات</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon purple"><i class="fas fa-wallet"></i></div>
    <div>
      <div class="stat-card-val"><?= money($adminBalance) ?></div>
      <div class="stat-card-lbl">رصيد المنصة</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon red"><i class="fas fa-id-card"></i></div>
    <div>
      <div class="stat-card-val"><?= $pendingKyc ?></div>
      <div class="stat-card-lbl">KYC ينتظر المراجعة</div>
    </div>
  </div>
</div>

<!-- ALERTS ROW -->
<?php if ($disputedOrders > 0): ?>
<div class="alert alert-err" style="margin-bottom:16px">
  <i class="fas fa-exclamation-triangle"></i>
  <span>يوجد <strong><?= $disputedOrders ?></strong> نزاع يحتاج تدخلك — <a href="disputes.php" style="color:var(--red);text-decoration:underline">عرض النزاعات</a></span>
</div>
<?php endif; ?>
<?php if ($pendingKyc > 0): ?>
<div class="alert alert-warn" style="margin-bottom:16px">
  <i class="fas fa-id-card"></i>
  <span>يوجد <strong><?= $pendingKyc ?></strong> طلب توثيق KYC ينتظر المراجعة — <a href="kyc.php" style="color:#fbbf24;text-decoration:underline">مراجعة الآن</a></span>
</div>
<?php endif; ?>

<div class="col-grid">
  <!-- RECENT ORDERS -->
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-handshake"></i> آخر الطلبات</div>
    <?php if (empty($recentOrders)): ?>
      <div class="empty"><i class="fas fa-inbox"></i><p>لا توجد طلبات بعد</p></div>
    <?php else: foreach ($recentOrders as $o): ?>
      <a href="orders.php?detail=<?= $o['id'] ?>" style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);text-decoration:none;color:var(--txt)">
        <div style="flex:1;min-width:0">
          <div style="font-size:.82rem;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e(mb_substr($o['listing_title'],0,30,'UTF-8')) ?></div>
          <div style="font-size:.68rem;color:var(--txt2);margin-top:2px"><?= e($o['buyer']) ?> → <?= e($o['seller']) ?> · <?= timeAgo($o['created_at']) ?></div>
        </div>
        <div style="text-align:left;flex-shrink:0">
          <div class="mono" style="font-size:.8rem;color:var(--gold)"><?= money((float)$o['amount']) ?></div>
          <span class="tag tag-<?= $o['status'] ?>" style="font-size:.6rem"><?= statusLabel($o['status']) ?></span>
        </div>
      </a>
    <?php endforeach; endif; ?>
    <div style="margin-top:10px">
      <a href="orders.php" class="btn btn-ghost btn-sm btn-block" style="font-size:.75rem">
        <i class="fas fa-arrow-left"></i> كل الطلبات
      </a>
    </div>
  </div>

  <!-- RECENT USERS -->
  <div class="sec-card" style="margin-bottom:0">
    <div class="sec-card-title"><i class="fas fa-user-plus"></i> آخر المسجلين</div>
    <?php if (empty($recentUsers)): ?>
      <div class="empty"><i class="fas fa-users"></i><p>لا يوجد مستخدمون</p></div>
    <?php else: foreach ($recentUsers as $u): ?>
      <a href="users.php?detail=<?= $u['id'] ?>" style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);text-decoration:none;color:var(--txt)">
        <div class="user-av" style="width:30px;height:30px;font-size:.75rem">
          <?= strtoupper(mb_substr($u['username'],0,1,'UTF-8')) ?>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:.82rem;font-weight:700"><?= e($u['username']) ?></div>
          <div style="font-size:.67rem;color:var(--txt2)"><?= e($u['email']) ?> · <?= timeAgo($u['created_at']) ?></div>
        </div>
        <?= kycBadge($u['kyc_status']) ?>
      </a>
    <?php endforeach; endif; ?>
    <div style="margin-top:10px">
      <a href="users.php" class="btn btn-ghost btn-sm btn-block" style="font-size:.75rem">
        <i class="fas fa-arrow-left"></i> كل المستخدمين
      </a>
    </div>
  </div>
</div>

<!-- PLATFORM HEALTH ────────────────────────────── -->
<?php
$totalOrdersCalc = max(1,$totalOrders);
$completionRate  = round($completedOrders / $totalOrdersCalc * 100);
$totalUsersCalc  = max(1,$totalUsers);
try {
    $kycApproved = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=0 AND kyc_status='approved'")->fetchColumn();
} catch(Exception $e){ $kycApproved=0; }
$kycRate       = round($kycApproved / $totalUsersCalc * 100);
$disputeRate   = $totalOrders>0 ? round($disputedOrders / $totalOrders * 100, 1) : 0;
try {
    $activeAds = (int)$pdo->query("SELECT COUNT(*) FROM ads WHERE status='active'")->fetchColumn();
    $totalAds  = max(1,(int)$pdo->query("SELECT COUNT(*) FROM ads")->fetchColumn());
} catch(Exception $e){ $activeAds=0;$totalAds=1; }
$adsRate = round($activeAds/$totalAds*100);

// Health score (0-100)
$healthScore = round(($completionRate*0.4) + ($kycRate*0.2) + ((100-min(100,$disputeRate*10))*0.25) + ($adsRate*0.15));
$healthColor = $healthScore>=75?'green':($healthScore>=50?'gold':'red');
$healthLabel = $healthScore>=75?'ممتاز':($healthScore>=50?'متوسط':'يحتاج اهتمام');
?>
<div class="health-card">
  <div class="health-title"><i class="fas fa-heartbeat"></i> مؤشر صحة المنصة</div>
  <div style="display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap">
    <div class="health-score">
      <div class="health-score-val" style="color:var(--<?=$healthColor?>)"><?=$healthScore?><span style="font-size:.7em;color:var(--t3)">%</span></div>
      <div class="health-score-lbl">نقاط الصحة<br><span style="color:var(--<?=$healthColor?>);font-weight:700"><?=$healthLabel?></span></div>
    </div>
    <div class="health-grid" style="flex:1;min-width:0">
      <div class="health-item">
        <div class="health-item-label">نسبة إتمام الصفقات <span><?=$completionRate?>%</span></div>
        <div class="health-track"><div class="health-fill green" style="width:<?=$completionRate?>%"></div></div>
      </div>
      <div class="health-item">
        <div class="health-item-label">معدل توثيق KYC <span><?=$kycRate?>%</span></div>
        <div class="health-track"><div class="health-fill blue" style="width:<?=$kycRate?>%"></div></div>
      </div>
      <div class="health-item">
        <div class="health-item-label">نسبة النزاعات <span><?=$disputeRate?>%</span></div>
        <div class="health-track"><div class="health-fill <?=$disputeRate>5?'red':'green'?>" style="width:<?=min(100,$disputeRate*10)?>%"></div></div>
      </div>
      <div class="health-item">
        <div class="health-item-label">الإعلانات النشطة <span><?=$adsRate?>%</span></div>
        <div class="health-track"><div class="health-fill gold" style="width:<?=$adsRate?>%"></div></div>
      </div>
    </div>
  </div>
</div>

<!-- QUICK ACTIONS -->
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-bolt"></i> إجراءات سريعة</div>
  <div class="quick-action-grid">
    <a href="users.php" class="quick-action"><i class="fas fa-users"></i><span>المستخدمون</span></a>
    <a href="ads.php" class="quick-action"><i class="fas fa-th-list"></i><span>الإعلانات</span></a>
    <a href="products.php" class="quick-action"><i class="fas fa-box-open"></i><span>المنتجات</span></a>
    <a href="orders.php" class="quick-action"><i class="fas fa-handshake"></i><span>الطلبات</span></a>
    <a href="kyc.php" class="quick-action"><i class="fas fa-id-card"></i><span>التحقق KYC</span></a>
    <a href="disputes.php" class="quick-action"><i class="fas fa-exclamation-triangle"></i><span>النزاعات</span></a>
    <a href="deposits.php" class="quick-action"><i class="fas fa-arrow-circle-down"></i><span>الإيداعات</span></a>
    <a href="withdrawals.php" class="quick-action"><i class="fas fa-money-bill-wave"></i><span>السحوبات</span></a>
    <a href="wallet.php" class="quick-action"><i class="fas fa-wallet"></i><span>المحفظة</span></a>
    <a href="broadcast.php" class="quick-action"><i class="fas fa-bullhorn"></i><span>الإذاعة</span></a>
    <a href="reports.php" class="quick-action"><i class="fas fa-chart-pie"></i><span>التقارير</span></a>
    <a href="settings.php" class="quick-action"><i class="fas fa-cog"></i><span>الإعدادات</span></a>
    <a href="activity_log.php" class="quick-action"><i class="fas fa-history"></i><span>سجل النشاطات</span></a>
    <a href="media_library.php" class="quick-action"><i class="fas fa-images"></i><span>مكتبة الوسائط</span></a>
  </div>
</div>

<!-- MONTHLY REVENUE TABLE -->
<?php if (!empty($monthlyRev)): ?>
<div class="sec-card">
  <div class="sec-card-title"><i class="fas fa-chart-bar"></i> العمولات الشهرية</div>
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <th>الشهر</th>
          <th>عدد الصفقات</th>
          <th>إجمالي العمولات</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach (array_reverse($monthlyRev) as $m): ?>
        <tr>
          <td class="mono"><?= e($m['mon']) ?></td>
          <td><?= number_format($m['orders']) ?></td>
          <td class="gold mono"><?= money((float)$m['rev']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php adminFoot(); ?>
