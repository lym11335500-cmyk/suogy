<?php
require_once 'admin_check.php';

$msg = '';

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['act'] ?? '';
    $pid = (int)($_POST['pid'] ?? 0);

    if ($act === 'complete' && $pid) {
        completePurchase($pdo, $pid);
        $msg = 'تم إتمام الصفقة.';
    } elseif ($act === 'refund' && $pid) {
        $chat = $pdo->query("SELECT id FROM chats WHERE purchase_id=$pid LIMIT 1")->fetch();
        if ($chat) refundPurchase($pdo, $pid, $chat['id'], 'completed');
        $msg = 'تم استرجاع المبلغ للمشتري.';
    } elseif ($act === 'resolve_dispute' && $pid) {
        $side = $_POST['side'] ?? 'buyer';
        $chat = $pdo->query("SELECT id FROM chats WHERE purchase_id=$pid LIMIT 1")->fetch();
        if ($side === 'seller') {
            completePurchase($pdo, $pid);
            addNotif($pdo, (int)$pdo->query("SELECT buyer_id FROM purchases WHERE id=$pid")->fetchColumn(),
                     'dispute', '⚖️ تم حل النزاع لصالح البائع.', "deal.php?pid=$pid");
        } else {
            if ($chat) refundPurchase($pdo, $pid, $chat['id'], 'completed');
            addNotif($pdo, (int)$pdo->query("SELECT seller_id FROM purchases WHERE id=$pid")->fetchColumn(),
                     'dispute', '⚖️ تم حل النزاع لصالح المشتري.', "deal.php?pid=$pid");
        }
        $msg = 'تم حل النزاع.';
    }
}

$filter  = $_GET['f'] ?? 'all';
$search  = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['p'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where  = "WHERE 1=1";
$params = [];
if ($filter !== 'all') { $where .= " AND p.status=?"; $params[] = $filter; }
if ($search) {
    $where .= " AND (l.title LIKE ? OR b.username LIKE ? OR s.username LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id JOIN users s ON p.seller_id=s.id $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = max(1, ceil($total / $perPage));

$stmt = $pdo->prepare("SELECT p.*,l.title listing_title,b.username buyer,s.username seller
    FROM purchases p
    JOIN listings l ON p.listing_id=l.id
    JOIN users b ON p.buyer_id=b.id JOIN users s ON p.seller_id=s.id
    $where ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Count per status for filter badges
$counts = [];
foreach(['held','completed','disputed','refunded'] as $st) {
    $counts[$st] = (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='$st'")->fetchColumn();
}

adminHead('الطلبات', 'orders.php');
?>

<div class="admin-topbar">
  <div>
    <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="fas fa-bars"></i></button>
    <div class="admin-topbar-title" style="display:inline-block;margin-right:10px">
      الطلبات والصفقات
      <small>إجمالي: <?= number_format($total) ?></small>
    </div>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-ok"><i class="fas fa-check-circle"></i><span><?=e($msg)?></span></div><?php endif; ?>

<!-- FILTER TABS -->
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;align-items:center">
  <?php
  $labels = ['all'=>'الكل','held'=>'محجوزة','completed'=>'مكتملة','disputed'=>'نزاعات','refunded'=>'مستردة'];
  foreach ($labels as $k=>$v):
    $cnt = ($k !== 'all') ? ($counts[$k] ?? 0) : null;
  ?>
  <a href="?f=<?=$k?>&q=<?=urlencode($search)?>"
     class="btn btn-sm <?=$filter===$k?'btn-gold':'btn-ghost'?>" style="font-size:.75rem;gap:4px">
    <?=$v?>
    <?php if ($cnt): ?><span style="background:#ef444422;color:var(--red);padding:0 5px;border-radius:8px;font-size:.65rem"><?=$cnt?></span><?php endif; ?>
  </a>
  <?php endforeach; ?>
  <form method="GET" style="margin-right:auto;display:flex;gap:6px">
    <input type="hidden" name="f" value="<?=e($filter)?>">
    <div class="search-bar" style="min-width:220px">
      <i class="fas fa-search"></i>
      <input type="text" name="q" value="<?=e($search)?>" placeholder="بحث بالإعلان أو المستخدم...">
    </div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-search"></i></button>
  </form>
</div>

<!-- TABLE -->
<div class="data-table-wrap">
  <div style="overflow-x:auto">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>الإعلان</th>
          <th>المشتري</th>
          <th>البائع</th>
          <th>المبلغ</th>
          <th>العمولة</th>
          <th>التاريخ</th>
          <th>الحالة</th>
          <th>إجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
        <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--txt3)">لا توجد طلبات</td></tr>
        <?php else: foreach ($orders as $o): ?>
        <tr <?= $o['status']==='disputed' ? 'style="background:#ef444408"' : '' ?>>
          <td class="mono txt2" style="font-size:.72rem"><?=$o['id']?></td>
          <td class="truncate" style="font-size:.8rem;font-weight:600;max-width:160px"><?=e($o['listing_title'])?></td>
          <td>
            <a href="users.php?detail=<?=$o['buyer_id']?>" style="color:var(--blue);text-decoration:none;font-size:.8rem">
              <?=e($o['buyer'])?>
            </a>
          </td>
          <td>
            <a href="users.php?detail=<?=$o['seller_id']?>" style="color:var(--gold);text-decoration:none;font-size:.8rem">
              <?=e($o['seller'])?>
            </a>
          </td>
          <td class="mono gold"><?=money((float)$o['amount'])?></td>
          <td class="mono" style="color:var(--cyan);font-size:.75rem"><?=money((float)$o['commission'])?></td>
          <td class="txt2" style="font-size:.72rem"><?=timeAgo($o['created_at'])?></td>
          <td><span class="tag tag-<?=$o['status']?>"><?=statusLabel($o['status'])?></span></td>
          <td>
            <div class="table-actions">
              <?php if ($o['status'] === 'held'): ?>
              <form method="POST" style="display:contents">
                <input type="hidden" name="_csrf" value="<?=csrf()?>">
                <input type="hidden" name="pid" value="<?=$o['id']?>">
                <button type="submit" name="act" value="complete"
                  class="btn btn-green btn-sm" style="padding:5px 10px;font-size:.72rem"
                  onclick="return confirm('إتمام الصفقة؟ سيحصل البائع على المبلغ.')">
                  <i class="fas fa-check"></i> إتمام
                </button>
                <button type="submit" name="act" value="refund"
                  class="btn btn-red btn-sm" style="padding:5px 10px;font-size:.72rem"
                  onclick="return confirm('استرجاع المبلغ للمشتري؟')">
                  <i class="fas fa-undo"></i> استرداد
                </button>
              </form>
              <?php elseif ($o['status'] === 'disputed'): ?>
              <button onclick="openDisputeModal(<?=$o['id']?>, '<?=e(addslashes($o['listing_title']))?>', '<?=e(addslashes($o['buyer']))?>', '<?=e(addslashes($o['seller']))?>')"
                class="btn btn-gold btn-sm" style="padding:5px 10px;font-size:.72rem">
                <i class="fas fa-gavel"></i> حل النزاع
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="pagination">
    <?php for ($i=1; $i<=min($pages,10); $i++): ?>
    <a href="?f=<?=e($filter)?>&q=<?=urlencode($search)?>&p=<?=$i?>"
       class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DISPUTE MODAL -->
<div class="modal-overlay" id="disputeModal">
  <div class="modal">
    <div class="modal-title">
      <span><i class="fas fa-gavel" style="color:var(--gold);margin-left:8px"></i> حل النزاع</span>
      <button class="modal-close" onclick="document.getElementById('disputeModal').classList.remove('open')"><i class="fas fa-times"></i></button>
    </div>
    <div id="disputeInfo" style="background:var(--bg2);border-radius:var(--r2);padding:14px;margin-bottom:16px;font-size:.82rem;color:var(--txt2)"></div>
    <form method="POST">
      <input type="hidden" name="_csrf" value="<?=csrf()?>">
      <input type="hidden" name="act" value="resolve_dispute">
      <input type="hidden" name="pid" id="disputePid">
      <div class="fg">
        <label>حل النزاع لصالح:</label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px">
          <label style="background:var(--bg2);border:1.5px solid var(--border2);border-radius:var(--r2);padding:14px;cursor:pointer;text-align:center;transition:all .2s" id="buyerLabel" onclick="selectSide('buyer')">
            <input type="radio" name="side" value="buyer" checked style="display:none">
            <i class="fas fa-user-tie" style="font-size:1.3rem;color:var(--blue);display:block;margin-bottom:6px"></i>
            <div style="font-weight:700;color:var(--blue)" id="disputeBuyer">المشتري</div>
            <div style="font-size:.7rem;color:var(--txt3);margin-top:3px">استرداد المبلغ</div>
          </label>
          <label style="background:var(--bg2);border:1.5px solid var(--border2);border-radius:var(--r2);padding:14px;cursor:pointer;text-align:center;transition:all .2s" id="sellerLabel" onclick="selectSide('seller')">
            <input type="radio" name="side" value="seller" style="display:none">
            <i class="fas fa-store" style="font-size:1.3rem;color:var(--gold);display:block;margin-bottom:6px"></i>
            <div style="font-weight:700;color:var(--gold)" id="disputeSeller">البائع</div>
            <div style="font-size:.7rem;color:var(--txt3);margin-top:3px">إتمام الصفقة</div>
          </label>
        </div>
      </div>
      <button type="submit" class="btn btn-gold btn-block" onclick="return confirm('تأكيد حل النزاع؟ لا يمكن التراجع!')">
        <i class="fas fa-gavel"></i> تأكيد القرار
      </button>
    </form>
  </div>
</div>

<script>
let selectedSide = 'buyer';
function openDisputeModal(pid, title, buyer, seller) {
  document.getElementById('disputePid').value = pid;
  document.getElementById('disputeInfo').innerHTML =
    `<strong style="color:var(--txt)">الإعلان:</strong> ${title}<br>
     <strong style="color:var(--blue)">المشتري:</strong> ${buyer} &nbsp;|&nbsp; <strong style="color:var(--gold)">البائع:</strong> ${seller}`;
  document.getElementById('disputeBuyer').textContent = buyer;
  document.getElementById('disputeSeller').textContent = seller;
  selectedSide = 'buyer';
  selectSide('buyer');
  document.getElementById('disputeModal').classList.add('open');
}
function selectSide(side) {
  selectedSide = side;
  const bLabel = document.getElementById('buyerLabel');
  const sLabel = document.getElementById('sellerLabel');
  bLabel.style.borderColor = side==='buyer' ? 'var(--blue)' : 'var(--border2)';
  sLabel.style.borderColor = side==='seller' ? 'var(--gold)' : 'var(--border2)';
  document.querySelector('input[name="side"][value="'+side+'"]').checked = true;
}
document.getElementById('disputeModal').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('open');
});
</script>

<?php adminFoot(); ?>
