<?php
// ════════════════════════════════════════════════════════
//  🔧 أداة طوارئ — إنشاء/تحديث الأدمن
//  ارفع هذا الملف وافتحه مرة واحدة فقط ثم احذفه فوراً!
// ════════════════════════════════════════════════════════
require_once __DIR__ . '/includes/db.php';

$msg = ''; $err = '';
if(isset($_GET['do'])){
    $newPass = trim($_GET['pass'] ?? 'Admin@2024');
    if(strlen($newPass) < 6){ $err = 'كلمة المرور قصيرة جداً (6 أحرف على الأقل)'; }
    else {
        $ex = $pdo->query("SELECT id,username FROM users WHERE is_admin=1 LIMIT 1")->fetch();
        if($ex){
            $pdo->prepare("UPDATE users SET password=?,is_banned=0 WHERE id=?")->execute([$newPass,$ex['id']]);
            $msg = '✅ تم تحديث كلمة مرور الأدمن <b>'.$ex['username'].'</b> — كلمة المرور: <b>'.$newPass.'</b>';
        } else {
            $au = 'TV'.strtoupper(substr(bin2hex(random_bytes(4)),0,8));
            $pdo->prepare("INSERT INTO users(unique_id,username,email,password,kyc_status,is_admin,balance)VALUES(?,?,?,?,?,?,?)")
                ->execute([$au,ADMIN_USERNAME,ADMIN_EMAIL,$newPass,'approved',1,0]);
            $msg = '✅ تم إنشاء الأدمن <b>'.ADMIN_USERNAME.'</b> — كلمة المرور: <b>'.$newPass.'</b>';
        }
    }
}
$admin = $pdo->query("SELECT id,username,email FROM users WHERE is_admin=1 LIMIT 1")->fetch();
$users = $pdo->query("SELECT id,username,email,is_admin,is_banned FROM users ORDER BY id DESC LIMIT 15")->fetchAll();
?><!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>Setup Admin</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Cairo,sans-serif;background:#07080b;color:#e0e6f0;padding:28px}
.w{max-width:720px;margin:auto}.card{background:#111520;border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:22px;margin-bottom:16px}
h1{color:#e8a400;margin-bottom:4px}h2{font-size:.85rem;color:#8b95b5;text-transform:uppercase;letter-spacing:1px;margin-bottom:14px}
.ok{color:#10d97a;background:rgba(16,217,122,.1);border:1px solid rgba(16,217,122,.2);padding:12px;border-radius:10px;margin-bottom:14px}
.er{color:#ff4757;background:rgba(255,71,87,.1);border:1px solid rgba(255,71,87,.2);padding:12px;border-radius:10px;margin-bottom:14px}
.btn{display:inline-block;padding:9px 20px;border-radius:9px;font-weight:700;text-decoration:none;font-size:.85rem;margin:3px;cursor:pointer}
.gold{background:linear-gradient(135deg,#f5c842,#e8a400);color:#07080b}
.gray{background:rgba(255,255,255,.07);color:#8b95b5;border:1px solid rgba(255,255,255,.1)}
input{background:#0a0d18;border:1px solid rgba(255,255,255,.15);border-radius:8px;padding:9px 12px;color:#e0e6f0;font-size:.85rem;outline:none}
input:focus{border-color:#e8a400}table{width:100%;border-collapse:collapse;font-size:.8rem}
th{background:rgba(255,255,255,.05);padding:8px;text-align:right;color:#5a6480}td{padding:8px;border-bottom:1px solid rgba(255,255,255,.05)}
.b{padding:2px 8px;border-radius:20px;font-size:.65rem;font-weight:700}
.ba{background:rgba(232,164,0,.15);color:#e8a400;border:1px solid rgba(232,164,0,.25)}
.bu{background:rgba(255,255,255,.05);color:#5a6480;border:1px solid rgba(255,255,255,.08)}
.bb{background:rgba(255,71,87,.15);color:#ff4757;border:1px solid rgba(255,71,87,.25)}
.warn{background:rgba(255,71,87,.06);border:1px solid rgba(255,71,87,.3);border-radius:10px;padding:14px;color:#ff4757;margin-top:12px;font-size:.85rem}
</style></head><body><div class="w">
<h1>🔧 أداة إعداد الأدمن</h1>
<p style="color:#5a6480;margin-bottom:20px;font-size:.82rem">DB: <b><?=DB_HOST?></b> / <b><?=DB_NAME?></b></p>

<?php if($msg):?><div class="ok"><?=$msg?></div><?php endif;?>
<?php if($err):?><div class="er">❌ <?=htmlspecialchars($err)?></div><?php endif;?>

<div class="card">
<h2>📊 حالة الأدمن</h2>
<?php if($admin):?>
<div class="ok">✅ أدمن موجود: <b><?=htmlspecialchars($admin['username'])?></b> (<?=htmlspecialchars($admin['email'])?>)</div>
<?php else:?>
<div class="er">🔴 لا يوجد أدمن في قاعدة البيانات!</div>
<?php endif;?>
</div>

<div class="card">
<h2>🛠️ إنشاء / تحديث كلمة مرور الأدمن</h2>
<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
  <input id="np" type="text" value="Admin@2024" placeholder="كلمة المرور الجديدة" style="width:200px">
  <a href="#" class="btn gold" onclick="location='?do=1&pass='+document.getElementById('np').value">تنفيذ</a>
  <a href="?" class="btn gray">تحديث</a>
</div>
<p style="color:#5a6480;font-size:.78rem;margin-top:10px">لو أدمن موجود → يحدّث كلمة المرور | لو مش موجود → ينشئ أدمن جديد</p>
</div>

<?php if(!empty($users)):?>
<div class="card">
<h2>👥 المستخدمون (آخر 15)</h2>
<table><thead><tr><th>ID</th><th>Username</th><th>Email</th><th>نوع</th><th>حالة</th></tr></thead><tbody>
<?php foreach($users as $u):?>
<tr>
  <td style="font-family:monospace;color:#5a6480"><?=$u['id']?></td>
  <td><b><?=htmlspecialchars($u['username'])?></b></td>
  <td style="color:#5a6480;font-size:.73rem"><?=htmlspecialchars($u['email'])?></td>
  <td><span class="b <?=$u['is_admin']?'ba':'bu'?>"><?=$u['is_admin']?'👑 أدمن':'مستخدم'?></span></td>
  <td><span class="b <?=$u['is_banned']?'bb':'bu'?>"><?=$u['is_banned']?'🚫 موقوف':'✓ نشط'?></span></td>
</tr>
<?php endforeach;?>
</tbody></table></div>
<?php endif;?>

<div class="card">
<h2>🚀 للدخول لوحة الأدمن</h2>
<p style="line-height:2;color:#8b95b5;font-size:.88rem">
الرابط: <b style="color:#e8a400">yoursite.com/admin/login.php</b><br>
المستخدم: <b style="color:#e8a400"><?=ADMIN_USERNAME?></b><br>
كلمة المرور: <b style="color:#e8a400">Admin@2024</b> (أو ما غيّرتها أعلاه)
</p>
</div>

<div class="warn">⚠️ <b>احذف هذا الملف فوراً بعد الانتهاء! أي شخص يقدر يستخدمه.</b></div>
</div></body></html>
