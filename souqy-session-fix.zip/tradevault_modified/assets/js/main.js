// ════════════════════════════════════════════════════════
//  سوقي Souqy — Main JavaScript
// ════════════════════════════════════════════════════════

'use strict';

// ── CSRF TOKEN ───────────────────────────────────────────
const csrf = document.querySelector('meta[name="csrf"]')?.content || '';

// ── FETCH HELPER ─────────────────────────────────────────
async function tv2Fetch(url, data = {}) {
  data._csrf = csrf;
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify(data),
      credentials: 'same-origin'
    });
    return await r.json();
  } catch(e) { return { ok: false, error: e.message }; }
}

// ── TOAST ────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const colors = { ok:'#10d97a', err:'#ff4757', info:'#4a8ff5', warn:'#e8a400' };
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:90px;left:50%;transform:translateX(-50%);
    background:${colors[type]||colors.info};color:#fff;padding:10px 20px;
    border-radius:12px;font-size:.85rem;font-weight:700;z-index:9999;
    animation:slideDown .3s ease;max-width:90%;text-align:center;
    box-shadow:0 8px 24px rgba(0,0,0,.4);`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .4s'; setTimeout(()=>t.remove(),400); }, 2800);
}

// ── MODAL ────────────────────────────────────────────────
function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
  if (e.target.closest('[data-modal-close]')) {
    e.target.closest('.modal-overlay').classList.remove('open');
  }
});

// ── IMAGE LIGHTBOX ───────────────────────────────────────
function openLightbox(src) {
  let lb = document.getElementById('tv2-lb');
  if (!lb) {
    lb = document.createElement('div');
    lb.id = 'tv2-lb';
    lb.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9998;display:flex;align-items:center;justify-content:center;cursor:zoom-out;backdrop-filter:blur(6px)';
    lb.innerHTML = '<img id="tv2-lbimg" style="max-width:96vw;max-height:90vh;border-radius:12px;object-fit:contain" alt="">';
    lb.onclick = () => lb.remove();
    document.body.appendChild(lb);
  }
  document.getElementById('tv2-lbimg').src = src;
}

// ── AUTO-RESIZE TEXTAREA ─────────────────────────────────
document.querySelectorAll('textarea[data-autoresize]').forEach(ta => {
  ta.style.overflow = 'hidden';
  const resize = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; };
  ta.addEventListener('input', resize);
});

// ── CONFIRM ACTIONS ──────────────────────────────────────
document.querySelectorAll('[data-confirm]').forEach(el => {
  el.addEventListener('click', e => {
    if (!confirm(el.dataset.confirm)) e.preventDefault();
  });
});

// ── CATEGORY FILTER ──────────────────────────────────────
document.querySelectorAll('.cat-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    const cat = chip.dataset.cat || '';
    const url = new URL(window.location.href);
    if (cat) url.searchParams.set('cat', cat); else url.searchParams.delete('cat');
    url.searchParams.delete('p');
    window.location.href = url.toString();
  });
});

// ── MARK NOTIFICATIONS READ ──────────────────────────────
if (document.querySelector('.notif-item.unread')) {
  fetch('../api/mark-notifs.php', { method:'POST', credentials:'same-origin' });
}

// ── FADE IN ELEMENTS ─────────────────────────────────────
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.l-card, .stat-box, .card').forEach(el => observer.observe(el));

// ── SCROLL TO TOP (inject button if missing) ──────────────
(function () {
  if (document.getElementById('stt')) return; // already exists
  const btn = document.createElement('button');
  btn.id = 'stt-global';
  btn.title = 'العودة للأعلى';
  btn.innerHTML = '<i class="fas fa-arrow-up"></i>';
  btn.style.cssText = 'position:fixed;bottom:80px;right:16px;z-index:400;width:40px;height:40px;border-radius:12px;background:var(--card2,#181d2e);border:1px solid rgba(255,255,255,.1);color:var(--gold,#e8a400);font-size:.9rem;opacity:0;pointer-events:none;transition:opacity .3s;cursor:pointer;display:flex;align-items:center;justify-content:center';
  document.body.appendChild(btn);
  window.addEventListener('scroll', () => {
    btn.style.opacity = window.scrollY > 300 ? '1' : '0';
    btn.style.pointerEvents = window.scrollY > 300 ? 'auto' : 'none';
  }, { passive: true });
  btn.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
})();

// ── KEYFRAME: slideDown (for toasts) ─────────────────────
(function () {
  if (document.getElementById('tv2-animations')) return;
  const style = document.createElement('style');
  style.id = 'tv2-animations';
  style.textContent = '@keyframes slideDown{from{opacity:0;transform:translateX(-50%) translateY(10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}';
  document.head.appendChild(style);
})();
