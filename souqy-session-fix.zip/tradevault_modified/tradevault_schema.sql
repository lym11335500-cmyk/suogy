-- ============================================================
-- TradeVault Database Schema
-- Database: if0_41256124_buy_sell
-- Host: sql204.infinityfree.com
-- Generated for: InfinityFree Hosting
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone_country_code` varchar(5) DEFAULT '+20',
  `phone_country_flag` varchar(10) DEFAULT '🇪🇬',
  `password` varchar(255) NOT NULL COMMENT 'stored as plain text',
  `profile_pic` varchar(255) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `held_balance` decimal(10,2) DEFAULT 0.00,
  `kyc_status` enum('not_submitted','pending','approved','rejected') DEFAULT 'not_submitted',
  `seller_rating` int(11) DEFAULT 0,
  `buyer_rating` int(11) DEFAULT 0,
  `total_sales` int(11) DEFAULT 0,
  `total_purchases` int(11) DEFAULT 0,
  `is_admin` tinyint(1) DEFAULT 0,
  `is_banned` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin account (password: admin123 — يتم تشفيرها تلقائياً بـ bcrypt عند التثبيت)
INSERT INTO `users` (`username`, `email`, `password`, `kyc_status`, `is_admin`, `balance`) VALUES
-- كلمة المرور تُولَّد تلقائياً بـ bcrypt من ملف db.php عند أول تشغيل

-- ============================================================
-- TABLE: kyc_documents
-- ============================================================
CREATE TABLE IF NOT EXISTS `kyc_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `id_card_image` varchar(255) DEFAULT NULL,
  `selfie_image` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` text,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_notes` text,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `kyc_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: categories (34 pre-seeded categories)
-- ============================================================
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fa-tag',
  `category_type` enum('games','social','other') DEFAULT 'other',
  `description` text,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`name`, `name_ar`, `icon`, `category_type`, `sort_order`) VALUES
-- Games (20)
('Clash of Clans', 'كلاش أوف كلانس', 'fa-shield-alt', 'games', 1),
('Clash Royale', 'كلاش رويال', 'fa-crown', 'games', 2),
('PUBG Mobile', 'ببجي موبايل', 'fa-crosshairs', 'games', 3),
('Free Fire', 'فري فاير', 'fa-fire', 'games', 4),
('Call of Duty Mobile', 'كول أوف ديوتي موبايل', 'fa-gun', 'games', 5),
('Fortnite', 'فورتنايت', 'fa-gamepad', 'games', 6),
('League of Legends', 'ليغ أوف ليجيندز', 'fa-chess', 'games', 7),
('Valorant', 'فالورانت', 'fa-bullseye', 'games', 8),
('Minecraft', 'ماين كرافت', 'fa-cube', 'games', 9),
('Hay Day', 'هاي داي', 'fa-leaf', 'games', 10),
('PUBG Lite', 'ببجي لايت', 'fa-crosshairs', 'games', 11),
('Roblox', 'روبلوكس', 'fa-robot', 'games', 12),
('eFootball / PES', 'بيس / إيفوتبول', 'fa-futbol', 'games', 13),
('FIFA Mobile', 'فيفا موبايل', 'fa-futbol', 'games', 14),
('Genshin Impact', 'جينشن إمباكت', 'fa-star', 'games', 15),
('GTA V Online', 'جراند ثفت أوتو', 'fa-car', 'games', 16),
('Arena of Valor', 'أرينا أوف فالور', 'fa-trophy', 'games', 17),
('Mobile Legends', 'موبايل ليجيندز', 'fa-dragon', 'games', 18),
('World of Warcraft', 'ورلد أوف ووركرافت', 'fa-dungeon', 'games', 19),
('Red Dead Redemption 2', 'ريد ديد ريدمبشن', 'fa-hat-cowboy', 'games', 20),
-- Social (7)
('Telegram Channels', 'قنوات تيليجرام', 'fa-paper-plane', 'social', 21),
('YouTube Channels', 'قنوات يوتيوب', 'fa-youtube', 'social', 22),
('Facebook Pages', 'صفحات فيسبوك', 'fa-facebook', 'social', 23),
('Instagram Accounts', 'حسابات إنستغرام', 'fa-instagram', 'social', 24),
('Twitter / X', 'حسابات تويتر/X', 'fa-x-twitter', 'social', 25),
('TikTok Accounts', 'حسابات تيك توك', 'fa-tiktok', 'social', 26),
('Snapchat Accounts', 'حسابات سناب شات', 'fa-ghost', 'social', 27),
-- Other (7)
('Gmail Accounts', 'حسابات جيميل', 'fa-envelope', 'other', 28),
('Microsoft Accounts', 'حسابات مايكروسوفت', 'fa-windows', 'other', 29),
('Netflix Accounts', 'حسابات نتفليكس', 'fa-film', 'other', 30),
('Spotify Premium', 'سبوتيفاي بريميوم', 'fa-music', 'other', 31),
('PayPal Accounts', 'حسابات باي بال', 'fa-paypal', 'other', 32),
('Amazon Accounts', 'حسابات أمازون', 'fa-amazon', 'other', 33),
('WhatsApp / Viber', 'واتساب / فايبر', 'fa-whatsapp', 'other', 34);

-- ============================================================
-- TABLE: listings
-- ============================================================
CREATE TABLE IF NOT EXISTS `listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `status` enum('active','pending_sale','sold','expired','disabled') DEFAULT 'active',
  `added_by` enum('admin','user') DEFAULT 'user',
  `views` int(11) DEFAULT 0,
  `account_details` text COMMENT 'Revealed only after purchase completion',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `listing_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `listing_cat_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: listing_images
-- ============================================================
CREATE TABLE IF NOT EXISTS `listing_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_video` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`),
  CONSTRAINT `img_listing_fk` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: purchases
-- ============================================================
CREATE TABLE IF NOT EXISTS `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `commission` decimal(10,2) NOT NULL DEFAULT 0.00,
  `seller_net` decimal(10,2) NOT NULL,
  `status` enum('held','completed','refunded','disputed') DEFAULT 'held',
  `account_details_shown` text COMMENT 'Account details revealed after completion',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `warranty_end` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `listing_id` (`listing_id`),
  KEY `buyer_id` (`buyer_id`),
  KEY `seller_id` (`seller_id`),
  CONSTRAINT `pur_listing_fk` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`),
  CONSTRAINT `pur_buyer_fk` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`),
  CONSTRAINT `pur_seller_fk` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: chats
-- ============================================================
CREATE TABLE IF NOT EXISTS `chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `status` enum('pending','active','completed','expired','cancelled','extended') DEFAULT 'pending',
  `buyer_joined` tinyint(1) DEFAULT 0,
  `seller_joined` tinyint(1) DEFAULT 0,
  `admin_joined` tinyint(1) DEFAULT 0,
  `activated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `chat_purchase_fk` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: messages
-- ============================================================
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message_type` enum('text','image','video','link','system') DEFAULT 'text',
  `content` text,
  `image_path` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `chat_id` (`chat_id`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `msg_chat_fk` FOREIGN KEY (`chat_id`) REFERENCES `chats` (`id`),
  CONSTRAINT `msg_user_fk` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: chat_actions
-- ============================================================
CREATE TABLE IF NOT EXISTS `chat_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` enum('complete_by_buyer','complete_by_seller','complete_by_admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_action` (`chat_id`,`action`),
  CONSTRAINT `ca_chat_fk` FOREIGN KEY (`chat_id`) REFERENCES `chats` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: notifications
-- ============================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notif_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: transactions
-- ============================================================
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdraw','hold','release','commission','refund') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance_before` decimal(10,2) NOT NULL,
  `balance_after` decimal(10,2) NOT NULL,
  `reference_id` int(11) DEFAULT 0,
  `note` varchar(255) DEFAULT '',
  `status` enum('pending','completed','cancelled') DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tx_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: payment_methods
-- ============================================================
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fa-credit-card',
  `type` enum('deposit','withdraw','both') DEFAULT 'both',
  `fee_percent` decimal(5,2) DEFAULT 0.00,
  `fee_fixed` decimal(10,2) DEFAULT 0.00,
  `min_amount` decimal(10,2) DEFAULT 1.00,
  `max_amount` decimal(10,2) DEFAULT 10000.00,
  `instructions` text,
  `account_info` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payment_methods` (`name`, `name_ar`, `icon`, `type`, `fee_percent`, `fee_fixed`, `min_amount`, `max_amount`, `instructions`, `account_info`, `is_active`, `sort_order`) VALUES
-- إيداع USDT 4 شبكات
('USDT ERC20', 'USDT - إيثريوم (ERC20)', 'fa-ethereum', 'deposit', 1.00, 0.00, 10.00, 50000.00, 'أرسل USDT على شبكة Ethereum (ERC20) وأرفق هاش العملية وصورة التأكيد.', '0xYourEthereumAddressHere', 1, 1),
('USDT BEP20', 'USDT - بينانس (BEP20)', 'fa-coins', 'deposit', 1.00, 0.00, 5.00, 50000.00, 'أرسل USDT على شبكة BEP20 وأرفق هاش العملية وصورة التأكيد.', '0xYourBNBAddressHere', 1, 2),
('USDT TRC20', 'USDT - ترون (TRC20)', 'fa-coins', 'deposit', 1.00, 0.00, 5.00, 50000.00, 'أرسل USDT على شبكة TRC20 وأرفق هاش العملية وصورة التأكيد.', 'TYourTronAddressHere', 1, 3),
('USDT POLYGON', 'USDT - بوليجون (POLYGON)', 'fa-coins', 'deposit', 1.00, 0.00, 5.00, 50000.00, 'أرسل USDT على شبكة Polygon وأرفق هاش العملية وصورة التأكيد.', '0xYourPolygonAddressHere', 1, 4),
-- سحب USDT 4 شبكات + Binance ID
('سحب USDT ERC20', 'سحب USDT - إيثريوم (ERC20)', 'fa-ethereum', 'withdraw', 1.00, 0.00, 10.00, 50000.00, 'أدخل عنوان محفظة ERC20 لاستلام USDT.', '', 1, 5),
('سحب USDT BEP20', 'سحب USDT - بينانس (BEP20)', 'fa-coins', 'withdraw', 1.00, 0.00, 5.00, 50000.00, 'أدخل عنوان محفظة BEP20 لاستلام USDT.', '', 1, 6),
('سحب USDT TRC20', 'سحب USDT - ترون (TRC20)', 'fa-coins', 'withdraw', 1.00, 0.00, 5.00, 50000.00, 'أدخل عنوان محفظة TRC20 لاستلام USDT.', '', 1, 7),
('سحب USDT POLYGON', 'سحب USDT - بوليجون (POLYGON)', 'fa-coins', 'withdraw', 1.00, 0.00, 5.00, 50000.00, 'أدخل عنوان محفظة Polygon لاستلام USDT.', '', 1, 8),
('Binance ID', 'سحب عبر Binance ID', 'fa-bitcoin', 'withdraw', 0.00, 0.00, 5.00, 50000.00, 'أدخل Binance ID الخاص بك لاستلام المبلغ مباشرةً.', '', 1, 9);

-- ============================================================
-- TABLE: payment_requests
-- ============================================================
CREATE TABLE IF NOT EXISTS `payment_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `method_id` int(11) NOT NULL,
  `type` enum('deposit','withdraw') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) DEFAULT 0.00,
  `net_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `user_account` varchar(255) DEFAULT NULL,
  `proof_image` varchar(255) DEFAULT NULL,
  `admin_note` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `method_id` (`method_id`),
  CONSTRAINT `pr_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `pr_method_fk` FOREIGN KEY (`method_id`) REFERENCES `payment_methods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: site_settings
-- ============================================================
CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('commission_rate', '5'),
('chat_duration_hours', '2'),
('max_listings_per_day', '10'),
('site_name', 'TradeVault'),
('withdraw_hold_hours', '24'),
('terms_content', 'يُرجى الالتزام بقواعد المنصة وعدم المشاركة في أي عمليات احتيال.'),
('how_it_works', '1. سجّل وأضف رصيداً.\n2. اختر الحساب المناسب واشترِه فوراً.\n3. ستظهر بيانات الحساب مباشرة بعد إتمام الصفقة.'),
('ad_default_duration', '30'),
('ad_daily_limit', '2'),
('ad_base_price', '5'),
('fee_deposit_eth', '1'),
('fee_deposit_bnb', '1'),
('fee_deposit_trc20', '1'),
('fee_deposit_polygon', '1'),
('fee_withdraw_eth', '1'),
('fee_withdraw_bnb', '1'),
('fee_withdraw_trc20', '1'),
('fee_withdraw_polygon', '1'),
('fee_withdraw_binance_id', '0'),
('fee_sell', '5'),
('deposit_days', '1'),
('withdraw_days', '2'),
('reserve_days', '2'),
('admin_max_rooms', '20');

-- ============================================================
-- TABLE: ad_types (35 pre-seeded ad types)
-- ============================================================
CREATE TABLE IF NOT EXISTS `ad_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ad_types` (`name`) VALUES
('حساب تليجرام'),('قناة تليجرام'),('مجموعة تليجرام'),('صفحة فيسبوك'),('مجموعة فيسبوك'),
('حساب فيسبوك'),('حساب انستقرام'),('صفحة انستقرام'),('حساب تيك توك'),('صفحة تيك توك'),
('قناة يوتيوب'),('فيديو يوتيوب'),('حساب تويتر (X)'),('حساب سناب شات'),
('حساب كلاش أوف كلانس'),('حساب كلاش رويال'),('حساب ببجي موبايل'),('حساب فري فاير'),
('حساب فورتنايت'),('حساب ماين كرافت'),('حساب ليج أوف ليجندز'),('حساب دوتا 2'),
('حساب فالورانت'),('حساب روبلوكس'),('حساب ستيوم'),('حساب إيبك غيمز'),
('حساب بلاي ستيشن'),('حساب إكس بوكس'),('حساب نينتندو'),('رابط موقع شخصي'),
('حساب Hay Day'),('حساب Mobile Legends'),('حساب Call of Duty Mobile'),
('حساب Brawl Stars'),('حساب Genshin Impact');

-- ============================================================
-- TABLE: ads
-- ============================================================
CREATE TABLE IF NOT EXISTS `ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ad_type_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `duration` int(11) NOT NULL DEFAULT 30,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('pending','active','expired','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ad_type_id` (`ad_type_id`),
  CONSTRAINT `ads_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ads_type_fk` FOREIGN KEY (`ad_type_id`) REFERENCES `ad_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- ============================================================
-- SETUP NOTES:
-- 1. Import this file via phpMyAdmin into: if0_41256124_buy_sell
-- 2. Upload all PHP files to your hosting root
-- 3. Admin login: username=admin, password=admin123
-- 4. Update payment method account info in Admin → المدفوعات
-- ============================================================

-- ============================================================
-- SCHEMA UPDATE v3 — TradeVault Admin Enhancements
-- ============================================================

-- Phone whitelist table for controlling user registration
CREATE TABLE IF NOT EXISTS `phone_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(30) NOT NULL,
  `note` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone_unique` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Extend payment_methods with extra commission columns
ALTER TABLE `payment_methods` ADD COLUMN IF NOT EXISTS `fee_percent` DECIMAL(5,2) DEFAULT 0.00;
ALTER TABLE `payment_methods` ADD COLUMN IF NOT EXISTS `instructions` TEXT;

-- Extend ad_types with price & duration
ALTER TABLE `ad_types` ADD COLUMN IF NOT EXISTS `price` DECIMAL(10,2) DEFAULT 0.00;
ALTER TABLE `ad_types` ADD COLUMN IF NOT EXISTS `duration` INT DEFAULT 30;

-- New site settings for v3
INSERT IGNORE INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('deposit_fee_pct', '0'),
('withdrawal_fee_pct', '0'),
('min_deposit', '5'),
('max_deposit', '50000'),
('min_withdrawal', '10'),
('max_withdrawal', '10000'),
('phone_whitelist_enabled', '0');

-- ============================================================
-- TABLE: activity_log (سجل النشاطات — v5)
-- ============================================================
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_type` enum('deal','finance','user','security','system','kyc','settings','broadcast','admin') DEFAULT 'system',
  `actor_id` int(11) DEFAULT NULL,
  `actor_name` varchar(100) DEFAULT NULL,
  `actor_role` enum('admin','user','system') DEFAULT 'system',
  `description` text NOT NULL,
  `ref_table` varchar(50) DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `action_type` (`action_type`),
  KEY `actor_id` (`actor_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
