<?php
function ensureReferralCode(PDO $pdo, int $userId): string {
    $row = $pdo->prepare("SELECT referral_code FROM users WHERE id=?");
    $row->execute([$userId]);
    $code = $row->fetchColumn();
    if ($code) return (string)$code;
    do {
        $code = strtoupper(substr(md5($userId . uniqid()), 0, 8));
        $chk  = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referral_code=?");
        $chk->execute([$code]);
    } while ($chk->fetchColumn() > 0);
    $pdo->prepare("UPDATE users SET referral_code=? WHERE id=?")->execute([$code, $userId]);
    return $code;
}

function getActiveContest(PDO $pdo): ?array {
    $s = $pdo->query("SELECT * FROM contests WHERE status='active' ORDER BY start_date DESC LIMIT 1");
    $c = $s->fetch(PDO::FETCH_ASSOC);
    return $c ?: null;
}

function getReferralCount(PDO $pdo, int $userId, ?int $contestId = null): int {
    if ($contestId) {
        $s = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id=? AND contest_id=?");
        $s->execute([$userId, $contestId]);
    } else {
        $s = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id=?");
        $s->execute([$userId]);
    }
    return (int)$s->fetchColumn();
}

function getUserContestRank(PDO $pdo, int $userId, int $contestId): ?int {
    $s = $pdo->prepare("SELECT referrer_id, COUNT(*) AS cnt FROM referrals WHERE contest_id=? GROUP BY referrer_id ORDER BY cnt DESC");
    $s->execute([$contestId]);
    foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $i => $row) {
        if ((int)$row['referrer_id'] === $userId) return $i + 1;
    }
    return null;
}

function getContestLeaderboard(PDO $pdo, int $contestId, int $top = 5): array {
    $s = $pdo->prepare("SELECT u.id, u.username, u.profile_pic, COUNT(r.id) AS cnt FROM referrals r JOIN users u ON u.id=r.referrer_id WHERE r.contest_id=? GROUP BY r.referrer_id ORDER BY cnt DESC LIMIT " . (int)$top);
    $s->execute([$contestId]);
    return $s->fetchAll(PDO::FETCH_ASSOC);
}

function calcContestWinners(PDO $pdo, int $contestId): bool {
    $top     = (int)getSetting($pdo, 'contest_top_n', 5);
    $leaders = getContestLeaderboard($pdo, $contestId, $top);
    $pdo->prepare("UPDATE contests SET status='ended', winners_calculated=1 WHERE id=?")->execute([$contestId]);
    if (empty($leaders)) return false;
    $pdo->prepare("DELETE FROM contest_results WHERE contest_id=?")->execute([$contestId]);
    $ins = $pdo->prepare("INSERT INTO contest_results (contest_id,user_id,rank_pos,referral_count) VALUES (?,?,?,?)");
    foreach ($leaders as $i => $row) {
        $ins->execute([$contestId, $row['id'], $i + 1, $row['cnt']]);
        addNotif($pdo, (int)$row['id'], 'contest', '🏆 تهانينا! أنت في المرتبة ' . ($i + 1) . ' في مسابقة الإحالة!');
    }
    return true;
}

function registerReferral(PDO $pdo, int $newUserId, string $refCode): bool {
    if (!$refCode) return false;
    $s = $pdo->prepare("SELECT id FROM users WHERE referral_code=? AND id != ?");
    $s->execute([$refCode, $newUserId]);
    $referrerId = $s->fetchColumn();
    if (!$referrerId) return false;
    $pdo->prepare("UPDATE users SET referred_by=? WHERE id=?")->execute([$referrerId, $newUserId]);
    try { $contest = getActiveContest($pdo); } catch(Exception $e){ $contest = null; }
    $cid = $contest ? $contest['id'] : null;
    try {
        $pdo->prepare("INSERT INTO referrals (referrer_id,referred_id,contest_id) VALUES (?,?,?)")->execute([$referrerId, $newUserId, $cid]);
    } catch (Exception $e) { return false; }
    addNotif($pdo, (int)$referrerId, 'referral', '✅ انضم مستخدم جديد عبر رابط إحالتك!');
    return true;
}
