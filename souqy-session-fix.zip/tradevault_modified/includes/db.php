<?php
// ═══════════════════════════════════════════════════════
//  إعدادات الجلسة — متوافقة مع واتساب وتيليغرام
// ═══════════════════════════════════════════════════════

if (session_status() === PHP_SESSION_NONE) {

    // اسم جلسة موحّد لجميع المتصفحات (بما فيها واتساب وتيليغرام)
    session_name('SOUQY_SID');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        // secure=true فقط على HTTPS (InfinityFree يستخدم HTTPS دائماً)
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        // Lax: يرسل الكوكي مع GET redirects ومع forms نفس الدومين
        // ✅ يعمل مع واتساب وتيليغرام لأن الطلبات same-site
        // ❌ None يحتاج Secure=true دائماً وإلا يُرفض من Chrome 80+
        'samesite' => 'Lax',
    ]);

    session_start();
}

// ── Headers متوافقة مع واتساب وتيليغرام ──────────────
if (!headers_sent()) {
    // ❌ حذف X-Frame-Options: SAMEORIGIN — يسبب ERR_HTTP_RESPONSE_CODE_FAILURE
    //    في متصفحات تيليغرام/واتساب المدمجة (تُعامَل كـ cross-origin frame)

    // ❌ حذف Content-Security-Policy: upgrade-insecure-requests
    //    يسبب redirect loops على InfinityFree المجاني

    // ✅ فقط هذه الـ header الآمنة
    header('X-Content-Type-Options: nosniff');
    header('Permissions-Policy: interest-cohort=()');

    // منع التخزين المؤقت لصفحات الـ PHP (يمنع عرض صفحة قديمة بعد logout)
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

// ═══════════════════════════════════════════════════════
//  CONFIG — بيانات قاعدة البيانات
// ═══════════════════════════════════════════════════════
define('DB_HOST', 'sql204.infinityfree.com');
define('DB_USER', 'if0_41320552');
define('DB_PASS', 'ZzXxAa123');
define('DB_NAME', 'if0_41320552_suogy');
define('DB_PORT', 3306);

// بيانات الأدمن الافتراضية (تُستخدم عند أول تثبيت فقط)
define('ADMIN_USERNAME', 'admin');
define('ADMIN_EMAIL',    'admin@souqy.com');
define('ADMIN_PASS',     'admin123');

// ─── CONNECT ──────────────────────────────────────────
try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES=>false]
    );
} catch(Exception $e){
    // InfinityFree لا يسمح بـ CREATE DATABASE — نعرض رسالة خطأ واضحة مباشرةً
    die('<div style="font-family:Cairo,sans-serif;direction:rtl;padding:40px;color:#ef4444;background:#07080b;min-height:100vh"><h2 style="color:#f0b429">خطأ في الاتصال بقاعدة البيانات</h2><p>تعذّر الاتصال. تحقق من بيانات الاتصال في ملف includes/db.php</p><small style="color:#888">' . $e->getMessage() . '</small></div>');
}

// ─── AUTO INSTALL ─────────────────────────────────────
function installDB(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        unique_id VARCHAR(20) UNIQUE DEFAULT NULL,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20),
        phone_country_code VARCHAR(5) DEFAULT '+20',
        phone_country_flag VARCHAR(10) DEFAULT '🇪🇬',
        password VARCHAR(255) NOT NULL,
        profile_pic VARCHAR(255) DEFAULT NULL,
        balance DECIMAL(10,2) DEFAULT 0.00,
        held_balance DECIMAL(10,2) DEFAULT 0.00,
        kyc_status ENUM('not_submitted','pending','approved','rejected') DEFAULT 'not_submitted',
        seller_rating INT DEFAULT 0,
        buyer_rating INT DEFAULT 0,
        total_sales INT DEFAULT 0,
        total_purchases INT DEFAULT 0,
        is_admin TINYINT(1) DEFAULT 0,
        is_banned TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS kyc_documents (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        id_card_image VARCHAR(255), selfie_image VARCHAR(255),
        full_name VARCHAR(100), id_number VARCHAR(50),
        date_of_birth DATE, address TEXT,
        status ENUM('pending','approved','rejected') DEFAULT 'pending',
        admin_notes TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        reviewed_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL, name_ar VARCHAR(100),
        icon VARCHAR(50) DEFAULT 'fa-tag',
        category_type ENUM('games','social','other') DEFAULT 'other',
        description TEXT, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS listings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL, category_id INT NOT NULL,
        title VARCHAR(255) NOT NULL, description TEXT,
        price DECIMAL(10,2) NOT NULL, quantity INT DEFAULT 1,
        status ENUM('active','pending_sale','sold','expired','disabled') DEFAULT 'active',
        added_by ENUM('admin','user') DEFAULT 'user',
        views INT DEFAULT 0, account_details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, expires_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS listing_images (
        id INT PRIMARY KEY AUTO_INCREMENT, listing_id INT NOT NULL,
        image_path VARCHAR(255) NOT NULL, is_video TINYINT(1) DEFAULT 0, sort_order INT DEFAULT 0,
        FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS purchases (
        id INT PRIMARY KEY AUTO_INCREMENT,
        listing_id INT NOT NULL, buyer_id INT NOT NULL, seller_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL, commission DECIMAL(10,2) NOT NULL DEFAULT 0,
        seller_net DECIMAL(10,2) NOT NULL,
        status ENUM('held','completed','refunded','disputed') DEFAULT 'held',
        account_details_shown TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        warranty_end TIMESTAMP, completed_at TIMESTAMP NULL,
        FOREIGN KEY (listing_id) REFERENCES listings(id),
        FOREIGN KEY (buyer_id) REFERENCES users(id),
        FOREIGN KEY (seller_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS chats (
        id INT PRIMARY KEY AUTO_INCREMENT,
        purchase_id INT UNIQUE NOT NULL,
        status ENUM('pending','active','completed','expired','cancelled','extended') DEFAULT 'pending',
        buyer_joined TINYINT(1) DEFAULT 0, seller_joined TINYINT(1) DEFAULT 0,
        admin_joined TINYINT(1) DEFAULT 0,
        activated_at TIMESTAMP NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, expires_at TIMESTAMP NULL,
        FOREIGN KEY (purchase_id) REFERENCES purchases(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    try { $pdo->exec("ALTER TABLE chats ADD COLUMN buyer_joined TINYINT(1) DEFAULT 0"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN seller_joined TINYINT(1) DEFAULT 0"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN admin_joined TINYINT(1) DEFAULT 0"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN activated_at TIMESTAMP NULL"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats MODIFY COLUMN status ENUM('pending','active','completed','expired','cancelled','extended') DEFAULT 'pending'"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats MODIFY COLUMN purchase_id INT NULL"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN auction_id INT NULL"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN winner_id INT NULL"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN seller_id2 INT NULL"); } catch(Exception $e){}
    try { $pdo->exec("ALTER TABLE chats ADD COLUMN winner_joined TINYINT(1) DEFAULT 0"); } catch(Exception $e){}

    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        chat_id INT NOT NULL, sender_id INT NOT NULL,
        message_type ENUM('text','image','video','link','system') DEFAULT 'text',
        content TEXT, image_path VARCHAR(255) NULL, is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (chat_id) REFERENCES chats(id),
        FOREIGN KEY (sender_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    try { $pdo->exec("ALTER TABLE messages MODIFY COLUMN message_type ENUM('text','image','video','link','system') DEFAULT 'text'"); } catch(Exception $e){}

    $pdo->exec("CREATE TABLE IF NOT EXISTS chat_actions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        chat_id INT NOT NULL, user_id INT NOT NULL,
        action ENUM('complete_by_buyer','complete_by_seller','complete_by_admin') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_action (chat_id, action),
        FOREIGN KEY (chat_id) REFERENCES chats(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL,
        type VARCHAR(50) NOT NULL, message TEXT NOT NULL,
        link VARCHAR(255) DEFAULT '', is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL,
        type ENUM('deposit','withdraw','hold','release','commission','refund') NOT NULL,
        amount DECIMAL(10,2) NOT NULL, balance_before DECIMAL(10,2) NOT NULL,
        balance_after DECIMAL(10,2) NOT NULL, reference_id INT DEFAULT 0,
        note VARCHAR(255) DEFAULT '', status ENUM('pending','completed','cancelled') DEFAULT 'completed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_methods (
        id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, name_ar VARCHAR(100),
        icon VARCHAR(50) DEFAULT 'fa-credit-card',
        type ENUM('deposit','withdraw','both') DEFAULT 'both',
        fee_percent DECIMAL(5,2) DEFAULT 0.00, fee_fixed DECIMAL(10,2) DEFAULT 0.00,
        min_amount DECIMAL(10,2) DEFAULT 1.00, max_amount DECIMAL(10,2) DEFAULT 10000.00,
        instructions TEXT, account_info VARCHAR(255),
        is_active TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_requests (
        id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL, method_id INT NOT NULL,
        type ENUM('deposit','withdraw') NOT NULL, amount DECIMAL(10,2) NOT NULL,
        fee DECIMAL(10,2) DEFAULT 0.00, net_amount DECIMAL(10,2) NOT NULL,
        status ENUM('pending','approved','rejected') DEFAULT 'pending',
        user_account VARCHAR(255), proof_image VARCHAR(255),
        tx_hash VARCHAR(255) DEFAULT NULL, network VARCHAR(50) DEFAULT NULL,
        admin_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, processed_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (method_id) REFERENCES payment_methods(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        setting_key VARCHAR(50) UNIQUE NOT NULL, setting_value TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS ad_types (
        id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL,
        icon VARCHAR(100) DEFAULT NULL, price DECIMAL(10,2) DEFAULT 0.00,
        status ENUM('active','inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS ads (
        id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL, ad_type_id INT NOT NULL,
        title VARCHAR(255) DEFAULT NULL, content TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL DEFAULT 0.00, duration INT NOT NULL DEFAULT 30,
        start_date DATE NULL, end_date DATE NULL,
        status ENUM('pending','active','expired','rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (ad_type_id) REFERENCES ad_types(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // ═══ SEED DATA ═══
    $ins=$pdo->prepare("INSERT IGNORE INTO site_settings(setting_key,setting_value)VALUES(?,?)");
    foreach([
        ['commission_rate','5'],['chat_duration_hours','2'],['max_listings_per_day','10'],
        ['site_name','سوقي'],['site_url',''],['withdraw_hold_hours','24'],
        ['terms_content','يُرجى الالتزام بقواعد المنصة وعدم المشاركة في أي عمليات احتيال.'],
        ['how_it_works','1. سجّل وأضف رصيداً.\n2. اختر الحساب المناسب واشترِه فوراً.\n3. ستظهر بيانات الحساب مباشرة بعد إتمام الصفقة.'],
        ['ad_default_duration','30'],['ad_daily_limit','2'],['ad_base_price','5'],
        ['fee_deposit_eth','1'],['fee_deposit_bnb','1'],['fee_deposit_trc20','1'],['fee_deposit_polygon','1'],
        ['fee_withdraw_eth','1'],['fee_withdraw_bnb','1'],['fee_withdraw_trc20','1'],['fee_withdraw_polygon','1'],
        ['fee_withdraw_binance_id','0'],
        ['fee_sell','5'],['deposit_days','1'],['withdraw_days','2'],['reserve_days','2'],
        ['admin_max_rooms','20'],
    ] as $d) $ins->execute($d);

    // طرق الدفع
    $pm=$pdo->prepare("INSERT IGNORE INTO payment_methods(name,name_ar,icon,type,fee_percent,fee_fixed,min_amount,max_amount,instructions,account_info,is_active,sort_order)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach([
        ['USDT ERC20','USDT - إيثريوم (ERC20)','fa-ethereum','deposit',1,0,10,50000,'أرسل USDT على شبكة Ethereum (ERC20) وأرفق هاش العملية وصورة التأكيد.','0xYourEthereumAddressHere',1,1],
        ['USDT BEP20','USDT - بينانس (BEP20)','fa-coins','deposit',1,0,5,50000,'أرسل USDT على شبكة BEP20 وأرفق هاش العملية وصورة التأكيد.','0xYourBNBAddressHere',1,2],
        ['USDT TRC20','USDT - ترون (TRC20)','fa-coins','deposit',1,0,5,50000,'أرسل USDT على شبكة TRC20 وأرفق هاش العملية وصورة التأكيد.','TYourTronAddressHere',1,3],
        ['USDT POLYGON','USDT - بوليجون (POLYGON)','fa-coins','deposit',1,0,5,50000,'أرسل USDT على شبكة Polygon وأرفق هاش العملية وصورة التأكيد.','0xYourPolygonAddressHere',1,4],
        ['سحب USDT ERC20','سحب USDT - إيثريوم (ERC20)','fa-ethereum','withdraw',1,0,10,50000,'أدخل عنوان محفظة ERC20 لاستلام USDT.','',1,5],
        ['سحب USDT BEP20','سحب USDT - بينانس (BEP20)','fa-coins','withdraw',1,0,5,50000,'أدخل عنوان محفظة BEP20 لاستلام USDT.','',1,6],
        ['سحب USDT TRC20','سحب USDT - ترون (TRC20)','fa-coins','withdraw',1,0,5,50000,'أدخل عنوان محفظة TRC20 لاستلام USDT.','',1,7],
        ['سحب USDT POLYGON','سحب USDT - بوليجون (POLYGON)','fa-coins','withdraw',1,0,5,50000,'أدخل عنوان محفظة Polygon لاستلام USDT.','',1,8],
        ['Binance ID','سحب عبر Binance ID','fa-bitcoin','withdraw',0,0,5,50000,'أدخل Binance ID الخاص بك لاستلام المبلغ مباشرةً.','',1,9],
    ] as $m) $pm->execute($m);

    try { $pdo->exec("ALTER TABLE payment_requests ADD COLUMN tx_hash VARCHAR(255) DEFAULT NULL"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE payment_requests ADD COLUMN network VARCHAR(50) DEFAULT NULL"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN unique_id VARCHAR(20) DEFAULT NULL"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD UNIQUE INDEX idx_unique_id (unique_id)"); } catch(Exception $e) {}

    // 34 categories
    $ic=$pdo->prepare("INSERT IGNORE INTO categories(name,name_ar,icon,category_type,sort_order)VALUES(?,?,?,?,?)");
    foreach([
        ['Clash of Clans','كلاش أوف كلانس','fa-shield-alt','games',1],['Clash Royale','كلاش رويال','fa-crown','games',2],
        ['PUBG Mobile','ببجي موبايل','fa-crosshairs','games',3],['Free Fire','فري فاير','fa-fire','games',4],
        ['Call of Duty Mobile','كول أوف ديوتي موبايل','fa-gun','games',5],['Fortnite','فورتنايت','fa-gamepad','games',6],
        ['League of Legends','ليغ أوف ليجيندز','fa-chess','games',7],['Valorant','فالورانت','fa-bullseye','games',8],
        ['Minecraft','ماين كرافت','fa-cube','games',9],['Hay Day','هاي داي','fa-leaf','games',10],
        ['PUBG Lite','ببجي لايت','fa-crosshairs','games',11],['Roblox','روبلوكس','fa-robot','games',12],
        ['eFootball / PES','بيس / إيفوتبول','fa-futbol','games',13],['FIFA Mobile','فيفا موبايل','fa-futbol','games',14],
        ['Genshin Impact','جينشن إمباكت','fa-star','games',15],['GTA V Online','جراند ثفت أوتو','fa-car','games',16],
        ['Arena of Valor','أرينا أوف فالور','fa-trophy','games',17],['Mobile Legends','موبايل ليجيندز','fa-dragon','games',18],
        ['World of Warcraft','ورلد أوف ووركرافت','fa-dungeon','games',19],['Red Dead Redemption 2','ريد ديد ريدمبشن','fa-hat-cowboy','games',20],
        ['Telegram Channels','قنوات تيليجرام','fa-paper-plane','social',21],['YouTube Channels','قنوات يوتيوب','fa-youtube','social',22],
        ['Facebook Pages','صفحات فيسبوك','fa-facebook','social',23],['Instagram Accounts','حسابات إنستغرام','fa-instagram','social',24],
        ['Twitter / X','حسابات تويتر/X','fa-x-twitter','social',25],['TikTok Accounts','حسابات تيك توك','fa-tiktok','social',26],
        ['Snapchat Accounts','حسابات سناب شات','fa-ghost','social',27],
        ['Gmail Accounts','حسابات جيميل','fa-envelope','other',28],['Microsoft Accounts','حسابات مايكروسوفت','fa-windows','other',29],
        ['Netflix Accounts','حسابات نتفليكس','fa-film','other',30],['Spotify Premium','سبوتيفاي بريميوم','fa-music','other',31],
        ['PayPal Accounts','حسابات باي بال','fa-paypal','other',32],['Amazon Accounts','حسابات أمازون','fa-amazon','other',33],
        ['WhatsApp / Viber','واتساب / فايبر','fa-whatsapp','other',34],
    ] as $c) $ic->execute($c);

    $iat=$pdo->prepare("INSERT IGNORE INTO ad_types(name)VALUES(?)");
    foreach([['حساب تليجرام'],['قناة تليجرام'],['مجموعة تليجرام'],['صفحة فيسبوك'],['مجموعة فيسبوك'],['حساب فيسبوك'],['حساب انستقرام'],['صفحة انستقرام'],['حساب تيك توك'],['صفحة تيك توك'],['قناة يوتيوب'],['فيديو يوتيوب'],['حساب تويتر (X)'],['حساب سناب شات'],['حساب كلاش أوف كلانس'],['حساب كلاش رويال'],['حساب ببجي موبايل'],['حساب فري فاير'],['حساب فورتنايت'],['حساب ماين كرافت'],['حساب ليج أوف ليجندز'],['حساب دوتا 2'],['حساب فالورانت'],['حساب روبلوكس'],['حساب ستيوم'],['حساب إيبك غيمز'],['حساب بلاي ستيشن'],['حساب إكس بوكس'],['حساب نينتندو'],['رابط موقع شخصي'],['حساب Hay Day'],['حساب Mobile Legends'],['حساب Call of Duty Mobile'],['حساب Brawl Stars'],['حساب Genshin Impact']] as $row) $iat->execute($row);

    if(!$pdo->query("SELECT id FROM users WHERE is_admin=1 LIMIT 1")->fetch()){
        $adminUid = 'TV' . strtoupper(substr(bin2hex(random_bytes(4)),0,8));
        $pdo->prepare("INSERT INTO users(unique_id,username,email,password,kyc_status,is_admin,balance)VALUES(?,?,?,?,?,?,?)")
            ->execute([$adminUid, ADMIN_USERNAME, ADMIN_EMAIL, ADMIN_PASS, 'approved', 1, 0]);
    }
}

// Run install
try { $pdo->query("SELECT 1 FROM site_settings LIMIT 1"); } catch(Exception $e){ installDB($pdo); }
try { $pdo->query("SELECT 1 FROM ad_types LIMIT 1"); } catch(Exception $e){ installDB($pdo); }

// ✅ ضمان وجود الأدمن في كل طلب — يحل مشكلة InfinityFree
// حتى لو الجداول موجودة من قبل وinstallDB ما اشتغلتش
try {
    if(!(int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_admin=1")->fetchColumn()){
        $au = 'TV'.strtoupper(substr(bin2hex(random_bytes(4)),0,8));
        $pdo->prepare("INSERT INTO users(unique_id,username,email,password,kyc_status,is_admin,balance)VALUES(?,?,?,?,?,?,?)")
            ->execute([$au, ADMIN_USERNAME, ADMIN_EMAIL, ADMIN_PASS, 'approved', 1, 0]);
    }
} catch(Exception $e){}

// Runtime migrations
try { $pdo->exec("ALTER TABLE payment_requests ADD COLUMN tx_hash VARCHAR(255) DEFAULT NULL"); } catch(Exception $e) {}
try { $pdo->exec("ALTER TABLE payment_requests ADD COLUMN network VARCHAR(50) DEFAULT NULL"); } catch(Exception $e) {}
try { $pdo->exec("ALTER TABLE users ADD COLUMN unique_id VARCHAR(20) DEFAULT NULL"); } catch(Exception $e) {}
try { $pdo->exec("ALTER TABLE users ADD UNIQUE INDEX idx_unique_id (unique_id)"); } catch(Exception $e) {}

// ─── country_codes migration ──────────────────────────
try { $pdo->exec("CREATE TABLE IF NOT EXISTS country_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    country_name VARCHAR(100) NOT NULL,
    country_name_ar VARCHAR(100),
    phone_code VARCHAR(10) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch(Exception $e){}
try {
    if(!(int)$pdo->query("SELECT COUNT(*) FROM country_codes")->fetchColumn()){
        $icc=$pdo->prepare("INSERT IGNORE INTO country_codes(country_name,country_name_ar,phone_code,sort_order)VALUES(?,?,?,?)");
        $ccdata=[['Egypt','مصر','+20',1],['Saudi Arabia','السعودية','+966',2],
            ['UAE','الإمارات','+971',3],['Jordan','الأردن','+962',4],
            ['Lebanon','لبنان','+961',5],['Syria','سوريا','+963',6],
            ['Iraq','العراق','+964',7],['Morocco','المغرب','+212',8],
            ['Tunisia','تونس','+216',9],['Algeria','الجزائر','+213',10],
            ['Libya','ليبيا','+218',11],['Sudan','السودان','+249',12],
            ['Yemen','اليمن','+967',13],['Oman','عُمان','+968',14],
            ['Kuwait','الكويت','+965',15],['Qatar','قطر','+974',16],
            ['Bahrain','البحرين','+973',17],['Palestine','فلسطين','+970',18],
            ['Somalia','الصومال','+252',19],['Mauritania','موريتانيا','+222',20]];
        foreach($ccdata as $cc) $icc->execute($cc);
    }
} catch(Exception $e){}

// Create missing tables if they don't exist
try { $pdo->query("SELECT 1 FROM ads LIMIT 1"); } catch(Exception $e){
    $pdo->exec("CREATE TABLE IF NOT EXISTS ad_types (
        id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL,
        icon VARCHAR(100) DEFAULT NULL, price DECIMAL(10,2) DEFAULT 0.00,
        status ENUM('active','inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS ads (
        id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL, ad_type_id INT NOT NULL,
        title VARCHAR(255) DEFAULT NULL, content TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL DEFAULT 0.00, duration INT NOT NULL DEFAULT 30,
        start_date DATE NULL, end_date DATE NULL,
        status ENUM('pending','active','expired','rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (ad_type_id) REFERENCES ad_types(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// Seed missing settings
try {
    $is=$pdo->prepare("INSERT IGNORE INTO site_settings(setting_key,setting_value)VALUES(?,?)");
    foreach([['admin_max_rooms','20'],['fee_withdraw_binance_id','0'],['deposit_days','1'],['withdraw_days','2'],['reserve_days','2'],['fee_deposit_eth','1'],['fee_deposit_bnb','1'],['fee_deposit_trc20','1'],['fee_deposit_polygon','1'],['fee_withdraw_eth','1'],['fee_withdraw_bnb','1'],['fee_withdraw_trc20','1'],['fee_withdraw_polygon','1']] as $d) $is->execute($d);
} catch(Exception $e){}


// ─── activity_log table ───────────────────────────
try { $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    action_type VARCHAR(50) NOT NULL DEFAULT 'system',
    actor_id INT DEFAULT NULL,
    actor_name VARCHAR(100) DEFAULT NULL,
    actor_role ENUM('admin','user','system') DEFAULT 'system',
    description TEXT NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch(Exception $e){}
try { $pdo->exec("ALTER TABLE activity_log ADD INDEX idx_action_type (action_type)"); } catch(Exception $e){}
try { $pdo->exec("ALTER TABLE activity_log ADD INDEX idx_created_at (created_at)"); } catch(Exception $e){}

// ─── HELPERS ──────────────────────────────────────────
function uid(): int { return (int)($_SESSION['uid'] ?? 0); }

// ═══════════════════════════════════════════════════════════════════
//  AUTH CORE — كل التحقق يمر من هنا، لا مكان آخر
// ═══════════════════════════════════════════════════════════════════

/**
 * _sessionValid()
 * يتحقق من:
 *   1. وجود uid في الجلسة
 *   2. تطابق User-Agent hash (حماية ضد session hijacking)
 *   3. أن المستخدم لا يزال موجوداً في قاعدة البيانات وغير محظور
 */
function _sessionValid(): bool {
    // 1. لا توجد جلسة أصلاً
    if (empty($_SESSION['uid'])) return false;

    // ❌ تم حذف تحقق _ua_hash
    // السبب: واتساب وتيليغرام يغيّران User-Agent بين طلب وآخر (login → dashboard)
    // مما كان يجعل كل جلسة تُرفض فوراً بعد تسجيل الدخول

    // 2. تحقق من قاعدة البيانات — المستخدم موجود وغير محظور
    //    نخزّن النتيجة في الجلسة لمدة 5 دقائق لتجنّب استعلام DB في كل طلب
    $now = time();
    if (!isset($_SESSION['_db_check']) || ($now - $_SESSION['_db_check']) > 300) {
        global $pdo;
        try {
            $r = $pdo->query(
                "SELECT id, is_banned FROM users WHERE id=" . (int)$_SESSION['uid'] . " LIMIT 1"
            )->fetch();
            if (!$r) {
                session_unset(); session_destroy(); return false;
            }
            if ((int)$r['is_banned'] === 1) {
                session_unset(); session_destroy(); return false;
            }
            $_SESSION['_db_check'] = $now;
        } catch (Exception $e) {
            // إذا فشل الاستعلام مؤقتاً، نقبل الجلسة بدلاً من طرد المستخدم
            // (تجنباً لـ logout عشوائي بسبب انقطاع DB مؤقت)
            if (isset($_SESSION['_db_check'])) return true;
            return false;
        }
    }

    return true;
}

function isLoggedIn(): bool { return _sessionValid(); }

// ✅ isAdmin — يستعلم من DB مباشرة، ما يعتمدش على الـ session وحدها
function isAdmin(): bool {
    if (!isLoggedIn()) return false;
    global $pdo;
    try {
        $r = $pdo->query("SELECT is_admin FROM users WHERE id=" . uid() . " LIMIT 1")->fetch();
        return $r && (int)$r['is_admin'] === 1;
    } catch (Exception $e) { return false; }
}

/**
 * requireLogin()
 * حماية الصفحات الداخلية (pages/)
 * إذا لم يكن المستخدم مسجلاً → يُوجَّه لصفحة تسجيل الدخول
 * إذا كان admin → يُوجَّه للوحة الإدارة
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        // حفظ الصفحة المطلوبة للعودة إليها بعد تسجيل الدخول
        $current = $_SERVER['REQUEST_URI'] ?? '';
        if ($current && strpos($current, 'login') === false && strpos($current, 'register') === false) {
            $_SESSION['_redirect_after_login'] = $current;
        }
        header('Location: login.php', true, 302);
        exit;
    }
}

/**
 * requireAdmin()
 * حماية لوحة الإدارة (admin/)
 * يستعلم من DB مباشرة للتحقق من صلاحية الأدمن
 */
function requireAdmin(): void {
    global $pdo;
    if (!isLoggedIn()) { header('Location: login.php', true, 302); exit; }
    try {
        $r = $pdo->query("SELECT is_admin FROM users WHERE id=" . uid() . " LIMIT 1")->fetch();
        if ($r && (int)$r['is_admin'] === 1) return; // ✅ مسموح
    } catch (Exception $e) {}
    // ليس أدمن — اطرده للوحة المستخدم
    header('Location: ../pages/index.php', true, 302); exit;
}
function e($s) { return htmlspecialchars((string)($s??''),ENT_QUOTES,'UTF-8'); }
function money(float $n): string { return '$'.number_format($n,2); }
function timeAgo(string $dt): string {
    $d=time()-strtotime($dt);
    if($d<60) return 'الآن';
    if($d<3600) return floor($d/60).' د';
    if($d<86400) return floor($d/3600).' س';
    if($d<604800) return floor($d/86400).' يوم';
    return date('d/m/Y',strtotime($dt));
}
function getSetting(PDO $pdo,string $k,string $def=''): string {
    $s=$pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key=?");
    $s->execute([$k]); $r=$s->fetchColumn(); return $r!==false?$r:$def;
}
function saveSetting(PDO $pdo,string $k,string $v): void {
    $pdo->prepare("INSERT INTO site_settings(setting_key,setting_value)VALUES(?,?)ON DUPLICATE KEY UPDATE setting_value=?")->execute([$k,$v,$v]);
}
function getSiteName(PDO $pdo): string { return getSetting($pdo,'site_name','سوقي'); }
function getUnreadCount(PDO $pdo,int $uid): int {
    $s=$pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0");
    $s->execute([$uid]); return (int)$s->fetchColumn();
}
function addNotif(PDO $pdo,int $uid,string $type,string $msg,string $link=''): void {
    $pdo->prepare("INSERT INTO notifications(user_id,type,message,link)VALUES(?,?,?,?)")->execute([$uid,$type,$msg,$link]);
}

function addActivityLog(PDO $pdo, string $type, string $desc, ?int $actorId=null, string $role='user'): void {
    try {
        $name = null;
        if($actorId) {
            $r = $pdo->prepare("SELECT username FROM users WHERE id=?");
            $r->execute([$actorId]); $name = $r->fetchColumn()?:null;
        }
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $pdo->prepare("INSERT INTO activity_log(action_type,actor_id,actor_name,actor_role,description,ip_address)VALUES(?,?,?,?,?,?)")
            ->execute([$type,$actorId,$name,$role,$desc,$ip]);
    } catch(Exception $e){}
}

function addTx(PDO $pdo,int $uid,string $type,float $amt,float $bef,float $aft,int $ref=0,string $note=''): void {
    $pdo->prepare("INSERT INTO transactions(user_id,type,amount,balance_before,balance_after,reference_id,note)VALUES(?,?,?,?,?,?,?)")->execute([$uid,$type,$amt,$bef,$aft,$ref,$note]);
}
function getListingThumb(PDO $pdo,int $lid): string {
    $s=$pdo->prepare("SELECT image_path FROM listing_images WHERE listing_id=? ORDER BY sort_order LIMIT 1");
    $s->execute([$lid]); return $s->fetchColumn()?:'';
}
function generateUniqueId(PDO $pdo): string {
    do {
        $id = 'TV' . strtoupper(substr(bin2hex(random_bytes(4)),0,8));
        $ex = $pdo->prepare("SELECT COUNT(*) FROM users WHERE unique_id=?");
        $ex->execute([$id]);
    } while($ex->fetchColumn() > 0);
    return $id;
}
function ensureUniqueId(PDO $pdo, int $userId): string {
    $row = $pdo->prepare("SELECT unique_id FROM users WHERE id=?");
    $row->execute([$userId]);
    $uid = $row->fetchColumn();
    if(!$uid){
        $uid = generateUniqueId($pdo);
        $pdo->prepare("UPDATE users SET unique_id=? WHERE id=?")->execute([$uid, $userId]);
    }
    return $uid;
}
function getSiteUrl(): string {
    $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir   = dirname($_SERVER['SCRIPT_NAME'] ?? '');
    $dir   = rtrim($dir,'/');
    return $proto.'://'.$host.$dir;
}
function csrf(): string {
    if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrfField(): string { return '<input type="hidden" name="_csrf" value="'.csrf().'">'; }
function verifyCsrf(): bool { return isset($_POST['_csrf'])&&$_POST['_csrf']===($_SESSION['csrf']??''); }
function kycBadge(string $status): string {
    $m=['approved'=>'<span class="badge badge-ok"><i class="fas fa-check-circle"></i> موثق</span>',
        'pending'=>'<span class="badge badge-warn"><i class="fas fa-clock"></i> قيد المراجعة</span>',
        'rejected'=>'<span class="badge badge-err"><i class="fas fa-times-circle"></i> مرفوض</span>'];
    return isset($m[$status]) ? $m[$status] : '<span class="badge badge-gray"><i class="fas fa-user-slash"></i> غير موثق</span>';
}
function uploadFile(array $file,string $subdir): ?string {
    $allowed=['image/jpeg','image/png','image/gif','image/webp'];
    if($file['error']!==UPLOAD_ERR_OK||!in_array($file['type'],$allowed)||$file['size']>10*1024*1024) return null;
    $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
    $name=uniqid('',true).'.'.$ext;
    $absRoot=rtrim(dirname(dirname(__FILE__)),DIRECTORY_SEPARATOR);
    $absDir=$absRoot.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR.$subdir;
    if(!is_dir($absDir)) mkdir($absDir,0755,true);
    return move_uploaded_file($file['tmp_name'],$absDir.DIRECTORY_SEPARATOR.$name) ? 'uploads/'.$subdir.'/'.$name : null;
}
function uploadFileMedia(array $file, string $subdir): ?array {
    $allowedImg=['image/jpeg','image/png','image/gif','image/webp'];
    $allowedVid=['video/mp4','video/webm','video/quicktime','video/x-msvideo'];
    if($file['error']!==UPLOAD_ERR_OK||$file['size']>50*1024*1024) return null;
    $isVid=in_array($file['type'],$allowedVid);
    $isImg=in_array($file['type'],$allowedImg);
    if(!$isImg&&!$isVid) return null;
    $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
    $name=uniqid('',true).'.'.$ext;
    $absRoot=rtrim(dirname(dirname(__FILE__)),DIRECTORY_SEPARATOR);
    $absDir=$absRoot.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR.$subdir;
    if(!is_dir($absDir)) mkdir($absDir,0755,true);
    if(!move_uploaded_file($file['tmp_name'],$absDir.DIRECTORY_SEPARATOR.$name)) return null;
    return ['path'=>'uploads/'.$subdir.'/'.$name,'type'=>$isVid?'video':'image'];
}

// التحقق من كلمة المرور — نص عادي
function verifyPassword(string $input, string $stored): bool {
    return $input === $stored;
}
function hashPassword(string $pw): string { return $pw; }

function autoCleanupChats(PDO $pdo): void {
    $pending = $pdo->query("SELECT c.id, p.id purchase_id, p.buyer_id, p.amount, p.listing_id, p.seller_id
        FROM chats c JOIN purchases p ON c.purchase_id=p.id
        WHERE c.status='pending' AND c.created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchAll();
    foreach($pending as $ch) refundPurchase($pdo,(int)$ch['purchase_id'],(int)$ch['id'],'cancelled');
    $expired = $pdo->query("SELECT c.id, p.id purchase_id, p.buyer_id, p.amount, p.listing_id, p.seller_id
        FROM chats c JOIN purchases p ON c.purchase_id=p.id
        WHERE c.status='active' AND c.expires_at IS NOT NULL AND c.expires_at < NOW() AND p.status='held'")->fetchAll();
    foreach($expired as $ch) refundPurchase($pdo,(int)$ch['purchase_id'],(int)$ch['id'],'expired');
    try {
        $pdo->exec("DELETE FROM messages WHERE chat_id IN (SELECT id FROM (SELECT id FROM chats WHERE status IN ('completed','expired','cancelled') AND TIMESTAMPDIFF(DAY,IFNULL(expires_at,created_at),NOW())>3) t)");
        $pdo->exec("DELETE FROM chats WHERE status IN ('completed','expired','cancelled') AND TIMESTAMPDIFF(DAY,IFNULL(expires_at,created_at),NOW())>3");
    } catch(Exception $e){}
}

function refundPurchase(PDO $pdo, int $purchaseId, int $chatId, string $chatStatus='expired'): void {
    $pdo->beginTransaction();
    try {
        $p=$pdo->prepare("SELECT * FROM purchases WHERE id=? AND status='held'");
        $p->execute([$purchaseId]); $purchase=$p->fetch();
        if(!$purchase){ $pdo->rollBack(); return; }
        $buyer=$pdo->query("SELECT balance,held_balance FROM users WHERE id={$purchase['buyer_id']}")->fetch();
        $newBal=$buyer['balance']+(float)$purchase['amount'];
        $newHeld=max(0,$buyer['held_balance']-(float)$purchase['amount']);
        $pdo->prepare("UPDATE users SET balance=?,held_balance=? WHERE id=?")->execute([$newBal,$newHeld,$purchase['buyer_id']]);
        addTx($pdo,$purchase['buyer_id'],'refund',(float)$purchase['amount'],$buyer['balance'],$newBal,$purchaseId,'استرجاع تلقائي');
        $pdo->prepare("UPDATE purchases SET status='refunded' WHERE id=?")->execute([$purchaseId]);
        $pdo->prepare("UPDATE listings SET status='active' WHERE id=?")->execute([$purchase['listing_id']]);
        $pdo->prepare("UPDATE chats SET status=?,expires_at=IFNULL(expires_at,NOW()) WHERE id=?")->execute([$chatStatus,$chatId]);
        addNotif($pdo,$purchase['buyer_id'],'refund','💰 تم استرجاع مبلغك: '.money((float)$purchase['amount']),'wallet.php');
        addNotif($pdo,$purchase['seller_id'],'refund','⚠️ تم إلغاء الصفقة تلقائياً.','deals.php');
        $label=$chatStatus==='expired'?'⏰ انتهت مهلة الصفقة. تم إلغاؤها تلقائياً وإعادة المبلغ للمشتري.':'❌ تم إلغاء الصفقة بعد 24 ساعة بدون تفعيل.';
        try{ $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content)VALUES(?,1,'system',?)")->execute([$chatId,$label]); }catch(Exception $e){}
        $pdo->commit();
    } catch(Exception $e){ $pdo->rollBack(); }
}

function completePurchase(PDO $pdo,int $purchaseId): void {
    $pdo->beginTransaction();
    try {
        $p=$pdo->prepare("SELECT * FROM purchases WHERE id=? AND status='held'");
        $p->execute([$purchaseId]); $purchase=$p->fetch();
        if(!$purchase){ $pdo->rollBack(); return; }
        $listing=$pdo->query("SELECT account_details FROM listings WHERE id={$purchase['listing_id']}")->fetch();
        $seller=$pdo->query("SELECT balance FROM users WHERE id={$purchase['seller_id']}")->fetch();
        $sNew=$seller['balance']+$purchase['seller_net'];
        $pdo->prepare("UPDATE users SET balance=?,total_sales=total_sales+1,seller_rating=seller_rating+2 WHERE id=?")->execute([$sNew,$purchase['seller_id']]);
        addTx($pdo,$purchase['seller_id'],'release',$purchase['seller_net'],$seller['balance'],$sNew,$purchaseId,'إيرادات بيع');
        $buyer=$pdo->query("SELECT held_balance FROM users WHERE id={$purchase['buyer_id']}")->fetch();
        $bHeld=max(0,$buyer['held_balance']-$purchase['amount']);
        $pdo->prepare("UPDATE users SET held_balance=?,total_purchases=total_purchases+1,buyer_rating=buyer_rating+1 WHERE id=?")->execute([$bHeld,$purchase['buyer_id']]);
        $admin=$pdo->query("SELECT id,balance FROM users WHERE is_admin=1 LIMIT 1")->fetch();
        if($admin&&$purchase['commission']>0){
            $aNew=$admin['balance']+$purchase['commission'];
            $pdo->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$aNew,$admin['id']]);
            addTx($pdo,$admin['id'],'commission',$purchase['commission'],$admin['balance'],$aNew,$purchaseId,'عمولة منصة');
        }
        $pdo->prepare("UPDATE purchases SET status='completed',completed_at=NOW(),account_details_shown=? WHERE id=?")->execute([$listing['account_details']??'',$purchaseId]);
        $pdo->prepare("UPDATE listings SET status=CASE WHEN quantity<=1 THEN 'sold' ELSE status END, quantity=GREATEST(0,quantity-1) WHERE id=?")->execute([$purchase['listing_id']]);
        $pdo->prepare("UPDATE chats SET status='completed' WHERE purchase_id=?")->execute([$purchaseId]);
        addNotif($pdo,$purchase['seller_id'],'sale_complete','✅ تمت الصفقة! حصلت على '.money($purchase['seller_net']),'deal.php?pid='.$purchaseId);
        addNotif($pdo,$purchase['buyer_id'],'purchase_complete','✅ تمت عملية الشراء! شاهد بيانات حسابك الآن.','deal.php?pid='.$purchaseId);
        $pdo->commit();
    } catch(Exception $e){ $pdo->rollBack(); }
}

function statusLabel(string $s): string {
    $m=['active'=>'نشط','pending_sale'=>'في انتظار','sold'=>'مُباع','expired'=>'منتهي',
        'disputed'=>'نزاع','held'=>'محجوز','completed'=>'مكتمل','refunded'=>'مسترجع',
        'disabled'=>'معطل','pending'=>'معلق','approved'=>'مقبول','rejected'=>'مرفوض'];
    return isset($m[$s]) ? $m[$s] : $s;
}
