<?php
// =====================================================
// دوال مساعدة لنظام المزادات
// =====================================================

function getAuction(PDO $pdo, int $id): ?array {
    $s = $pdo->prepare("SELECT a.*, u.username seller_name, u.profile_pic seller_pic, u.kyc_status seller_kyc
        FROM auctions a JOIN users u ON u.id=a.seller_id WHERE a.id=?");
    $s->execute([$id]);
    return $s->fetch() ?: null;
}

function getTopBid(PDO $pdo, int $auctionId): ?array {
    $s = $pdo->prepare("SELECT b.*, u.username FROM bids b JOIN users u ON u.id=b.user_id
        WHERE b.auction_id=? ORDER BY b.bid_amount DESC LIMIT 1");
    $s->execute([$auctionId]);
    return $s->fetch() ?: null;
}

function getRecentBids(PDO $pdo, int $auctionId, int $limit = 10): array {
    $s = $pdo->prepare("SELECT b.*, u.username FROM bids b JOIN users u ON u.id=b.user_id
        WHERE b.auction_id=? ORDER BY b.bid_amount DESC LIMIT " . (int)$limit);
    $s->execute([$auctionId]);
    return $s->fetchAll();
}

// تحقق من حد المزايدات في الدقيقة (مكافحة البوتات)
function checkBidRateLimit(PDO $pdo, int $userId, int $auctionId): bool {
    try {
        $limit = (int)getSetting($pdo, 'auction_bid_rate_limit', 5);
        $s = $pdo->prepare("SELECT COUNT(*) FROM bids WHERE user_id=? AND auction_id=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
        $s->execute([$userId, $auctionId]);
        return $s->fetchColumn() < $limit;
    } catch(Exception $e){ return true; }
}

// حجز رصيد لمزايدة جديدة + إلغاء حجز السابق
function placeBid(PDO $pdo, int $auctionId, int $userId, float $bidAmount): array {
    $pdo->beginTransaction();
    try {
        // جلب المزاد بقفل
        $a = $pdo->query("SELECT * FROM auctions WHERE id=$auctionId FOR UPDATE")->fetch();
        if (!$a || $a['status'] !== 'active') {
            $pdo->rollBack(); return ['ok'=>false,'msg'=>'المزاد غير متاح'];
        }
        if (strtotime($a['end_date']) < time()) {
            $pdo->rollBack(); return ['ok'=>false,'msg'=>'انتهى وقت المزاد'];
        }
        if ($userId == $a['seller_id']) {
            $pdo->rollBack(); return ['ok'=>false,'msg'=>'لا يمكنك المزايدة على مزادك'];
        }

        $minIncrement = (float)getSetting($pdo, 'auction_min_increment', 1);
        $minBid       = $a['current_price'] + $minIncrement;
        if ($bidAmount < $minBid) {
            $pdo->rollBack(); return ['ok'=>false,'msg'=>'يجب أن تكون مزايدتك '.money($minBid).' على الأقل'];
        }

        // جلب بيانات المزايد مع قفل
        $user = $pdo->query("SELECT * FROM users WHERE id=$userId FOR UPDATE")->fetch();
        $availBal = (float)$user['balance'];

        if ($availBal < $bidAmount) {
            $pdo->rollBack(); return ['ok'=>false,'msg'=>'رصيدك غير كافٍ — متاح: '.money($availBal)];
        }

        // إلغاء حجز أعلى مزايد سابق (إذا كان مختلفاً)
        $prevTop = $pdo->query("SELECT * FROM bids WHERE auction_id=$auctionId ORDER BY bid_amount DESC LIMIT 1")->fetch();
        if ($prevTop && (int)$prevTop['user_id'] !== $userId) {
            $prevUser = $pdo->query("SELECT balance,held_balance FROM users WHERE id=".(int)$prevTop['user_id']." FOR UPDATE")->fetch();
            $relAmt   = (float)$prevTop['bid_amount'];
            $newBal   = (float)$prevUser['balance']   + $relAmt;
            $newHeld  = max(0, (float)$prevUser['held_balance'] - $relAmt);
            $pdo->prepare("UPDATE users SET balance=?,held_balance=? WHERE id=?")->execute([$newBal,$newHeld,(int)$prevTop['user_id']]);
            addTx($pdo,(int)$prevTop['user_id'],'release',$relAmt,(float)$prevUser['balance'],$newBal,$auctionId,'إلغاء حجز مزايدة');
        }
        // لو نفس المزايد يرفع مزايدته: أفك حجزه القديم أولاً
        if ($prevTop && (int)$prevTop['user_id'] === $userId) {
            $oldAmt  = (float)$prevTop['bid_amount'];
            $newBal  = $availBal + $oldAmt;
            $newHeld = max(0,(float)$user['held_balance'] - $oldAmt);
            $pdo->prepare("UPDATE users SET balance=?,held_balance=? WHERE id=?")->execute([$newBal,$newHeld,$userId]);
            addTx($pdo,$userId,'release',$oldAmt,$availBal,$newBal,$auctionId,'إلغاء حجز مزايدة سابقة');
            $availBal = $newBal; // تحديث الرصيد المتاح
            $user['held_balance'] = $newHeld;
        }

        // حجز المبلغ الجديد
        $balBefore = $availBal;
        $balAfter  = $availBal - $bidAmount;
        $heldAfter = (float)$user['held_balance'] + $bidAmount;
        $pdo->prepare("UPDATE users SET balance=?,held_balance=? WHERE id=?")->execute([$balAfter,$heldAfter,$userId]);
        addTx($pdo,$userId,'hold',$bidAmount,$balBefore,$balAfter,$auctionId,'حجز مزايدة');

        // تسجيل المزايدة
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        $pdo->prepare("INSERT INTO bids (auction_id,user_id,bid_amount,ip_address) VALUES (?,?,?,?)")->execute([$auctionId,$userId,$bidAmount,$ip]);

        // تحديث السعر الحالي وعداد المزايدات
        $pdo->prepare("UPDATE auctions SET current_price=?,bid_count=bid_count+1 WHERE id=?")->execute([$bidAmount,$auctionId]);

        $pdo->commit();

        // إشعار البائع
        addNotif($pdo,(int)$a['seller_id'],'auction','💰 مزايدة جديدة على مزادك: '.money($bidAmount),'auctions.php?id='.$auctionId);

        return ['ok'=>true,'msg'=>'تمت مزايدتك بنجاح على '.money($bidAmount)];
    } catch(Exception $e) {
        $pdo->rollBack();
        return ['ok'=>false,'msg'=>'خطأ: '.$e->getMessage()];
    }
}

// إنهاء المزادات المنتهية وتوزيع الأموال
function settleExpiredAuctions(PDO $pdo): void {
    try {
        $expired = $pdo->query("SELECT * FROM auctions WHERE status='active' AND end_date < NOW()")->fetchAll();
    } catch(Exception $e){ return; }
    foreach ($expired as $a) {
        try { settleAuction($pdo, (int)$a['id']); } catch(Exception $e){}
    }
}

function settleAuction(PDO $pdo, int $auctionId): void {
    $pdo->beginTransaction();
    try {
        $a = $pdo->query("SELECT * FROM auctions WHERE id=$auctionId FOR UPDATE")->fetch();
        if (!$a || $a['status'] !== 'active') { $pdo->rollBack(); return; }

        $topBid = $pdo->query("SELECT * FROM bids WHERE auction_id=$auctionId ORDER BY bid_amount DESC LIMIT 1")->fetch();

        if (!$topBid) {
            // لا توجد مزايدات → إلغاء
            $pdo->prepare("UPDATE auctions SET status='cancelled' WHERE id=?")->execute([$auctionId]);
            addNotif($pdo,(int)$a['seller_id'],'auction','❌ انتهى مزادك بدون مزايدات وتم إلغاؤه','');
            $pdo->commit(); return;
        }

        $winnerId  = (int)$topBid['user_id'];
        $winAmount = (float)$topBid['bid_amount'];
        $commRate  = (float)getSetting($pdo, 'auction_commission_rate', '5');
        $commission= round($winAmount * $commRate / 100, 2);
        $sellerNet = round($winAmount - $commission, 2);

        // تحويل المحجوز → خصم نهائي للفائز (الرصيد المحجوز يُصفّى)
        $winner = $pdo->query("SELECT balance,held_balance FROM users WHERE id=$winnerId FOR UPDATE")->fetch();
        $newHeld = max(0,(float)$winner['held_balance'] - $winAmount);
        $pdo->prepare("UPDATE users SET held_balance=? WHERE id=?")->execute([$newHeld,$winnerId]);
        addTx($pdo,$winnerId,'withdraw',$winAmount,(float)$winner['balance'],(float)$winner['balance'],$auctionId,'دفع مزاد فائز');

        // إضافة للبائع
        $seller   = $pdo->query("SELECT balance FROM users WHERE id=".(int)$a['seller_id']." FOR UPDATE")->fetch();
        $selBef   = (float)$seller['balance'];
        $pdo->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$sellerNet,(int)$a['seller_id']]);
        addTx($pdo,(int)$a['seller_id'],'commission',$sellerNet,$selBef,$selBef+$sellerNet,$auctionId,'عائد مزاد (بعد العمولة)');

        // تحرير حجز باقي المزايدين
        $others = $pdo->query("SELECT user_id, bid_amount FROM bids WHERE auction_id=$auctionId AND user_id!=$winnerId GROUP BY user_id HAVING bid_amount=MAX(bid_amount)")->fetchAll();
        // أبسط: حرر الحجوزات لجميع المزايدين غير الفائز
        $lostBidders = $pdo->query("SELECT user_id, MAX(bid_amount) AS top FROM bids WHERE auction_id=$auctionId AND user_id!=$winnerId GROUP BY user_id")->fetchAll();
        foreach ($lostBidders as $lb) {
            $lu = $pdo->query("SELECT balance,held_balance FROM users WHERE id=".(int)$lb['user_id']." FOR UPDATE")->fetch();
            $rAmt  = (float)$lb['top'];
            $nBal  = (float)$lu['balance'] + $rAmt;
            $nHeld = max(0,(float)$lu['held_balance'] - $rAmt);
            $pdo->prepare("UPDATE users SET balance=?,held_balance=? WHERE id=?")->execute([$nBal,$nHeld,(int)$lb['user_id']]);
            addTx($pdo,(int)$lb['user_id'],'release',$rAmt,(float)$lu['balance'],$nBal,$auctionId,'إرجاع حجز مزاد');
            addNotif($pdo,(int)$lb['user_id'],'auction','😔 لم تفز في المزاد، تم إرجاع رصيدك كاملاً','');
        }

        // تحديد الفائز
        $pdo->prepare("UPDATE bids SET is_winner=1 WHERE auction_id=? AND user_id=? ORDER BY bid_amount DESC LIMIT 1")->execute([$auctionId,$winnerId]);
        $pdo->prepare("UPDATE auctions SET status='completed',winner_id=? WHERE id=?")->execute([$winnerId,$auctionId]);

        // ── إنشاء غرفة الشات بين الفائز + البائع + الأدمن ──
        try {
            $pdo->prepare("INSERT INTO chats (purchase_id, auction_id, winner_id, seller_id2, status, buyer_joined, seller_joined, admin_joined, activated_at, expires_at)
                VALUES (NULL, ?, ?, ?, 'active', 0, 0, 0, NOW(), DATE_ADD(NOW(), INTERVAL 72 HOUR))")
                ->execute([$auctionId, $winnerId, (int)$a['seller_id']]);
            $roomId = (int)$pdo->lastInsertId();
            // رسالة ترحيب في الغرفة
            $sysMsg = "🏆 انتهى المزاد — تم إنشاء غرفة التسليم\n"
                    . "الفائز: سيتواصل مع البائع هنا\n"
                    . "💰 مبلغ الفوز: ".money($winAmount)."\n"
                    . "📋 يُرجى التنسيق لإتمام التسليم خلال 72 ساعة";
            $pdo->prepare("INSERT INTO messages(chat_id,sender_id,message_type,content) VALUES(?,1,'system',?)")
                ->execute([$roomId, $sysMsg]);
            // إشعارات بالغرفة
            $roomLink = 'auction_deal.php?rid='.$roomId;
            addNotif($pdo, $winnerId,          'chat_active', '🏆 فزت بالمزاد! غرفة التسليم جاهزة — انضم الآن', $roomLink);
            addNotif($pdo, (int)$a['seller_id'],'chat_active', '✅ انتهى مزادك — غرفة التسليم مع الفائز جاهزة',  $roomLink);
        } catch(Exception $e){}

        addNotif($pdo,$winnerId,'auction','🏆 تهانينا! فزت بالمزاد بـ '.money($winAmount),'');
        addNotif($pdo,(int)$a['seller_id'],'auction','✅ انتهى مزادك — الفائز: '.money($winAmount).' (صافيك: '.money($sellerNet).')','');

        $pdo->commit();
    } catch(Exception $e) {
        $pdo->rollBack();
    }
}

// تنسيق الوقت المتبقي
function auctionTimeLeft(string $endDate): string {
    $diff = strtotime($endDate) - time();
    if ($diff <= 0) return 'انتهى';
    $d = floor($diff / 86400);
    $h = floor(($diff % 86400) / 3600);
    $m = floor(($diff % 3600) / 60);
    if ($d > 0) return $d . ' يوم ' . $h . ' س';
    if ($h > 0) return $h . ' ساعة ' . $m . ' د';
    return $m . ' دقيقة';
}

// إخفاء اسم المستخدم جزئياً: ahmed22 → ah***22
function maskUsername(string $name): string {
    $len = mb_strlen($name, 'UTF-8');
    if ($len <= 4) return str_repeat('*', $len);
    $show = 2;
    $end  = 2;
    return mb_substr($name,0,$show,'UTF-8') . '***' . mb_substr($name,$len-$end,$end,'UTF-8');
}
