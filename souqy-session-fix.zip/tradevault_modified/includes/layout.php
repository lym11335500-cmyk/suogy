<?php
// ─── LAYOUT HELPERS ───────────────────────────────────────────────────────────

function assetUrl($path) {
    if (!$path) return '';
    if (substr($path, 0, 4) === 'http') return $path;
    $sd  = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $rd  = str_replace('\\', '/', dirname(dirname(__FILE__)));
    $dep = substr_count(str_replace($rd, '', $sd), '/');
    $pfx = $dep > 0 ? str_repeat('../', $dep) : '';
    return $pfx . ltrim($path, '/');
}

function pageHead(string $title, string $extra = ''): void {
    global $pdo;
    $siteName  = isset($pdo) ? getSetting($pdo, 'site_name', 'سوقي') : 'سوقي';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $rootDir   = str_replace('\\', '/', dirname(dirname(__FILE__)));
    $depth     = substr_count(str_replace($rootDir, '', $scriptDir), '/');
    $cssPrefix = $depth > 0 ? str_repeat('../', $depth) : '';
    echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#060810">
<title>' . e($title) . ' — ' . e($siteName) . '</title>
<link rel="icon" type="image/svg+xml" href="' . $cssPrefix . 'assets/img/favicon.svg">
<link rel="shortcut icon" href="' . $cssPrefix . 'assets/img/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Cairo:wght@400;600;700;900&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="' . $cssPrefix . 'assets/css/style.css">
' . $extra . '
</head><body><div class="app">';
}

function pageTopbar(PDO $pdo, string $backUrl = '', string $title = ''): void {
    $uid   = uid();
    $notif = $uid ? getUnreadCount($pdo, $uid) : 0;
    $badge = $notif ? '<span class="notif-dot">' . min($notif, 9) . '</span>' : '';
    $user  = $uid ? $pdo->query("SELECT profile_pic,username FROM users WHERE id=$uid")->fetch() : null;

    // Depth calculation for links
    $sd2  = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $rd2  = str_replace('\\', '/', dirname(dirname(__FILE__)));
    $dep2 = substr_count(str_replace($rd2, '', $sd2), '/');
    $lpfx = $dep2 > 0 ? str_repeat('../', $dep2) : '';

    echo '<header class="topbar">';

    if ($backUrl === '') {
        // ── Home topbar: logo + search icon + bells + avatar ──
        $sn = getSetting($pdo, 'site_name', 'سوقي');
        echo '<a href="index.php" class="topbar-logo">
          <img src="' . $lpfx . 'assets/img/logo.svg" alt="TV" style="width:28px;height:28px;vertical-align:middle;margin-left:6px">
          ' . e($sn) . '
        </a>';
        echo '<div class="topbar-right">';
        // Search icon → listing.php
        echo '<a href="' . $lpfx . 'pages/listing.php" class="icon-btn" aria-label="بحث"><i class="fas fa-search"></i></a>';
        if ($uid) {
            echo '<a href="' . $lpfx . 'pages/notifications.php" class="icon-btn" aria-label="الإشعارات"><i class="fas fa-bell"></i>' . $badge . '</a>';
            if ($user && $user['profile_pic']) {
                echo '<a href="' . $lpfx . 'pages/profile.php" class="avatar-btn"><img src="' . e(assetUrl($user['profile_pic'])) . '" alt=""></a>';
            } else {
                $avLetter = $user ? strtoupper(mb_substr($user['username'], 0, 1, 'UTF-8')) : '?';
                echo '<a href="' . $lpfx . 'pages/profile.php" class="avatar-btn">' . $avLetter . '</a>';
            }
        } else {
            echo '<a href="' . $lpfx . 'pages/login.php" class="btn btn-gold btn-sm">دخول</a>';
        }
        echo '</div>';
    } else {
        // ── Inner page topbar: back button + title ──
        $href    = $backUrl === 'js:back' ? '#' : e($backUrl);
        $onclick = $backUrl === 'js:back' ? ' onclick="history.back();return false;"' : '';
        echo '<a href="' . $href . '" class="icon-btn" aria-label="رجوع"' . $onclick . '><i class="fas fa-arrow-right"></i></a>';
        if ($title) {
            echo '<div class="topbar-title">' . e($title) . '</div>';
        } else {
            echo '<div style="flex:1"></div>';
        }
        echo '<div class="topbar-right">';
        if ($uid) {
            echo '<a href="' . $lpfx . 'pages/notifications.php" class="icon-btn" aria-label="الإشعارات"><i class="fas fa-bell"></i>' . $badge . '</a>';
        }
        echo '</div>';
    }

    echo '</header>';
}

function pageBottomNav(string $active = ''): void {
    $uid = uid();

    // ── Optimized nav: 5 items, Sell is prominent center button ──
    $items = [
        ['index.php',    'fa-home',    'الرئيسية', 'home',     false],
        ['auctions.php', 'fa-gavel',   'مزادات',   'auctions', false],
        ['sell.php',     'fa-plus',    'بيع',      'sell',     true ],   // center CTA
        ['deals.php',    'fa-handshake','صفقاتي',  'deals',    false],
        ['wallet.php',   'fa-wallet',  'محفظتي',   'wallet',   false],
    ];

    echo '<nav class="bnav" role="navigation" aria-label="التنقل الرئيسي">';
    foreach ($items as [$href, $ic, $lbl, $key, $isSell]) {
        $cls = ($active === $href || $active === $key) ? 'bnav-item active' : 'bnav-item';
        if (!$uid && in_array($key, ['sell', 'deals', 'wallet'])) $href = 'login.php';

        if ($isSell) {
            // Prominent "+" sell button
            echo '<a href="' . $href . '" class="bnav-item bnav-sell" aria-label="' . $lbl . '">
              <div class="bnav-sell-btn"><i class="fas ' . $ic . '"></i></div>
              ' . $lbl . '
            </a>';
        } else {
            echo '<a href="' . $href . '" class="' . $cls . '" aria-label="' . $lbl . '">
              <i class="fas ' . $ic . '"></i>' . $lbl . '
            </a>';
        }
    }
    echo '</nav>';
}

function pageFoot(string $extraJs = ''): void {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']));
    $rootDir   = str_replace('\\', '/', dirname(dirname(__FILE__)));
    $depth     = substr_count(str_replace($rootDir, '', $scriptDir), '/');
    $jsPrefix  = $depth > 0 ? str_repeat('../', $depth) : '';
    echo '<script src="' . $jsPrefix . 'assets/js/main.js"></script>';
    if ($extraJs) echo '<script>' . $extraJs . '</script>';
    echo '</div></body></html>';
}

function flash(string $type, string $msg): string {
    $icons = ['ok' => 'fa-check-circle', 'err' => 'fa-times-circle', 'info' => 'fa-info-circle', 'warn' => 'fa-exclamation-triangle'];
    $ic    = $icons[$type] ?? 'fa-info-circle';
    return '<div class="alert alert-' . $type . '"><i class="fas ' . $ic . '"></i><span>' . e($msg) . '</span></div>';
}

function listingCard(PDO $pdo, array $l, bool $showStatus = false): string {
    $thumb = getListingThumb($pdo, (int)$l['id']);
    $img   = $thumb
        ? '<img src="' . e(assetUrl($thumb)) . '" class="l-card-img" alt="" loading="lazy">'
        : '<div class="l-card-img-ph"><i class="fas ' . e($l['cat_icon'] ?? 'fa-tag') . '"></i></div>';

    $price      = money((float)$l['price']);
    $cat        = e($l['cat_name'] ?? $l['name_ar'] ?? '');
    $catIcon    = e($l['cat_icon'] ?? 'fa-tag');
    $seller     = e($l['seller_name'] ?? '');
    $statusTag  = $showStatus ? '<span class="tag tag-' . e($l['status']) . '">' . statusLabel($l['status']) . '</span>' : '';
    $isSold     = in_array($l['status'], ['sold', 'disabled']);
    $soldOverlay = $isSold
        ? '<div style="position:absolute;inset:0;background:#00000077;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:.85rem;color:var(--red);letter-spacing:2px">' . ($l['status'] === 'sold' ? 'مُباع' : 'معطل') . '</div>'
        : '';

    return '<a href="listing.php?id=' . e($l['id']) . '" class="l-card fade-up" style="position:relative">
      ' . $img . $soldOverlay . '
      <div class="l-card-body">
        <div class="l-card-cat"><i class="fas ' . $catIcon . '"></i> ' . $cat . '</div>
        <div class="l-card-title">' . e($l['title']) . '</div>
        <div style="display:flex;align-items:center;justify-content:space-between">
          <div class="l-card-price">' . $price . '</div>' . $statusTag . '
        </div>
        <div class="l-card-foot">
          <div class="l-card-seller"><i class="fas fa-user" style="font-size:.6rem"></i>' . $seller . '</div>
          <span style="font-size:.65rem;color:var(--t2)">' . timeAgo($l['created_at']) . '</span>
        </div>
      </div>
    </a>';
}
