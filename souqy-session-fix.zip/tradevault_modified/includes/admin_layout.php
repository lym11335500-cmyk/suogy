<?php
require_once __DIR__ . '/db.php';

function adminCheck(): void { requireAdmin(); }

function adminHead(string $title, string $activePage=''): void {
    global $pdo;
    $siteName = getSetting($pdo,'site_name','سوقي');
    try {
        $pKyc    = (int)$pdo->query("SELECT COUNT(*) FROM kyc_documents WHERE status='pending'")->fetchColumn();
        $pDisp   = (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='disputed'")->fetchColumn();
        $pHeld   = (int)$pdo->query("SELECT COUNT(*) FROM purchases WHERE status='held'")->fetchColumn();
        $pPay    = (int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE status='pending'")->fetchColumn();
        $pDeposits = (int)$pdo->query("SELECT COUNT(*) FROM payment_requests WHERE type='deposit' AND status='pending'")->fetchColumn();
        $pAds    = (int)$pdo->query("SELECT COUNT(*) FROM ads WHERE status='pending'")->fetchColumn();
        $unreadN = (int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id=1 AND is_read=0")->fetchColumn();
    } catch(Exception $e){ $pKyc=$pDisp=$pHeld=$pPay=$pDeposits=$pAds=$unreadN=0; }

    $scriptDir = str_replace('\\','/',dirname($_SERVER['SCRIPT_FILENAME']));
    $rootDir   = str_replace('\\','/',dirname(dirname(__FILE__)));
    $depth     = substr_count(str_replace($rootDir,'',$scriptDir),'/');
    $prefix    = $depth > 0 ? str_repeat('../',$depth) : '';
    $cur       = basename($_SERVER['PHP_SELF'], '.php');
    $adminUser = $_SESSION['username'] ?? 'Admin';

    // Determine open state for dropdown groups
    $inContent = in_array($cur,['ads','products','media_library']);
    $inFinance = in_array($cur,['deposits','withdrawals','wallet','deposit_methods','withdraw_methods']);

    echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#060810">
<title>'.e($title).' — لوحة الإدارة | '.e($siteName).'</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Cairo:wght@400;600;700;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="'.$prefix.'assets/css/admin.css">
</head><body>

<!-- OVERLAYS -->
<div class="sb-overlay" id="sbOverlay" onclick="closeSb()"></div>
<div class="adm-wrap">

<!-- ═══════════════ SIDEBAR ═══════════════ -->
<aside class="adm-sidebar" id="adminSidebar">

  <!-- Logo -->
  <div class="sb-logo">
    <div class="logo-box" style="background:transparent;border:none;padding:0"><img src="'.$prefix.'assets/img/logo.svg" alt="TV" style="width:38px;height:38px"></div>
    <div>
      <div class="logo-text">'.e($siteName).'</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
    <div class="online-dot"></div>
  </div>

  <!-- Quick Search Button -->
  <div class="sb-search">
    <button class="sb-search-btn" onclick="openSearch()" id="sbSearchBtn">
      <i class="fas fa-search"></i>
      <span>بحث سريع...</span>
      <span class="kb">Ctrl+K</span>
    </button>
  </div>

  <nav class="sb-nav">

    <!-- ── إجراءات سريعة (مرئية دائماً) ── -->
    <div class="sb-quick-actions">
      <a href="settings.php" class="sb-quick-btn'.($cur==='settings'?' sq-active':'').'" title="الإعدادات">
        <i class="fas fa-cog"></i><span>الإعدادات</span>
      </a>
      <a href="'.$prefix.'pages/index.php" class="sb-quick-btn" title="الموقع" target="_blank">
        <i class="fas fa-globe" style="color:#4ade80"></i><span style="color:#4ade80">الموقع</span>
      </a>
      <a href="logout.php" class="sb-quick-btn" title="خروج" onclick="return confirm(\'تأكيد الخروج؟\')">
        <i class="fas fa-sign-out-alt" style="color:#ff4757"></i><span style="color:#ff4757">خروج</span>
      </a>
    </div>

    <!-- ── نظرة عامة ─────────────────────── -->
    <div class="sb-sect">نظرة عامة</div>
    <a href="index.php" class="sb-link'.($cur==='index'?' active':'').'">
      <i class="fas fa-chart-pie"></i>لوحة التحكم
    </a>
    <a href="activity_log.php" class="sb-link'.($cur==='activity_log'?' active':'').'">
      <i class="fas fa-history"></i>سجل النشاطات
      <span class="sb-badge new" style="font-size:.55rem;padding:2px 6px">جديد</span>
    </a>

    <!-- ── المستخدمون ─────────────────────── -->
    <div class="sb-sect">المستخدمون</div>
    <a href="users.php" class="sb-link'.($cur==='users'?' active':'').'">
      <i class="fas fa-users"></i>جميع المستخدمين
    </a>
    <a href="kyc.php" class="sb-link'.($cur==='kyc'?' active':'').'">
      <i class="fas fa-id-card"></i>توثيق KYC
      '.($pKyc>0?'<span class="sb-badge">'.$pKyc.'</span>':'').'
    </a>
    <a href="archive.php" class="sb-link'.($cur==='archive'?' active':'').'" style="'.($cur==='archive'?'':'').'">
      <i class="fas fa-lock" style="color:var(--gold)"></i>الأرشيف السري
    </a>

    <!-- ── إدارة المحتوى (dropdown) ────────── -->
    <div class="sb-sect">المحتوى</div>
    <div class="sb-group">
      <button class="sb-group-toggle'.($inContent?' has-active open':'').'" onclick="toggleGroup(this)">
        <i class="fas fa-layer-group icon"></i>
        إدارة المحتوى
        '.($pAds>0?'<span class="sb-badge gold">'.$pAds.'</span>':'').'
        <i class="fas fa-chevron-left arrow"></i>
      </button>
      <div class="sb-group-items'.($inContent?' open':'').'">
        <a href="ads.php" class="sb-sub-link'.($cur==='ads'?' active':'').'">
          <span class="dot"></span>جميع الإعلانات
          '.($pAds>0?'<span class="sb-badge gold" style="margin-right:auto">'.$pAds.'</span>':'').'
        </a>
        <a href="products.php" class="sb-sub-link'.($cur==='products'?' active':'').'">
          <span class="dot"></span>المنتجات
        </a>
        <a href="media_library.php" class="sb-sub-link'.($cur==='media_library'?' active':'').'">
          <span class="dot"></span>مكتبة الوسائط
          <span class="sb-badge new" style="margin-right:auto;font-size:.52rem;padding:1px 5px">جديد</span>
        </a>
      </div>
    </div>

    <!-- ── المالية (dropdown) ────────────── -->
    <div class="sb-sect">المالية</div>
    <div class="sb-group">
      <button class="sb-group-toggle'.($inFinance?' has-active open':'').'" onclick="toggleGroup(this)">
        <i class="fas fa-coins icon"></i>
        المعاملات المالية
        '.($pDeposits+$pPay>0?'<span class="sb-badge">'.(int)($pDeposits+$pPay).'</span>':'').'
        <i class="fas fa-chevron-left arrow"></i>
      </button>
      <div class="sb-group-items'.($inFinance?' open':'').'">
        <a href="deposits.php" class="sb-sub-link'.($cur==='deposits'?' active':'').'">
          <span class="dot"></span>طلبات الإيداع
          '.($pDeposits>0?'<span class="sb-badge" style="margin-right:auto">'.$pDeposits.'</span>':'').'
        </a>
        <a href="deposit_methods.php" class="sb-sub-link'.($cur==='deposit_methods'?' active':'').'">
          <span class="dot"></span>طرق الإيداع
        </a>
        <a href="withdrawals.php" class="sb-sub-link'.($cur==='withdrawals'?' active':'').'">
          <span class="dot"></span>طلبات السحب
          '.($pPay>0?'<span class="sb-badge" style="margin-right:auto">'.$pPay.'</span>':'').'
        </a>
        <a href="withdraw_methods.php" class="sb-sub-link'.($cur==='withdraw_methods'?' active':'').'">
          <span class="dot"></span>طرق السحب
        </a>
        <a href="wallet.php" class="sb-sub-link'.($cur==='wallet'?' active':'').'">
          <span class="dot"></span>سجل المعاملات
        </a>
      </div>
    </div>

    <!-- ── العمليات ──────────────────────── -->
    <div class="sb-sect">العمليات</div>
    <a href="orders.php" class="sb-link'.($cur==='orders'?' active':'').'">
      <i class="fas fa-handshake"></i>الطلبات والصفقات
      '.($pHeld>0?'<span class="sb-badge gold">'.$pHeld.'</span>':'').'
    </a>
    <a href="disputes.php" class="sb-link'.($cur==='disputes'?' active':'').'">
      <i class="fas fa-exclamation-triangle"></i>النزاعات
      '.($pDisp>0?'<span class="sb-badge">'.$pDisp.'</span>':'').'
    </a>
    <a href="reports.php" class="sb-link'.($cur==='reports'?' active':'').'">
      <i class="fas fa-chart-line"></i>التقارير والإحصاء
    </a>
    <a href="contests.php" class="sb-link'.($cur==='contests'?' active':'').'">
      <i class="fas fa-trophy"></i>مسابقة الإحالة
    </a>
    <a href="auctions.php" class="sb-link'.($cur==='auctions'?' active':'').'">
      <i class="fas fa-gavel"></i>المزادات
    </a>

    <!-- ── النظام ────────────────────────── -->
    <div class="sb-sect">النظام</div>
    <a href="broadcast.php" class="sb-link'.($cur==='broadcast'?' active':'').'">
      <i class="fas fa-bullhorn"></i>إشعار جماعي
    </a>
    <a href="settings.php" class="sb-link'.($cur==='settings'?' active':'').'">
      <i class="fas fa-cog"></i>الإعدادات
    </a>

  </nav>

  <!-- Footer -->
  <div class="sb-foot">
    <div class="sb-user">
      <div class="sb-av" style="background:linear-gradient(135deg,#F0B429,#E07B00);font-weight:900;font-size:.8rem">TV</div>
      <div>
        <div style="font-size:.82rem;font-weight:700">'.e($adminUser).'</div>
        <div style="font-size:.65rem;color:var(--t3)">مدير النظام</div>
      </div>
    </div>
    <a href="logout.php" class="sb-link" style="color:var(--red)"><i class="fas fa-sign-out-alt"></i>تسجيل الخروج</a>
    <a href="'.$prefix.'pages/index.php" class="sb-link" style="color:#4ade80;margin-top:2px;border-top:1px solid rgba(255,255,255,.08);padding-top:10px" target="_blank">
      <i class="fas fa-globe"></i>العودة للموقع
    </a>
  </div>

</aside>
<!-- ═════════════ END SIDEBAR ═════════════ -->

<!-- ═══════════════ MAIN ═══════════════ -->
<main class="adm-main" id="adminMain">
<button class="mobile-btn" id="mobileBtn" onclick="toggleSb()" style="display:none;margin-bottom:16px">
  <i class="fas fa-bars"></i>
</button>

<!-- Notification Bell (floating in topbar area) -->
<div id="globalNotifBell" style="position:fixed;bottom:24px;right:24px;z-index:500;">
  <button class="notif-bell" onclick="toggleNotifPanel()" title="الإشعارات (Alt+N)">
    <i class="fas fa-bell"></i>
    '.($unreadN>0?'<span class="n-dot"></span>':'').'
  </button>
</div>';
}

function adminFoot(): void {
    global $pdo;
    // Load recent notifications for panel
    $notifs = [];
    try {
        $notifs = $pdo->query("SELECT * FROM notifications WHERE user_id=1 ORDER BY created_at DESC LIMIT 20")->fetchAll();
    } catch(Exception $e){}

    echo '</main></div>

<!-- ═══════════════ NOTIFICATION PANEL ═══════════════ -->
<div class="notif-panel" id="notifPanel">
  <div class="np-head">
    <div class="np-title"><i class="fas fa-bell" style="color:var(--gold)"></i> الإشعارات</div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-ghost btn-xs" onclick="markAllRead()" title="تحديد الكل كمقروء">
        <i class="fas fa-check-double"></i> الكل مقروء
      </button>
      <button class="modal-close" onclick="closeNotifPanel()"><i class="fas fa-times"></i></button>
    </div>
  </div>
  <div class="np-body" id="npBody">';

    if (empty($notifs)) {
        echo '<div class="notif-empty"><i class="fas fa-bell-slash"></i><p>لا توجد إشعارات</p></div>';
    } else {
        foreach ($notifs as $n) {
            $unread = !$n['is_read'] ? ' unread' : '';
            $icons = [
                'broadcast'        => ['fa-bullhorn','rgba(232,164,0,.12)','var(--gold)'],
                'deposit'          => ['fa-arrow-circle-down','rgba(16,217,122,.12)','var(--green)'],
                'withdrawal'       => ['fa-money-bill-wave','rgba(74,143,245,.12)','var(--blue)'],
                'sale_complete'    => ['fa-handshake','rgba(16,217,122,.12)','var(--green)'],
                'purchase_complete'=> ['fa-shopping-bag','rgba(74,143,245,.12)','var(--blue)'],
                'refund'           => ['fa-undo','rgba(168,85,247,.12)','var(--purple)'],
                'kyc'              => ['fa-id-card','rgba(245,200,66,.12)','#f5c842'],
            ];
            $ico = $icons[$n['type']] ?? ['fa-bell','rgba(255,255,255,.08)','var(--t2)'];
            echo '<div class="notif-item'.$unread.'" data-id="'.e($n['id']).'">
              <div class="notif-icon" style="background:'.$ico[1].'"><i class="fas '.$ico[0].'" style="color:'.$ico[2].'"></i></div>
              <div class="notif-text">
                <div class="nt-msg">'.e(mb_substr($n['message'],0,80,'UTF-8')).'</div>
                <div class="nt-time"><i class="fas fa-clock" style="font-size:.6rem"></i> '.timeAgo($n['created_at']).'</div>
              </div>
            </div>';
        }
    }

    echo '</div>
</div>

<!-- ═══════════════ SEARCH MODAL ═══════════════ -->
<div class="search-overlay" id="searchOverlay" onclick="handleSearchOverlayClick(event)">
  <div class="search-modal">
    <div class="search-input-wrap">
      <i class="fas fa-search"></i>
      <input type="text" id="searchInput" placeholder="ابحث في الصفحات... مثال: المستخدمون، الإيداع" oninput="filterSearch(this.value)" onkeydown="searchKeyNav(event)" autocomplete="off">
      <span class="search-kb">Esc</span>
    </div>
    <div class="search-results" id="searchResults"></div>
    <div class="search-footer">
      <span class="search-hint"><kbd>↑↓</kbd> للتنقل</span>
      <span class="search-hint"><kbd>Enter</kbd> للانتقال</span>
      <span class="search-hint"><kbd>Esc</kbd> للإغلاق</span>
    </div>
  </div>
</div>

<!-- ═══════════════ BROADCAST QUICK MODAL ═══════════════ -->
<div class="modal-overlay" id="bcastModal">
  <div class="modal" style="max-width:520px">
    <div class="modal-title">
      <span><i class="fas fa-paper-plane" style="color:var(--gold);margin-left:8px"></i> إرسال إشعار سريع</span>
      <button class="modal-close" onclick="closeBcastModal()"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" action="broadcast.php">
      <input type="hidden" name="_csrf" value="<?php echo csrf(); ?>">
      <input type="hidden" name="act" value="send_broadcast">
      <div class="fg">
        <label>المستهدفون</label>
        <select name="bc_target" class="fsel">
          <option value="all">🌍 جميع المستخدمين</option>
          <option value="kyc_approved">✅ الموثقون فقط</option>
          <option value="kyc_pending">⏳ قيد المراجعة</option>
        </select>
      </div>
      <div class="fg">
        <label>عنوان الرسالة <span style="color:var(--red)">*</span></label>
        <input type="text" name="bc_title" class="fi" placeholder="عنوان الإشعار..." required maxlength="100">
      </div>
      <div class="fg">
        <label>محتوى الرسالة <span style="color:var(--red)">*</span></label>
        <textarea name="bc_body" class="fta" rows="3" required maxlength="500" placeholder="نص الرسالة..."></textarea>
      </div>
      <div style="display:flex;gap:10px">
        <button type="submit" class="btn btn-gold" style="flex:1" onclick="return confirm(\'إرسال الإشعار الجماعي؟\')">
          <i class="fas fa-paper-plane"></i> إرسال الآن
        </button>
        <button type="button" class="btn btn-ghost" onclick="closeBcastModal()">إلغاء</button>
      </div>
    </form>
  </div>
</div>

<!-- ═══════════════ SCROLL TO TOP ═══════════════ -->
<button id="stt" title="العودة للأعلى"><i class="fas fa-arrow-up"></i></button>

<script>
/* ══════ SIDEBAR TOGGLE ══════ */
function toggleSb(){
  document.getElementById("adminSidebar").classList.toggle("open");
  document.getElementById("sbOverlay").classList.toggle("show");
}
function closeSb(){
  document.getElementById("adminSidebar").classList.remove("open");
  document.getElementById("sbOverlay").classList.remove("show");
}

/* ══════ DROPDOWN GROUPS ══════ */
function toggleGroup(btn){
  var arrow = btn.querySelector(".arrow");
  var items = btn.nextElementSibling;
  var isOpen = items.classList.contains("open");
  // Close all other groups
  document.querySelectorAll(".sb-group-items").forEach(function(el){ el.classList.remove("open"); });
  document.querySelectorAll(".sb-group-toggle").forEach(function(el){ el.classList.remove("open"); });
  if(!isOpen){ items.classList.add("open"); btn.classList.add("open"); }
}

/* ══════ NOTIFICATION PANEL ══════ */
function toggleNotifPanel(){
  document.getElementById("notifPanel").classList.toggle("open");
}
function closeNotifPanel(){
  document.getElementById("notifPanel").classList.remove("open");
}
function markAllRead(){
  fetch("../api/mark-notifs.php", {method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded"}, body:"all=1"})
    .then(function(){ 
      document.querySelectorAll(".notif-item.unread").forEach(function(el){ el.classList.remove("unread"); });
      var dot = document.querySelector(".notif-bell .n-dot");
      if(dot) dot.remove();
    }).catch(function(){});
}

/* ══════ SEARCH MODAL ══════ */
var searchPages = [
  {label:"لوحة التحكم",      url:"index.php",         icon:"fa-chart-pie",       hint:"الرئيسية"},
  {label:"سجل النشاطات",     url:"activity_log.php",  icon:"fa-history",         hint:"النشاطات"},
  {label:"جميع المستخدمين",  url:"users.php",          icon:"fa-users",           hint:"المستخدمون"},
  {label:"توثيق KYC",        url:"kyc.php",            icon:"fa-id-card",         hint:"التحقق"},
  {label:"الأرشيف السري",    url:"archive.php",         icon:"fa-lock",            hint:"موثقين"},
  {label:"جميع الإعلانات",   url:"ads.php",            icon:"fa-th-list",         hint:"المحتوى"},
  {label:"المنتجات",          url:"products.php",       icon:"fa-box-open",        hint:"المحتوى"},
  {label:"مكتبة الوسائط",    url:"media_library.php",  icon:"fa-images",          hint:"المحتوى"},
  {label:"الطلبات والصفقات", url:"orders.php",          icon:"fa-handshake",       hint:"العمليات"},
  {label:"النزاعات",          url:"disputes.php",       icon:"fa-exclamation-triangle",hint:"العمليات"},
  {label:"التقارير والإحصاء",url:"reports.php",         icon:"fa-chart-line",      hint:"العمليات"},
  {label:"طلبات الإيداع",    url:"deposits.php",       icon:"fa-arrow-circle-down",hint:"المالية"},
  {label:"طرق الإيداع",      url:"deposit_methods.php",icon:"fa-cog",             hint:"المالية"},
  {label:"طلبات السحب",      url:"withdrawals.php",    icon:"fa-money-bill-wave", hint:"المالية"},
  {label:"طرق السحب",        url:"withdraw_methods.php",icon:"fa-cog",            hint:"المالية"},
  {label:"سجل المعاملات",    url:"wallet.php",          icon:"fa-wallet",          hint:"المالية"},
  {label:"إشعار جماعي",      url:"broadcast.php",      icon:"fa-bullhorn",        hint:"النظام"},
  {label:"الإعدادات",        url:"settings.php",        icon:"fa-cog",             hint:"النظام"},
];
var searchFocus = -1;

function openSearch(){
  document.getElementById("searchOverlay").classList.add("open");
  setTimeout(function(){ document.getElementById("searchInput").focus(); },80);
  filterSearch("");
}
function closeSearch(){
  document.getElementById("searchOverlay").classList.remove("open");
  document.getElementById("searchInput").value = "";
  searchFocus = -1;
}
function handleSearchOverlayClick(e){
  if(e.target===document.getElementById("searchOverlay")) closeSearch();
}
function filterSearch(q){
  var res = document.getElementById("searchResults");
  var filtered = q.trim()==="" ? searchPages : searchPages.filter(function(p){
    return p.label.includes(q) || p.hint.includes(q);
  });
  if(!filtered.length){
    res.innerHTML = "<div style=\"padding:20px;text-align:center;color:var(--t3);font-size:.82rem\">لا نتائج لـ &ldquo;"+q+"&rdquo;</div>";
    return;
  }
  res.innerHTML = filtered.map(function(p,i){
    return "<a href=\""+p.url+"\" class=\"search-result-item\" data-idx=\""+i+"\" onclick=\"closeSearch()\">"+
      "<i class=\"fas "+p.icon+"\"></i>"+
      "<span>"+p.label+"</span>"+
      "<span class=\"sr-hint\">"+p.hint+"</span>"+
      "</a>";
  }).join("");
  searchFocus = -1;
}
function searchKeyNav(e){
  var items = document.querySelectorAll(".search-result-item");
  if(e.key==="ArrowDown"){e.preventDefault();searchFocus=Math.min(searchFocus+1,items.length-1);}
  else if(e.key==="ArrowUp"){e.preventDefault();searchFocus=Math.max(searchFocus-1,0);}
  else if(e.key==="Enter" && searchFocus>=0){items[searchFocus].click();return;}
  items.forEach(function(el,i){ el.classList.toggle("focused", i===searchFocus); });
  if(items[searchFocus]) items[searchFocus].scrollIntoView({block:"nearest"});
}

/* ══════ KEYBOARD SHORTCUTS ══════ */
document.addEventListener("keydown", function(e){
  // Ctrl+K or Cmd+K → open search
  if((e.ctrlKey||e.metaKey) && e.key==="k"){
    e.preventDefault(); openSearch();
  }
  // Escape → close any open overlay
  if(e.key==="Escape"){
    closeSearch();
    closeNotifPanel();
    document.querySelectorAll(".modal-overlay.open").forEach(function(m){ m.classList.remove("open"); });
  }
  // Alt+N → notification panel
  if(e.altKey && e.key==="n"){
    e.preventDefault(); toggleNotifPanel();
  }
  // Alt+B → broadcast modal
  if(e.altKey && e.key==="b"){
    e.preventDefault(); openBcastModal();
  }
});

/* ══════ BROADCAST MODAL ══════ */
function openBcastModal(){
  document.getElementById("bcastModal").classList.add("open");
}
function closeBcastModal(){
  document.getElementById("bcastModal").classList.remove("open");
}

/* ══════ MOBILE ══════ */
document.addEventListener("DOMContentLoaded",function(){
  var mb = document.getElementById("mobileBtn");
  if(window.innerWidth<=900 && mb) mb.style.display="flex";
});

/* ══════ AUTO-DISMISS ALERTS ══════ */
setTimeout(function(){
  document.querySelectorAll(".alert").forEach(function(a){
    a.style.transition="opacity .4s";a.style.opacity=0;
    setTimeout(function(){a.remove()},400);
  });
},4500);

/* ══════ RIPPLE EFFECT ══════ */
document.addEventListener("click",function(e){
  var b=e.target.closest(".btn");if(!b||b.disabled)return;
  var rip=document.createElement("span");
  rip.className="ripple-fx";
  var rect=b.getBoundingClientRect(),s=Math.max(rect.width,rect.height);
  rip.style.cssText="width:"+s+"px;height:"+s+"px;left:"+(e.clientX-rect.left-s/2)+"px;top:"+(e.clientY-rect.top-s/2)+"px";
  b.appendChild(rip);setTimeout(function(){rip.remove();},550);
});

/* ══════ SCROLL-TO-TOP ══════ */
(function(){
  var btn=document.getElementById("stt");
  window.addEventListener("scroll",function(){
    btn.style.opacity=window.scrollY>300?"1":"0";
    btn.style.pointerEvents=window.scrollY>300?"auto":"none";
  },{passive:true});
  btn.onclick=function(){window.scrollTo({top:0,behavior:"smooth"});};
})();
</script>
</body></html>';
}

function adminTopbar(string $title, string $sub='', string $extraHtml=''): void {
    echo '<div class="adm-topbar">
<div style="display:flex;align-items:center;gap:12px">
  <div class="adm-title">'.e($title).'<small>'.e($sub).'</small></div>
</div>
<div style="display:flex;gap:8px;align-items:center">
  '.$extraHtml.'
  <button class="btn btn-ghost btn-sm" onclick="openBcastModal()" title="إشعار جماعي سريع (Alt+B)">
    <i class="fas fa-paper-plane"></i>
  </button>
</div>
</div>';
}

function renderStars(float $rating): string {
    $full = min(5, floor($rating));
    $html = '';
    for($i=0;$i<$full;$i++) $html.='★';
    for($i=$full;$i<5;$i++) $html.='☆';
    return $html;
}
