<?php
/**
 * سوقي Souqy — نقطة الدخول الرئيسية
 * ─────────────────────────────────────────────────────
 *  زائر غير مسجّل  →  صفحة التسجيل  (pages/register.php)
 *  زائر مسجّل      →  الصفحة الرئيسية (pages/index.php)
 *  مدير             →  لوحة الإدارة   (admin/index.php)
 */
// استخدام db.php لضمان توحيد إعدادات الجلسة
require_once __DIR__ . '/includes/db.php';

// منع التخزين المؤقت للتوجيه
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (isset($_SESSION['uid'])) {
    if (!empty($_SESSION['is_admin'])) {
        header('Location: admin/index.php', true, 302);
    } else {
        header('Location: pages/index.php', true, 302);
    }
} else {
    header('Location: pages/register.php', true, 302);
}
exit;
