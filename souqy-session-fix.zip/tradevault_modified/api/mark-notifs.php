<?php
require_once __DIR__ . '/../includes/db.php';
if(!isLoggedIn()){http_response_code(401);echo json_encode(['ok'=>false]);exit;}
$uid = uid();
$all = $_POST['all'] ?? '';
if($all) {
    // Mark all notifications for this user as read
    $pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$uid]);
} else {
    $id = (int)($_POST['id'] ?? 0);
    if($id) $pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")->execute([$id,$uid]);
    else $pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$uid]);
}
echo json_encode(['ok'=>true]);
