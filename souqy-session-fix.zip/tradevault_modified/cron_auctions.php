<?php
/**
 * cron_auctions.php — تسوية المزادات المنتهية تلقائياً
 * شغّل كل 5 دقائق:
 *   */5 * * * * php /path/to/site/cron_auctions.php
 */
define('RUNNING_CRON', true);
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auction_helpers.php';

$isCli  = (PHP_SAPI === 'cli');
$cronKey= getSetting($pdo,'cron_secret_key','');
$keyOk  = $cronKey && isset($_GET['key']) && hash_equals($cronKey, $_GET['key']);
if (!$isCli && !$keyOk) { http_response_code(403); exit('Access denied'); }

echo "[".date('Y-m-d H:i:s')."] بدء تسوية المزادات\n";

$expired = $pdo->query("SELECT id,title FROM auctions WHERE status='active' AND end_date < NOW()")->fetchAll();
foreach($expired as $a){
    echo "[INFO] تسوية مزاد #{$a['id']}: {$a['title']}\n";
    settleAuction($pdo,(int)$a['id']);
    echo "[OK] تمت التسوية\n";
}
if(empty($expired)) echo "[OK] لا توجد مزادات منتهية\n";
echo "[".date('Y-m-d H:i:s')."] انتهى\n";
