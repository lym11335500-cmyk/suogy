<?php
// رابط تسجيل الدخول من الجذر
header('Location: pages/login.php', true, 302);
exit;
