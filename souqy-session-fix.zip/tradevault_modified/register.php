<?php
// الرابط العام — يوجّه للتسجيل دائماً
header('Location: pages/register.php', true, 302);
exit;
