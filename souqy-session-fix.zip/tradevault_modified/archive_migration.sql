-- نظام الأرشيف السري للموثقين
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `is_archived` tinyint(1) DEFAULT 0 AFTER `is_banned`;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `archived_at` timestamp NULL DEFAULT NULL AFTER `is_archived`;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `unique_id` varchar(20) DEFAULT NULL AFTER `id`;
