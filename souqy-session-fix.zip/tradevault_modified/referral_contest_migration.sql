-- =====================================================
-- نظام الإحالات والمسابقات — شغّل هذا الملف مرة واحدة فقط
-- =====================================================

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `referral_code` VARCHAR(20) NULL UNIQUE,
  ADD COLUMN IF NOT EXISTS `referred_by`   INT(11)     NULL;

CREATE TABLE IF NOT EXISTS `referrals` (
  `id`          INT(11)  NOT NULL AUTO_INCREMENT,
  `referrer_id` INT(11)  NOT NULL,
  `referred_id` INT(11)  NOT NULL,
  `contest_id`  INT(11)  NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_referred` (`referred_id`),
  INDEX `idx_referrer` (`referrer_id`),
  INDEX `idx_contest`  (`contest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `contests` (
  `id`                 INT(11)      NOT NULL AUTO_INCREMENT,
  `title`              VARCHAR(200) NOT NULL DEFAULT 'مسابقة إحالة',
  `start_date`         DATE         NOT NULL,
  `end_date`           DATE         NOT NULL,
  `status`             ENUM('active','ended','cancelled') NOT NULL DEFAULT 'active',
  `winners_calculated` TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `contest_results` (
  `id`             INT(11)       NOT NULL AUTO_INCREMENT,
  `contest_id`     INT(11)       NOT NULL,
  `user_id`        INT(11)       NOT NULL,
  `rank_pos`       TINYINT(3)    NOT NULL,
  `referral_count` INT(11)       NOT NULL DEFAULT 0,
  `reward`         DECIMAL(12,2) NULL,
  `reward_note`    VARCHAR(500)  NULL,
  `rewarded_at`    DATETIME      NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contest_rank` (`contest_id`, `rank_pos`),
  INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `site_settings` (`setting_key`, `setting_value`) VALUES
  ('contest_enabled', '1'),
  ('contest_top_n',   '5');

INSERT INTO `contests` (`title`, `start_date`, `end_date`, `status`)
SELECT CONCAT('مسابقة إحالة — ', DATE_FORMAT(CURDATE(), '%m/%Y')),
       DATE_FORMAT(CURDATE(), '%Y-%m-01'), LAST_DAY(CURDATE()), 'active'
WHERE NOT EXISTS (SELECT 1 FROM `contests` WHERE `status` = 'active');
