<?php
/**
 * سوقي Cron Job - Expire Ads
 * Run this via cron: php /path/to/cron_expire_ads.php
 * Recommended: every hour — 0 * * * * php /path/cron_expire_ads.php
 */
require_once __DIR__ . '/includes/db.php';

// Expire ads where end_date has passed
$expired = $pdo->exec("UPDATE ads SET status='expired' WHERE status='active' AND end_date IS NOT NULL AND end_date < CURDATE()");

echo date('[Y-m-d H:i:s]') . " Expired $expired ads.\n";
