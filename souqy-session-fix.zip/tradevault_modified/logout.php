<?php
// تسجيل الخروج من الجذر
header('Location: pages/logout.php', true, 302);
exit;
