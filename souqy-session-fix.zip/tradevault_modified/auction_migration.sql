-- =====================================================
-- نظام المزادات — شغّل هذا الملف مرة واحدة فقط
-- =====================================================

-- 1. جدول المزادات
CREATE TABLE IF NOT EXISTS `auctions` (
  `id`            INT(11)        NOT NULL AUTO_INCREMENT,
  `seller_id`     INT(11)        NOT NULL,
  `title`         VARCHAR(200)   NOT NULL,
  `description`   TEXT           NULL,
  `image_path`    VARCHAR(255)   NULL,
  `start_price`   DECIMAL(12,2)  NOT NULL DEFAULT 0.00,
  `current_price` DECIMAL(12,2)  NOT NULL DEFAULT 0.00,
  `min_increment` DECIMAL(12,2)  NOT NULL DEFAULT 1.00,
  `start_date`    DATETIME       NOT NULL,
  `end_date`      DATETIME       NOT NULL,
  `status`        ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `winner_id`     INT(11)        NULL,
  `views`         INT(11)        NOT NULL DEFAULT 0,
  `bid_count`     INT(11)        NOT NULL DEFAULT 0,
  `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_status`     (`status`),
  INDEX `idx_seller`     (`seller_id`),
  INDEX `idx_end_date`   (`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. جدول المزايدات
CREATE TABLE IF NOT EXISTS `bids` (
  `id`          INT(11)       NOT NULL AUTO_INCREMENT,
  `auction_id`  INT(11)       NOT NULL,
  `user_id`     INT(11)       NOT NULL,
  `bid_amount`  DECIMAL(12,2) NOT NULL,
  `is_winner`   TINYINT(1)    NOT NULL DEFAULT 0,
  `ip_address`  VARCHAR(45)   NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_auction` (`auction_id`),
  INDEX `idx_user`    (`user_id`),
  INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. إعدادات المزادات في site_settings
INSERT IGNORE INTO `site_settings` (`setting_key`, `setting_value`) VALUES
  ('auction_commission_rate', '5'),
  ('auction_min_increment',   '1'),
  ('auction_enabled',         '1'),
  ('auction_bid_rate_limit',  '5');

-- 4. إضافة auction_id لجدول chats
ALTER TABLE `chats`
  MODIFY COLUMN `purchase_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `auction_id`     INT NULL,
  ADD COLUMN IF NOT EXISTS `winner_id`      INT NULL,
  ADD COLUMN IF NOT EXISTS `seller_id2`     INT NULL,
  ADD COLUMN IF NOT EXISTS `winner_joined`  TINYINT(1) DEFAULT 0;
